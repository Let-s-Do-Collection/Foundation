package net.satisfy.foundation.tooltip;

import dev.architectury.event.events.client.ClientTooltipEvent;
import net.minecraft.class_1320;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2588;
import net.minecraft.class_5134;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_6880;
import net.minecraft.class_8828;
import net.satisfy.foundation.Foundation;
import net.satisfy.foundation.platform.PlatformHelper;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class AttributeIcons {
    private static final class_2583 ICON_STYLE = class_2583.field_24360.method_27704(Foundation.identifier("attribute_icons")).method_27703(class_5251.method_27717(0xFFFFFF)).method_10978(false).method_10982(false);
    private static final Map<class_6880<class_1320>, Character> ICONS = new LinkedHashMap<>();
    private static Map<String, class_2561> byKey;
    private static boolean initialized;

    static {
        ICONS.put(class_5134.field_23724, '');
        ICONS.put(class_5134.field_23725, '');
        ICONS.put(class_5134.field_23718, '');
        ICONS.put(class_5134.field_23721, '');
        ICONS.put(class_5134.field_23723, '');
        ICONS.put(class_5134.field_23716, '');
        ICONS.put(class_5134.field_23719, '');
    }

    private AttributeIcons() {
    }

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        ClientTooltipEvent.ITEM.register((stack, lines, context, flag) -> {
            if (PlatformHelper.enableAttributeIcons()) {
                apply(lines);
            }
        });
    }

    public static void apply(List<class_2561> lines) {
        for (int i = 0; i < lines.size(); i++) {
            class_2561 line = lines.get(i);
            class_2561 icon = icon(line);
            if (icon != null) {
                lines.set(i, class_2561.method_43473().method_10852(icon).method_10852(class_5244.field_41874).method_10852(trimLeadingSpace(line)));
            }
        }
    }

    @Nullable
    private static class_2561 icon(class_2561 line) {
        String key = attributeKey(line);
        return key == null ? null : icons().get(key);
    }

    private static Map<String, class_2561> icons() {
        if (byKey == null) {
            Map<String, class_2561> map = new LinkedHashMap<>();
            ICONS.forEach((attribute, glyph) -> map.put(attribute.comp_349().method_26830(), class_2561.method_43470(String.valueOf(glyph)).method_27696(ICON_STYLE)));
            byKey = map;
        }
        return byKey;
    }

    @Nullable
    private static String attributeKey(class_2561 component) {
        if (component.method_10851() instanceof class_2588 translatable && isModifierKey(translatable.method_11022())) {
            for (Object arg : translatable.method_11023()) {
                if (arg instanceof class_2561 argument && argument.method_10851() instanceof class_2588 name && icons().containsKey(name.method_11022())) {
                    return name.method_11022();
                }
            }
        }
        for (class_2561 sibling : component.method_10855()) {
            String key = attributeKey(sibling);
            if (key != null) {
                return key;
            }
        }
        return null;
    }

    private static boolean isModifierKey(String key) {
        return key.startsWith("attribute.modifier.") || key.startsWith("neoforge.modifier.");
    }

    private static class_2561 trimLeadingSpace(class_2561 line) {
        if (line.method_10851() instanceof class_8828 plain && plain.comp_737().isBlank() && !line.method_10855().isEmpty()) {
            class_5250 trimmed = class_2561.method_43473().method_27696(line.method_10866());
            line.method_10855().forEach(trimmed::method_10852);
            return trimmed;
        }
        return line;
    }
}
