package net.satisfy.foundation.client.creative;

import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5251;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.satisfy.foundation.rarity.FoundationRarity;
import net.satisfy.foundation.rarity.RarityTooltipFrame;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class CreativeTabTooltips {
    private static final Map<class_5321<class_1761>, FoundationRarity> RARITIES = new HashMap<>();

    private CreativeTabTooltips() {
    }

    public static void register(class_5321<class_1761> tab, FoundationRarity rarity) {
        RARITIES.put(tab, rarity);
    }

    public static boolean renderTab(class_332 graphics, class_327 font, class_1761 tab, int mouseX, int mouseY) {
        Optional<class_5321<class_1761>> key = class_7923.field_44687.method_29113(tab);
        FoundationRarity rarity = key.map(RARITIES::get).orElse(null);
        if (rarity == null) {
            return false;
        }
        class_2561 modId = class_2561.method_43470("@" + key.get().method_29177().method_12836()).method_27694(style -> style.method_27703(class_5251.method_27717(rarity.baseColor())).method_10978(true));
        render(graphics, font, rarity, tab.method_7747(), List.of(tab.method_7737(), modId), mouseX, mouseY);
        return true;
    }

    public static boolean renderSideTab(class_332 graphics, class_327 font, class_1761 tab, CreativeSideTabs.SideTab sideTab, int mouseX, int mouseY) {
        FoundationRarity rarity = rarity(tab);
        if (rarity == null) {
            return false;
        }
        render(graphics, font, rarity, sideTab.icon(), List.of(sideTab.title()), mouseX, mouseY);
        return true;
    }

    @Nullable
    private static FoundationRarity rarity(class_1761 tab) {
        return class_7923.field_44687.method_29113(tab).map(RARITIES::get).orElse(null);
    }

    private static void render(class_332 graphics, class_327 font, FoundationRarity rarity, class_1799 icon, List<class_2561> lines, int mouseX, int mouseY) {
        RarityTooltipFrame.mark(rarity, icon);
        graphics.method_51437(font, lines, Optional.empty(), mouseX, mouseY);
    }
}
