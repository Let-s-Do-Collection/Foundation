package net.satisfy.foundation.overlay;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_3966;

public interface EntityInfoProvider {
    List<InfoSection> describe(class_1937 level, class_1297 entity, class_3966 hit);

    default void beforeBackground(class_1937 level, class_1297 entity) {
    }
}
