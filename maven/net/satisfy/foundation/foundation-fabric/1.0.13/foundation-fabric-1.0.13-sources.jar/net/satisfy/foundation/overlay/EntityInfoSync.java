package net.satisfy.foundation.overlay;

import dev.architectury.networking.NetworkManager;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.satisfy.foundation.Foundation;

import java.util.ArrayList;
import java.util.List;

public final class EntityInfoSync {
    private static final double MAX_DISTANCE_SQR = 64.0;
    private static final int REQUEST_INTERVAL = 10;
    private static final int NO_ENTITY = -1;
    private static final class_2487 EMPTY = new class_2487();
    private static final List<Handler> HANDLERS = new ArrayList<>();

    private static class_2487 clientData = EMPTY;
    private static int clientId = NO_ENTITY;
    private static int lastRequest = NO_ENTITY;

    private EntityInfoSync() {
    }

    @FunctionalInterface
    public interface Handler {
        void write(class_3218 level, class_1297 entity, class_3222 player, class_2487 tag);
    }

    public record Request(int entityId) implements class_8710 {
        public static final class_9154<Request> TYPE = new class_9154<>(Foundation.identifier("entity_info_request"));
        public static final class_9139<class_9129, Request> CODEC = class_9139.method_56434(class_9135.field_48550, Request::entityId, Request::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public record Response(int entityId, class_2487 data) implements class_8710 {
        public static final class_9154<Response> TYPE = new class_9154<>(Foundation.identifier("entity_info"));
        public static final class_9139<class_9129, Response> CODEC = class_9139.method_56435(class_9135.field_48550, Response::entityId, class_9135.field_48556, Response::data, Response::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public static void registerHandler(Handler handler) {
        HANDLERS.add(handler);
    }

    public static void init() {
        NetworkManager.registerReceiver(NetworkManager.c2s(), Request.TYPE, Request.CODEC, (payload, context) -> context.queue(() -> {
            if (!(context.getPlayer() instanceof class_3222 player)) {
                return;
            }
            class_1297 entity = player.method_51469().method_8469(payload.entityId());
            if (entity == null || player.method_5858(entity) > MAX_DISTANCE_SQR) {
                return;
            }
            class_2487 tag = new class_2487();
            for (Handler handler : HANDLERS) {
                handler.write(player.method_51469(), entity, player, tag);
            }
            NetworkManager.sendToPlayer(player, new Response(payload.entityId(), tag));
        }));
        if (Platform.getEnvironment() == Env.CLIENT) {
            NetworkManager.registerReceiver(NetworkManager.s2c(), Response.TYPE, Response.CODEC, (payload, context) -> context.queue(() -> {
                clientId = payload.entityId();
                clientData = payload.data();
            }));
        } else {
            NetworkManager.registerS2CPayloadType(Response.TYPE, Response.CODEC);
        }
    }

    public static class_2487 poll(class_1297 entity) {
        if (entity.method_37908().method_8510() % REQUEST_INTERVAL == 0 || entity.method_5628() != lastRequest) {
            lastRequest = entity.method_5628();
            NetworkManager.sendToServer(new Request(entity.method_5628()));
        }
        return entity.method_5628() == clientId ? clientData : EMPTY;
    }
}
