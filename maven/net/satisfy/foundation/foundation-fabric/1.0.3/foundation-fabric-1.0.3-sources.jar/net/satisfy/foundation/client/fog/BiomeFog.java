package net.satisfy.foundation.client.fog;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.architectury.event.events.client.ClientTickEvent;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;

/**
 * Shared terrain fog for all mods. Every mod registers a {@link Source}, Foundation picks the densest active fog
 * and blends it in and out smoothly, so several mods never overwrite each other.
 */
public final class BiomeFog {
    private static final Map<class_2960, Source> SOURCES = new LinkedHashMap<>();
    private static final float FADE_STEP = 1.0F / 60.0F;
    private static final float FOLLOW_SPEED = 0.1F;

    private static boolean initialized;
    private static float factor;
    private static float previousFactor;
    private static float start;
    private static float end;
    private static float previousStart;
    private static float previousEnd;

    private BiomeFog() {
    }

    /** Fog distances in blocks. */
    public record Fog(float start, float end) {
    }

    @FunctionalInterface
    public interface Source {
        /** @return the fog this source wants right now, or {@code null} for none */
        @Nullable
        Fog get(class_638 level, class_2338 cameraPos, float renderDistance);
    }

    /** Adds or replaces a fog source. */
    public static void register(class_2960 id, Source source) {
        SOURCES.put(id, source);
        if (!initialized) {
            initialized = true;
            ClientTickEvent.CLIENT_POST.register(BiomeFog::tick);
        }
    }

    private static void tick(class_310 minecraft) {
        previousFactor = factor;
        previousStart = start;
        previousEnd = end;
        class_638 level = minecraft.field_1687;
        if (level == null || minecraft.field_1724 == null) {
            factor = 0.0F;
            return;
        }
        float renderDistance = minecraft.field_1773.method_3193();
        class_2338 cameraPos = minecraft.field_1773.method_19418().method_19328();
        Fog target = null;
        for (Source source : SOURCES.values()) {
            Fog fog = source.get(level, cameraPos, renderDistance);
            if (fog != null && (target == null || fog.end() < target.end())) {
                target = fog;
            }
        }
        if (target == null) {
            factor = Math.max(0.0F, factor - FADE_STEP);
            return;
        }
        if (factor <= 0.0F) {
            start = previousStart = target.start();
            end = previousEnd = target.end();
        } else {
            start = class_3532.method_16439(FOLLOW_SPEED, start, target.start());
            end = class_3532.method_16439(FOLLOW_SPEED, end, target.end());
        }
        factor = Math.min(1.0F, factor + FADE_STEP);
    }

    /** Called at the end of {@link class_758#method_3211}. */
    public static void apply(class_4184 camera, class_758.class_4596 mode, float partialTick) {
        if (mode != class_758.class_4596.field_20946 || camera.method_19334() != class_5636.field_27888) {
            return;
        }
        float blend = class_3532.method_16439(partialTick, previousFactor, factor);
        if (blend <= 0.0F) {
            return;
        }
        blend = blend * blend * (3.0F - 2.0F * blend);
        float fogStart = class_3532.method_16439(partialTick, previousStart, start);
        float fogEnd = class_3532.method_16439(partialTick, previousEnd, end);
        RenderSystem.setShaderFogStart(class_3532.method_16439(blend, RenderSystem.getShaderFogStart(), Math.min(fogStart, RenderSystem.getShaderFogStart())));
        RenderSystem.setShaderFogEnd(class_3532.method_16439(blend, RenderSystem.getShaderFogEnd(), Math.min(fogEnd, RenderSystem.getShaderFogEnd())));
    }
}
