package net.satisfy.foundation.flammable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2358;

public final class FoundationFlammables {
    private static final List<Entry> ENTRIES = new ArrayList<>();

    private FoundationFlammables() {
    }

    public static void register(int igniteOdds, int burnOdds, Supplier<? extends class_2248> block) {
        synchronized (ENTRIES) {
            ENTRIES.add(new Entry(block, igniteOdds, burnOdds));
        }
    }

    @SafeVarargs
    public static void register(int igniteOdds, int burnOdds, Supplier<? extends class_2248>... blocks) {
        for (Supplier<? extends class_2248> block : blocks) {
            register(igniteOdds, burnOdds, block);
        }
    }

    @SafeVarargs
    public static void wood(Supplier<? extends class_2248>... blocks) {
        register(5, 20, blocks);
    }

    @SafeVarargs
    public static void wool(Supplier<? extends class_2248>... blocks) {
        register(30, 60, blocks);
    }

    @SafeVarargs
    public static void hay(Supplier<? extends class_2248>... blocks) {
        register(60, 20, blocks);
    }

    @SafeVarargs
    public static void plant(Supplier<? extends class_2248>... blocks) {
        register(60, 100, blocks);
    }

    public static void apply() {
        class_2358 fire = (class_2358) class_2246.field_10036;
        synchronized (ENTRIES) {
            for (Entry entry : ENTRIES) {
                fire.method_10189(entry.block().get(), entry.igniteOdds(), entry.burnOdds());
            }
        }
    }

    private record Entry(Supplier<? extends class_2248> block, int igniteOdds, int burnOdds) {
    }
}
