package net.satisfy.foundation.client.gui.recipebook;

import dev.architectury.networking.NetworkManager;
import net.minecraft.class_124;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_3956;
import net.minecraft.class_437;
import net.minecraft.class_8786;
import net.satisfy.foundation.recipe.RecipeUnlockManager;
import net.satisfy.foundation.recipe.RecipeUnlockSync;
import net.satisfy.foundation.recipe.book.PlaceRecipePacket;
import net.satisfy.foundation.recipe.book.RecipePlacer;
import net.satisfy.foundation.recipe.book.StationRecipeBookMenu;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Vanilla styled recipe book panel for station menus implementing {@link StationRecipeBookMenu}.
 * Uses the vanilla recipe book textures. {@link StationRecipeBookScreen} wires it up,
 * custom screens can forward the calls themselves.
 */
public class StationRecipeBook {
    public static final int WIDTH = 147;
    public static final int HEIGHT = 166;
    private static final class_2960 TEXTURE = class_2960.method_60656("textures/gui/recipe_book.png");
    private static final class_2960 SLOT_CRAFTABLE = class_2960.method_60656("recipe_book/slot_craftable");
    private static final class_2960 SLOT_UNCRAFTABLE = class_2960.method_60656("recipe_book/slot_uncraftable");
    private static final class_2960 PAGE_FORWARD = class_2960.method_60656("recipe_book/page_forward");
    private static final class_2960 PAGE_FORWARD_HIGHLIGHTED = class_2960.method_60656("recipe_book/page_forward_highlighted");
    private static final class_2960 PAGE_BACKWARD = class_2960.method_60656("recipe_book/page_backward");
    private static final class_2960 PAGE_BACKWARD_HIGHLIGHTED = class_2960.method_60656("recipe_book/page_backward_highlighted");
    private static final class_2960 TAB = class_2960.method_60656("recipe_book/tab");
    private static final class_2960 TAB_SELECTED = class_2960.method_60656("recipe_book/tab_selected");
    private static final class_2960 FILTER_ENABLED = class_2960.method_60656("recipe_book/filter_enabled");
    private static final class_2960 FILTER_DISABLED = class_2960.method_60656("recipe_book/filter_disabled");
    private static final class_2960 FILTER_ENABLED_HIGHLIGHTED = class_2960.method_60656("recipe_book/filter_enabled_highlighted");
    private static final class_2960 FILTER_DISABLED_HIGHLIGHTED = class_2960.method_60656("recipe_book/filter_disabled_highlighted");
    private static final class_2561 SEARCH_HINT = class_2561.method_43471("gui.recipebook.search_hint");
    private static final class_2561 ONLY_CRAFTABLE = class_2561.method_43471("gui.recipebook.toggleRecipes.craftable");
    private static final class_2561 INGREDIENTS = class_2561.method_43471("gui.foundation.recipe_book.ingredients");
    private static final class_2561 ALL_RECIPES = class_2561.method_43471("gui.recipebook.toggleRecipes.all");
    private static final int COLUMNS = 5;
    private static final int ROWS = 4;
    private static final int BUTTON_SIZE = 25;

    // static so it stays open/filtered between screens, like vanilla does per session
    private static boolean open;
    private static boolean onlyCraftable;

    private class_310 minecraft;
    private class_1703 menu;
    private StationRecipeBookMenu book;
    private class_342 searchBox;
    private int x;
    private int y;
    private int page;
    private int tab;
    private boolean widthTooNarrow;
    private final List<Entry> entries = new ArrayList<>();
    private int lastInventoryChange = -1;
    private int lastMenuState = -1;
    private class_8786<?> ghost;
    private float ghostTime;
    private int ghostLeft;
    private int ghostTop;

    /** placeable: items are there, craftable: placeable and the station extras are met. */
    private record Entry(class_8786<?> recipe, class_1799 result, boolean placeable, boolean craftable) {
    }

    public <M extends class_1703 & StationRecipeBookMenu> void init(int screenWidth, int screenHeight, class_310 minecraft, M menu) {
        this.minecraft = minecraft;
        this.menu = menu;
        this.book = menu;
        this.widthTooNarrow = screenWidth < 379;
        this.x = (screenWidth - 147) / 2 - (widthTooNarrow ? 0 : 86);
        this.y = (screenHeight - 166) / 2;
        String search = searchBox != null ? searchBox.method_1882() : "";
        this.searchBox = new class_342(minecraft.field_1772, x + 25, y + 13, 81, 14, SEARCH_HINT);
        this.searchBox.method_1880(50);
        this.searchBox.method_1862(true);
        this.searchBox.method_1868(0xFFFFFF);
        this.searchBox.method_47404(SEARCH_HINT);
        this.searchBox.method_1852(search);
        refresh();
    }

    public boolean isOpen() {
        return open;
    }

    public void toggle() {
        open = !open;
        if (!open) {
            searchBox.method_25365(false);
        }
    }

    /** New leftPos of the container screen, shifted right while the book is open. */
    public int updateScreenPosition(int screenWidth, int imageWidth) {
        return open && !widthTooNarrow ? 177 + (screenWidth - imageWidth - 200) / 2 : (screenWidth - imageWidth) / 2;
    }

    /** Call every tick, rebuilds the list when the inventory or the inputs changed. */
    public void tick() {
        int inventoryChange = minecraft.field_1724.method_31548().method_7364();
        if (inventoryChange != lastInventoryChange || menu.method_37421() != lastMenuState) {
            refresh();
        }
    }

    private void refresh() {
        lastInventoryChange = minecraft.field_1724.method_31548().method_7364();
        lastMenuState = menu.method_37421();
        entries.clear();
        String query = searchBox.method_1882().toLowerCase(Locale.ROOT);
        for (class_8786<?> recipe : recipes()) {
            if (book.recipeBookRequiresUnlock() && !RecipeUnlockManager.isUnlocked(RecipeUnlockSync.clientUnlocked(), recipe)) {
                continue;
            }
            class_1799 result = recipe.comp_1933().method_8110(minecraft.field_1687.method_30349());
            if (!query.isEmpty() && !result.method_7964().getString().toLowerCase(Locale.ROOT).contains(query)) {
                continue;
            }
            boolean placeable = RecipePlacer.canCraft(minecraft.field_1724.method_31548(), menu, book.recipeBookPlacementSlots(recipe), book.recipeBookPlacementIngredients(recipe));
            boolean craftable = placeable && book.recipeBookExtrasMet(recipe);
            if (onlyCraftable && !craftable) {
                continue;
            }
            entries.add(new Entry(recipe, result, placeable, craftable));
        }
        entries.sort(Comparator.comparing((Entry entry) -> !entry.craftable).thenComparing(entry -> entry.result.method_7964().getString()));
        page = class_3532.method_15340(page, 0, pageCount() - 1);
    }

    private List<class_8786<?>> recipes() {
        return recipesOf(book.recipeBookTypes().get(tab));
    }

    private List<class_8786<?>> recipesOf(class_3956<?> type) {
        return minecraft.field_1687.method_8433().method_8126().stream().filter(recipe -> recipe.comp_1933().method_17716() == type).toList();
    }

    private int[] slotsFor(class_8786<?> recipe) {
        return book.recipeBookInputSlots(recipe.comp_1933().method_17716());
    }

    /** Tab icon: result of the first recipe of that type. */
    private class_1799 tabIcon(class_3956<?> type) {
        List<class_8786<?>> recipes = recipesOf(type);
        return recipes.isEmpty() ? class_1799.field_8037 : recipes.get(0).comp_1933().method_8110(minecraft.field_1687.method_30349());
    }

    private boolean hasTabs() {
        return book.recipeBookTypes().size() > 1;
    }

    private int tabY(int index) {
        return y + 3 + 27 * index;
    }

    private int pageCount() {
        return Math.max(1, class_3532.method_38788(entries.size(), COLUMNS * ROWS));
    }

    public void render(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (!open) {
            return;
        }
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0, 0, 100);
        if (hasTabs()) {
            List<class_3956<?>> types = book.recipeBookTypes();
            for (int i = 0; i < types.size(); i++) {
                boolean selected = i == tab;
                int tx = selected ? x - 32 : x - 30;
                graphics.method_52706(selected ? TAB_SELECTED : TAB, tx, tabY(i), 35, 27);
                graphics.method_51445(tabIcon(types.get(i)), tx + 9 + (selected ? -2 : 0), tabY(i) + 5);
            }
        }
        graphics.method_25302(TEXTURE, x, y, 1, 1, WIDTH, HEIGHT);
        searchBox.method_25394(graphics, mouseX, mouseY, partialTick);

        boolean filterHovered = isOver(mouseX, mouseY, x + 110, y + 12, 26, 16);
        class_2960 filter = onlyCraftable
                ? (filterHovered ? FILTER_ENABLED_HIGHLIGHTED : FILTER_ENABLED)
                : (filterHovered ? FILTER_DISABLED_HIGHLIGHTED : FILTER_DISABLED);
        graphics.method_52706(filter, x + 110, y + 12, 26, 16);

        int start = page * COLUMNS * ROWS;
        for (int i = 0; i < COLUMNS * ROWS && start + i < entries.size(); i++) {
            Entry entry = entries.get(start + i);
            int bx = buttonX(i);
            int by = buttonY(i);
            graphics.method_52706(entry.craftable ? SLOT_CRAFTABLE : SLOT_UNCRAFTABLE, bx, by, BUTTON_SIZE, BUTTON_SIZE);
            graphics.method_51445(entry.result, bx + 4, by + 4);
            graphics.method_51431(minecraft.field_1772, entry.result, bx + 4, by + 4);
        }

        if (pageCount() > 1) {
            class_2561 text = class_2561.method_43470((page + 1) + "/" + pageCount());
            int textWidth = minecraft.field_1772.method_27525(text);
            graphics.method_51439(minecraft.field_1772, text, x + 73 - textWidth / 2, y + 141, -1, false);
            if (page > 0) {
                graphics.method_52706(isOver(mouseX, mouseY, x + 38, y + 137, 12, 17) ? PAGE_BACKWARD_HIGHLIGHTED : PAGE_BACKWARD, x + 38, y + 137, 12, 17);
            }
            if (page < pageCount() - 1) {
                graphics.method_52706(isOver(mouseX, mouseY, x + 93, y + 137, 12, 17) ? PAGE_FORWARD_HIGHLIGHTED : PAGE_FORWARD, x + 93, y + 137, 12, 17);
            }
        }
        graphics.method_51448().method_22909();
    }

    public void renderTooltip(class_332 graphics, int mouseX, int mouseY) {
        if (renderGhostTooltip(graphics, mouseX, mouseY)) {
            return;
        }
        if (!open) {
            return;
        }
        if (isOver(mouseX, mouseY, x + 110, y + 12, 26, 16)) {
            graphics.method_51438(minecraft.field_1772, onlyCraftable ? ONLY_CRAFTABLE : ALL_RECIPES, mouseX, mouseY);
            return;
        }
        if (hasTabs()) {
            List<class_3956<?>> types = book.recipeBookTypes();
            for (int i = 0; i < types.size(); i++) {
                class_2561 name = book.recipeBookTabName(types.get(i));
                if (name != null && isOver(mouseX, mouseY, x - 30, tabY(i), 35, 27)) {
                    graphics.method_51438(minecraft.field_1772, name, mouseX, mouseY);
                    return;
                }
            }
        }
        int hovered = hoveredButton(mouseX, mouseY);
        if (hovered >= 0) {
            Entry entry = entries.get(hovered);
            List<class_2561> lines = new ArrayList<>(class_437.method_25408(minecraft, entry.result));
            lines.add(INGREDIENTS.method_27661().method_27692(class_124.field_1080));
            for (Map.Entry<String, Integer> ingredient : countIngredients(entry.recipe).entrySet()) {
                lines.add(class_2561.method_43470(" " + ingredient.getValue() + "× " + ingredient.getKey()).method_27692(class_124.field_1063));
            }
            book.appendRecipeBookTooltip(entry.recipe, lines);
            graphics.method_51434(minecraft.field_1772, lines, mouseX, mouseY);
        }
    }

    /** Ingredient name -> count, the name cycles through the options like the ghost does. */
    private Map<String, Integer> countIngredients(class_8786<?> recipe) {
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (class_1856 ingredient : book.recipeBookPlacementIngredients(recipe)) {
            class_1799[] items = ingredient.method_8105();
            if (items.length == 0) {
                continue;
            }
            class_1799 shown = items[(int) (minecraft.field_1687.method_8510() / 20 % items.length)];
            counts.merge(shown.method_7964().getString(), 1, Integer::sum);
        }
        return counts;
    }

    /** Draws the missing ingredients of the last clicked recipe into the input slots. */
    public void renderGhost(class_332 graphics, int leftPos, int topPos, float partialTick) {
        if (ghost == null) {
            return;
        }
        ghostLeft = leftPos;
        ghostTop = topPos;
        if (!class_437.method_25441()) {
            ghostTime += partialTick;
        }
        List<class_1856> ingredients = book.recipeBookPlacementIngredients(ghost);
        int[] slots = book.recipeBookPlacementSlots(ghost);
        for (int i = 0; i < ingredients.size() && i < slots.length; i++) {
            renderGhostSlot(graphics, leftPos, topPos, slots[i], ingredients.get(i));
        }
        book.recipeBookExtraGhosts(ghost).forEach((slot, ingredient) -> renderGhostSlot(graphics, leftPos, topPos, slot, ingredient));
        int resultSlot = book.recipeBookResultSlot(ghost.comp_1933().method_17716());
        if (resultSlot >= 0) {
            class_1799 result = ghost.comp_1933().method_8110(minecraft.field_1687.method_30349());
            renderGhostSlot(graphics, leftPos, topPos, resultSlot, class_1856.method_8101(result));
            class_1735 slot = menu.method_7611(resultSlot);
            if (!slot.method_7681()) {
                graphics.method_51448().method_22903();
                graphics.method_51448().method_46416(0, 0, 250);
                graphics.method_51431(minecraft.field_1772, result, leftPos + slot.field_7873, topPos + slot.field_7872);
                graphics.method_51448().method_22909();
            }
        }
    }

    /** Tooltip of the ghost item under the mouse, same item the slot shows right now. */
    private boolean renderGhostTooltip(class_332 graphics, int mouseX, int mouseY) {
        if (ghost == null) {
            return false;
        }
        Map<Integer, class_1856> slots = new LinkedHashMap<>();
        List<class_1856> ingredients = book.recipeBookPlacementIngredients(ghost);
        int[] placement = book.recipeBookPlacementSlots(ghost);
        for (int i = 0; i < ingredients.size() && i < placement.length; i++) {
            slots.put(placement[i], ingredients.get(i));
        }
        slots.putAll(book.recipeBookExtraGhosts(ghost));
        int resultSlot = book.recipeBookResultSlot(ghost.comp_1933().method_17716());
        if (resultSlot >= 0) {
            slots.put(resultSlot, class_1856.method_8101(ghost.comp_1933().method_8110(minecraft.field_1687.method_30349())));
        }
        for (Map.Entry<Integer, class_1856> entry : slots.entrySet()) {
            class_1799[] items = entry.getValue().method_8105();
            class_1735 slot = menu.method_7611(entry.getKey());
            if (items.length == 0 || slot.method_7681()) {
                continue;
            }
            if (isOver(mouseX, mouseY, ghostLeft + slot.field_7873, ghostTop + slot.field_7872, 16, 16)) {
                class_1799 stack = items[class_3532.method_15375(ghostTime / 30.0F) % items.length];
                graphics.method_51446(minecraft.field_1772, stack, mouseX, mouseY);
                return true;
            }
        }
        return false;
    }

    private void renderGhostSlot(class_332 graphics, int leftPos, int topPos, int slotIndex, class_1856 ingredient) {
        class_1799[] items = ingredient.method_8105();
        class_1735 slot = menu.method_7611(slotIndex);
        if (items.length == 0 || slot.method_7681()) {
            return;
        }
        class_1799 stack = items[class_3532.method_15375(ghostTime / 30.0F) % items.length];
        int sx = leftPos + slot.field_7873;
        int sy = topPos + slot.field_7872;
        graphics.method_25294(sx, sy, sx + 16, sy + 16, 0x30FF0000);
        graphics.method_51445(stack, sx, sy);
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0, 0, 200);
        graphics.method_25294(sx, sy, sx + 16, sy + 16, 0x30FFFFFF);
        graphics.method_51448().method_22909();
    }

    /** Recipe shown as ghost right now, null if none. */
    public @Nullable class_8786<?> getGhost() {
        return ghost;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!open || minecraft.field_1724.method_7325()) {
            return false;
        }
        if (searchBox.method_25402(mouseX, mouseY, button)) {
            searchBox.method_25365(true);
            return true;
        }
        searchBox.method_25365(false);
        if (hasTabs()) {
            for (int i = 0; i < book.recipeBookTypes().size(); i++) {
                if (isOver(mouseX, mouseY, x - 30, tabY(i), 35, 27)) {
                    if (tab != i) {
                        tab = i;
                        page = 0;
                        ghost = null;
                        refresh();
                    }
                    return true;
                }
            }
        }
        if (isOver(mouseX, mouseY, x + 110, y + 12, 26, 16)) {
            onlyCraftable = !onlyCraftable;
            page = 0;
            refresh();
            return true;
        }
        if (pageCount() > 1 && page > 0 && isOver(mouseX, mouseY, x + 38, y + 137, 12, 17)) {
            page--;
            return true;
        }
        if (pageCount() > 1 && page < pageCount() - 1 && isOver(mouseX, mouseY, x + 93, y + 137, 12, 17)) {
            page++;
            return true;
        }
        int hovered = hoveredButton(mouseX, mouseY);
        if (hovered >= 0) {
            Entry entry = entries.get(hovered);
            if (entry.placeable) {
                ghost = null;
                NetworkManager.sendToServer(new PlaceRecipePacket(menu.field_7763, entry.recipe.comp_1932(), class_437.method_25442()));
            } else if (inputsEmpty(slotsFor(entry.recipe))) {
                ghost = entry.recipe;
            }
            return true;
        }
        return isMouseOver(mouseX, mouseY);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!open || !searchBox.method_25370()) {
            return false;
        }
        if (keyCode == 256) {
            return false;
        }
        String before = searchBox.method_1882();
        searchBox.method_25404(keyCode, scanCode, modifiers);
        if (!before.equals(searchBox.method_1882())) {
            page = 0;
            refresh();
        }
        // swallow everything else so inventory keys don't close the screen while typing
        return true;
    }

    public boolean charTyped(char codePoint, int modifiers) {
        if (!open || !searchBox.method_25370()) {
            return false;
        }
        if (searchBox.method_25400(codePoint, modifiers)) {
            page = 0;
            refresh();
        }
        return true;
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        if (open && hasTabs() && isOver(mouseX, mouseY, x - 32, tabY(0), 35, 27 * book.recipeBookTypes().size())) {
            return true;
        }
        return open && isOver(mouseX, mouseY, x, y, WIDTH, HEIGHT);
    }

    /** Drops the ghost, call when the player clicks a slot. */
    public void clearGhost() {
        ghost = null;
    }

    private boolean inputsEmpty(int[] slots) {
        for (int index : slots) {
            if (menu.method_7611(index).method_7681()) {
                return false;
            }
        }
        return true;
    }

    private int hoveredButton(double mouseX, double mouseY) {
        int start = page * COLUMNS * ROWS;
        for (int i = 0; i < COLUMNS * ROWS && start + i < entries.size(); i++) {
            if (isOver(mouseX, mouseY, buttonX(i), buttonY(i), BUTTON_SIZE, BUTTON_SIZE)) {
                return start + i;
            }
        }
        return -1;
    }

    private int buttonX(int index) {
        return x + 11 + BUTTON_SIZE * (index % COLUMNS);
    }

    private int buttonY(int index) {
        return y + 31 + BUTTON_SIZE * (index / COLUMNS);
    }

    private static boolean isOver(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }
}
