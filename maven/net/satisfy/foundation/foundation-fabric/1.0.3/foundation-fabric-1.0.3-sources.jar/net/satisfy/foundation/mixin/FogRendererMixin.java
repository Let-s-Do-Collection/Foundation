package net.satisfy.foundation.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_758;
import net.satisfy.foundation.client.fog.BiomeFog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hook for {@link BiomeFog}. */
@Mixin(class_758.class)
public abstract class FogRendererMixin {
    @Inject(method = "setupFog", at = @At("TAIL"), require = 0)
    private static void foundation$biomeFog(class_4184 camera, class_758.class_4596 mode, float renderDistance, boolean thickFog, float partialTick, CallbackInfo callback) {
        BiomeFog.apply(camera, mode, partialTick);
    }
}
