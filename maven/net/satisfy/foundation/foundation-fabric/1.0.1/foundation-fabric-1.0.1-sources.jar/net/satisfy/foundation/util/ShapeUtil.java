package net.satisfy.foundation.util;

import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.world.level.*;
import java.util.*;

/** VoxelShape and placement helpers. */
public final class ShapeUtil {
    private ShapeUtil() {
    }

    /** Checks the block BELOW the pos. */
    public static boolean isFullAndSolid(class_4538 levelReader, class_2338 blockPos) {
        return isFaceFull(levelReader, blockPos) && isSolid(levelReader, blockPos);
    }

    public static boolean isFaceFull(class_4538 levelReader, class_2338 blockPos) {
        class_2338 belowPos = blockPos.method_10074();
        return class_2248.method_9501(levelReader.method_8320(belowPos).method_26222(levelReader, belowPos), class_2350.field_11036);
    }

    public static boolean isSolid(class_4538 levelReader, class_2338 blockPos) {
        return levelReader.method_8320(blockPos.method_10074()).method_51367();
    }

    /** Rotates a shape around y, clockwise from {@code from} to {@code to}. Build shapes facing north, then rotate. */
    public static class_265 rotateShape(class_2350 from, class_2350 to, class_265 shape) {
        class_265[] buffer = new class_265[]{shape, class_259.method_1073()};
        int times = (to.method_10161() - from.method_10161() + 4) % 4;

        for(int i = 0; i < times; ++i) {
            buffer[0].method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
                buffer[1] = class_259.method_1082(buffer[1], class_259.method_1081(1.0 - maxZ, minY, minX, 1.0 - minZ, maxY, maxX), class_247.field_1366);
            });
            buffer[0] = buffer[1];
            buffer[1] = class_259.method_1073();
        }

        return buffer[0];
    }

    /**
     * Hit position on the front face as (x, y), 0-1, seen from the front.
     * Empty if a forbidden or side face was hit.
     */
    public static Optional<class_3545<Float, Float>> getRelativeHitCoordinatesForBlockFace(class_3965 blockHitResult, class_2350 direction, class_2350[] unAllowedDirections) {
        class_2350 direction2 = blockHitResult.method_17780();
        if (Arrays.stream(unAllowedDirections).toList().contains(direction2)) {
            return Optional.empty();
        } else if (direction != direction2 && direction2 != class_2350.field_11036 && direction2 != class_2350.field_11033) {
            return Optional.empty();
        } else {
            class_2338 blockPos = blockHitResult.method_17777().method_10093(direction2);
            class_243 vec3 = blockHitResult.method_17784().method_1023((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260());
            float d = (float)vec3.method_10216();
            float f = (float)vec3.method_10215();
            float y = (float)vec3.method_10214();
            if (direction2 == class_2350.field_11036 || direction2 == class_2350.field_11033) {
                direction2 = direction;
            }

            Optional var10000;
            switch (direction2) {
                case field_11043:
                    var10000 = Optional.of(new class_3545((float)(1.0 - (double)d), y));
                    break;
                case field_11035:
                    var10000 = Optional.of(new class_3545(d, y));
                    break;
                case field_11039:
                    var10000 = Optional.of(new class_3545(f, y));
                    break;
                case field_11034:
                    var10000 = Optional.of(new class_3545((float)(1.0 - (double)f), y));
                    break;
                case field_11033:
                case field_11036:
                    var10000 = Optional.empty();
                    break;
                default:
                    throw new IncompatibleClassChangeError();
            }

            return var10000;
        }
    }
}
