package net.satisfy.foundation.storage;

import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.satisfy.foundation.storage.StorageBlockEntity;

/** Renders the items of one storage type. Pose stack is already rotated to the facing. */
public interface StorageTypeRenderer {
    void render(StorageBlockEntity var1, class_4587 var2, class_4597 var3, class_2371<class_1799> var4);
}