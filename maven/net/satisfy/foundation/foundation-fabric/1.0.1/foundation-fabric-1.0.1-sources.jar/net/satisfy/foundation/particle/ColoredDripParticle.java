package net.satisfy.foundation.particle;

import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_9381;

/** Same hang, fall and land drop as {@link WaterDripParticle}, but tinted with the color of the particle option. */
public class ColoredDripParticle extends WaterDripParticle {
    protected ColoredDripParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_4002 sprites, class_9381 color) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites);
        this.method_3084(color.method_58259(), color.method_58263(), color.method_58264());
    }

    public static class Provider implements class_707<class_9381> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_9381 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new ColoredDripParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites, type);
        }
    }
}
