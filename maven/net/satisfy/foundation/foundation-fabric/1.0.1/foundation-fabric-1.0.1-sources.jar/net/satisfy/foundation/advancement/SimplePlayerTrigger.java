package net.satisfy.foundation.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

/**
 * Dead simple advancement trigger without any conditions.
 * Register one per "event" you want and just call {@link #trigger(class_3222)}.
 */
public class SimplePlayerTrigger extends class_4558<SimplePlayerTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    /** Fires the trigger for the given player, every instance matches. */
    public void trigger(class_3222 player) {
        this.method_22510(player, instance -> true);
    }

    public record TriggerInstance(Optional<class_5258> player) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029)
        ).apply(instance, TriggerInstance::new));
    }
}
