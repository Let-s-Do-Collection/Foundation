package net.satisfy.foundation.block;

import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2521;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2756;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

/** Tall flower variant, same as {@link BonemealableFlowerBlock} but only the lower half drops. */
public class BonemealableTallFlowerBlock extends class_2521 implements class_2256 {
    private static final float RETURN_CHANCE = 0.6F;

    public BonemealableTallFlowerBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public boolean method_9651(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return true;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        return true;
    }

    @Override
    public void method_9652(class_3218 serverLevel, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        if (blockState.method_11654(class_2741.field_12533) == class_2756.field_12609) {
            return;
        }
        if (randomSource.method_43057() < RETURN_CHANCE) {
            method_9577(serverLevel, blockPos, new class_1799(this));
        }
    }
}