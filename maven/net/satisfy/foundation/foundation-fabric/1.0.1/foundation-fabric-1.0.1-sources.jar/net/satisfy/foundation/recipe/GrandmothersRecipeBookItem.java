package net.satisfy.foundation.recipe;

import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_8786;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Consumable item that "unlocks" one or more recipes on use.
 * Recipe ids are stored in custom data ({@code Recipe} or {@code Recipes}).
 * Unlocks are saved through {@link RecipeUnlockManager}.
 */
public class GrandmothersRecipeBookItem extends class_1792 {
    public GrandmothersRecipeBookItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        if (stack.method_57826(class_9334.field_49628)) {
            var data = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
            List<class_2960> recipeIds = new ArrayList<>();
            if (data != null && data.method_57450("Recipes")) {
                class_2499 list = data.method_57461().method_10554("Recipes", 8);
                for (int i = 0; i < list.size(); i++) {
                    recipeIds.add(class_2960.method_60654(list.method_10608(i)));
                }
            } else if (data.method_57450("Recipe")) {
                recipeIds.add(class_2960.method_60654(data.method_57461().method_10558("Recipe")));
            }
            if (!recipeIds.isEmpty()) {
                class_1863 manager = (class_310.method_1551().field_1687).method_8433();
                for (class_2960 id : recipeIds) {
                    Optional<? extends class_8786<?>> opt = manager.method_8130(id);
                    if (opt.isPresent()) {
                        class_8786<?> recipe = opt.get();
                        class_1799 resultStack = recipe.comp_1933().method_8110((class_310.method_1551().field_1687).method_30349());
                        tooltip.add(class_2561.method_43469("tooltip.foundation.recipe_unlocker.unlocks", resultStack.method_7964())
                                .method_27692(class_124.field_1080));
                    } else {
                        tooltip.add(class_2561.method_43469("tooltip.foundation.recipe_unlocker.unlocks", id.toString())
                                .method_27692(class_124.field_1080));
                    }
                }
            }
        }
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
            class_1799 stack = player.method_5998(hand);
            class_9279 data = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
            if (data != null) {
                List<class_2960> recipeIds = new ArrayList<>();
                if (data.method_57450("Recipes")) {
                    class_2499 list = data.method_57461().method_10554("Recipes", 8);
                    for (int i = 0; i < list.size(); i++) {
                        recipeIds.add(class_2960.method_60654(list.method_10608(i)));
                    }
                } else if (data.method_57450("Recipe")) {
                    recipeIds.add(class_2960.method_60654(data.method_57461().method_10558("Recipe")));
                }
                if (!recipeIds.isEmpty()) {
                    Set<class_2960> unlocked = RecipeUnlockManager.loadUnlockedRecipes(serverPlayer);
                    if (unlocked.containsAll(recipeIds)) {
                        serverPlayer.method_7353(class_2561.method_43471("tooltip.foundation.recipe_unlocker.already_unlocked")
                                .method_27692(class_124.field_1061), false);
                        return class_1271.method_22427(stack);
                    }
                    class_1863 manager = level.method_8433();
                    List<class_8786<?>> recipes = new ArrayList<>();
                    for (class_2960 id : recipeIds) {
                        Optional<? extends class_8786<?>> opt = manager.method_8130(id);
                        opt.ifPresent(recipes::add);
                    }
                    if (!recipes.isEmpty()) {
                        RecipeUnlockManager.unlockRecipeIds(serverPlayer, recipeIds);
                        class_8786<?> firstRecipe = recipes.get(0);
                        class_1799 resultStack = firstRecipe.comp_1933().method_8110(level.method_30349());
                        class_5250 message = class_2561.method_43470("")
                                .method_10852(class_2561.method_43471("tooltip.foundation.recipe_unlocker.unlocked.prefix")
                                        .method_27692(class_124.field_1054))
                                .method_10852(class_2561.method_43470(" [").method_27692(class_124.field_1068))
                                .method_10852(resultStack.method_7964().method_27661().method_27694(style -> style.method_10977(class_124.field_1068)
                                        .method_10949(new class_2568(class_2568.class_5247.field_24343,
                                                new class_2568.class_5249(resultStack)))))
                                .method_10852(class_2561.method_43470("]").method_27692(class_124.field_1068));
                        serverPlayer.method_7353(message, false);
                        spawnGoldenParticles(serverPlayer);
                        stack.method_7934(1);
                        return class_1271.method_22427(stack);
                    }
                }
            }
        }
        return class_1271.method_22430(player.method_5998(hand));
    }

    /** Creates a book stack for the given recipe ids. */
    public static class_1799 createUnlockerForRecipes(GrandmothersRecipeBookItem item, String... recipeIds) {
        class_1799 stack = new class_1799(item);
        class_2487 tag = new class_2487();
        if (recipeIds.length == 1) {
            tag.method_10582("Recipe", recipeIds[0]);
        } else {
            class_2499 list = new class_2499();
            for (String id : recipeIds) {
                list.add(class_2519.method_23256(id));
            }
            tag.method_10566("Recipes", list);
        }
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        return stack;
    }

    private void spawnGoldenParticles(class_3222 serverPlayer) {
        class_3218 serverLevel = (class_3218) serverPlayer.method_37908();
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 40) {
                    timer.cancel();
                    return;
                }
                serverLevel.method_14199(new class_2390(new Vector3f(1.0f, 0.84f, 0.0f), 1.0f),
                        serverPlayer.method_23317(), serverPlayer.method_23318() + 1.0, serverPlayer.method_23321(),
                        5, 0.5, 0.5, 0.5, 0.0);
                ticks++;
            }
        }, 0, 50);
    }
}