package net.satisfy.foundation.fabric.client;

import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.satisfy.foundation.client.armor.ArmorModels;

public final class FoundationArmorRenderer implements ArmorRenderer {
    public static final FoundationArmorRenderer INSTANCE = new FoundationArmorRenderer();

    private FoundationArmorRenderer() {
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, class_1799 stack, class_1309 entity, class_1304 slot, int light, class_572<class_1309> contextModel) {
        ArmorModels.render(matrices, vertexConsumers, stack, slot, light, contextModel);
    }
}
