package net.satisfy.foundation.block;

import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5815;
import net.minecraft.class_7923;
import net.minecraft.class_9062;
import net.satisfy.foundation.util.DyeHelper;
import org.jetbrains.annotations.NotNull;

public class TableBlock extends LineConnectingBlock implements class_3737 {
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    public static final class_2754<ClothColor> TABLECLOTH = class_2754.method_11850("tablecloth", ClothColor.class);
    private static final class_265 TOP_SHAPE = method_9541(0, 13, 0, 16, 16, 16);
    private static final class_265[] LEG_SHAPES = {
            method_9541(1, 0, 1, 4, 13, 4),
            method_9541(12, 0, 1, 15, 13, 4),
            method_9541(12, 0, 12, 15, 13, 15),
            method_9541(1, 0, 12, 4, 13, 15)
    };

    private final boolean alwaysCovered;

    public TableBlock(class_2251 properties) {
        this(properties, ClothColor.NONE);
    }

    public TableBlock(class_2251 properties, ClothColor fixedCloth) {
        super(properties);
        this.alwaysCovered = fixedCloth != ClothColor.NONE;
        method_9590(method_9564().method_11657(WATERLOGGED, false).method_11657(TABLECLOTH, fixedCloth));
    }

    protected class_265 getTableShape(LineConnectingType type, class_2350 facing) {
        if (type == LineConnectingType.MIDDLE) {
            return TOP_SHAPE;
        }
        boolean leftEnd = facing == class_2350.field_11043 && type == LineConnectingType.LEFT || facing == class_2350.field_11035 && type == LineConnectingType.RIGHT;
        boolean rightEnd = facing == class_2350.field_11043 && type == LineConnectingType.RIGHT || facing == class_2350.field_11035 && type == LineConnectingType.LEFT;
        boolean eastLeft = facing == class_2350.field_11034 && type == LineConnectingType.LEFT || facing == class_2350.field_11039 && type == LineConnectingType.RIGHT;
        boolean eastRight = facing == class_2350.field_11034 && type == LineConnectingType.RIGHT || facing == class_2350.field_11039 && type == LineConnectingType.LEFT;
        if (leftEnd) return class_259.method_17786(TOP_SHAPE, LEG_SHAPES[0], LEG_SHAPES[3]);
        if (rightEnd) return class_259.method_17786(TOP_SHAPE, LEG_SHAPES[1], LEG_SHAPES[2]);
        if (eastLeft) return class_259.method_17786(TOP_SHAPE, LEG_SHAPES[0], LEG_SHAPES[1]);
        if (eastRight) return class_259.method_17786(TOP_SHAPE, LEG_SHAPES[2], LEG_SHAPES[3]);
        return class_259.method_17786(TOP_SHAPE, LEG_SHAPES);
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return getTableShape(state.method_11654(TYPE), state.method_11654(FACING));
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2680 state = super.method_9605(context);
        return state == null ? null : state.method_11657(WATERLOGGED, context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910);
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        ClothColor cloth = state.method_11654(TABLECLOTH);
        if (!alwaysCovered && cloth == ClothColor.NONE && class_2248.method_9503(stack.method_7909()) instanceof class_5815 carpet) {
            if (!level.method_8608()) {
                level.method_8501(pos, state.method_11657(TABLECLOTH, ClothColor.of(carpet.method_33635())));
                level.method_8396(null, pos, class_3417.field_15226, class_3419.field_15245, 1.0F, 1.0F);
                stack.method_57008(1, player);
            }
            return class_9062.method_55644(level.method_8608());
        }
        if (cloth != ClothColor.NONE && stack.method_7909() instanceof class_1769 dye && cloth.color() != dye.method_7802()) {
            return DyeHelper.apply(stack, dye.method_7802(), state.method_11657(TABLECLOTH, ClothColor.of(dye.method_7802())), level, pos, player);
        }
        if (!alwaysCovered && cloth != ClothColor.NONE && stack.method_7960() && player.method_5715()) {
            if (!level.method_8608()) {
                level.method_8501(pos, state.method_11657(TABLECLOTH, ClothColor.NONE));
                level.method_8396(null, pos, class_3417.field_14983, class_3419.field_15245, 1.0F, 1.0F);
                class_1799 carpet = new class_1799(carpetFor(cloth.color()));
                if (!player.method_31548().method_7394(carpet)) player.method_7328(carpet, false);
            }
            return class_9062.method_55644(level.method_8608());
        }
        return super.method_55765(stack, state, level, pos, player, hand, hit);
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        ClothColor cloth = state.method_11654(TABLECLOTH);
        if (!alwaysCovered && !state.method_27852(newState.method_26204()) && cloth != ClothColor.NONE) {
            class_1264.method_5449(level, pos.method_10263(), pos.method_10264(), pos.method_10260(), new class_1799(carpetFor(cloth.color())));
        }
        super.method_9536(state, level, pos, newState, moved);
    }

    private static class_1792 carpetFor(class_1767 color) {
        for (class_2248 block : class_7923.field_41175) {
            if (block instanceof class_5815 carpet && carpet.method_33635() == color) return block.method_8389();
        }
        return class_1802.field_8850;
    }

    @Override
    public @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(WATERLOGGED, TABLECLOTH);
    }

    @Override
    public @NotNull class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }
}
