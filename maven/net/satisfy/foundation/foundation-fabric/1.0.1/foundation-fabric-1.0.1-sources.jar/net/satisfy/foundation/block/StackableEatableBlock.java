package net.satisfy.foundation.block;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3d;

/** Like {@link StackableBlock}, but sneak + empty hand eats one layer instead. */
@SuppressWarnings("all")
public class StackableEatableBlock extends class_2248 implements class_2343 {
    private static final class_2758 STACK_PROPERTY = StackableBlock.STACK_PROPERTY;
    private static final class_2746 ANIMATED = StackableBlock.ANIMATED;
    private static final class_2753 FACING = class_2741.field_12481;
    private final int maxStack;
    private static final class_265 SHAPE = class_2248.method_9541(2, 0, 2, 14, 10, 14);
    private final class_265[][] shapes;

    public StackableEatableBlock(class_2251 settings, int maxStack) {
        super(settings);
        this.maxStack = maxStack;
        this.shapes = null;
        this.method_9590(this.field_10647.method_11664().method_11657(STACK_PROPERTY, 1).method_11657(FACING, class_2350.field_11043).method_11657(ANIMATED, false));
    }

    public StackableEatableBlock(class_2251 settings, int maxStack, class_265... shapesNorthByStack) {
        super(settings);
        this.maxStack = maxStack;
        this.shapes = new class_265[shapesNorthByStack.length][4];
        for (int stack = 0; stack < shapesNorthByStack.length; stack++) {
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                this.shapes[stack][direction.method_10161()] = ShapeUtil.rotateShape(class_2350.field_11043, direction, shapesNorthByStack[stack]);
            }
        }
        this.method_9590(this.field_10647.method_11664().method_11657(STACK_PROPERTY, 1).method_11657(FACING, class_2350.field_11043).method_11657(ANIMATED, false));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (shapes == null || shapes.length == 0) {
            return SHAPE;
        }
        return shapes[class_3532.method_15340(state.method_11654(STACK_PROPERTY) - 1, 0, shapes.length - 1)][state.method_11654(FACING).method_10161()];
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(STACK_PROPERTY, FACING, ANIMATED);
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rot) {
        return state.method_11657(FACING, rot.method_10503(state.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153()).method_11657(ANIMATED, true);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        if (player.method_5715() && stack.method_7960()) {
            if (!world.field_9236) {
                if (state.method_11654(STACK_PROPERTY) > 1) {
                    world.method_8652(pos, state.method_11657(STACK_PROPERTY, state.method_11654(STACK_PROPERTY) - 1).method_11657(ANIMATED, true), class_2248.field_31036);
                } else {
                    world.method_8650(pos, false);
                }
                player.method_7344().method_7585(3, 0.6f);
                world.method_8396(null, pos, class_3417.field_20614, class_3419.field_15248, 1.0F, 1.0F);
            }
            if (world.field_9236) {
                for (int i = 0; i < 10; i++) {
                    double rx = world.field_9229.method_43058() - 0.5;
                    double ry = world.field_9229.method_43058();
                    double rz = world.field_9229.method_43058() - 0.5;
                    Vector3d velocity = new Vector3d(rx, ry, rz).mul(0.1);
                    world.method_8406(new class_2392(class_2398.field_11218, new class_1799(this.method_8389())),
                            pos.method_10263() + 0.5, pos.method_10264() + 0.7, pos.method_10260() + 0.5, velocity.x, velocity.y, velocity.z);
                }
            }
            return class_9062.method_55644(world.field_9236);
        } else if (stack.method_7909() == this.method_8389()) {
            if (state.method_11654(STACK_PROPERTY) < this.maxStack) {
                world.method_8652(pos, state.method_11657(STACK_PROPERTY, state.method_11654(STACK_PROPERTY) + 1).method_11657(ANIMATED, true), class_2248.field_31036);
                if (!player.method_7337()) {
                    stack.method_7934(1);
                }
                for (int i = 0; i < 8; i++) {
                    double angle = world.field_9229.method_43058() * Math.PI * 2;
                    double speed = 0.1 + world.field_9229.method_43058() * 0.1;
                    double dx = Math.cos(angle) * speed;
                    double dy = 0.05;
                    double dz = Math.sin(angle) * speed;
                    world.method_8406(new class_2388(class_2398.field_11217, state),
                            pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, dx, dy, dz);
                }
                return class_9062.field_47728;
            }
        } else if (stack.method_7960()) {
            if (state.method_11654(STACK_PROPERTY) > 1) {
                world.method_8652(pos, state.method_11657(STACK_PROPERTY, state.method_11654(STACK_PROPERTY) - 1).method_11657(ANIMATED, true), class_2248.field_31036);
            } else if (state.method_11654(STACK_PROPERTY) == 1) {
                world.method_22352(pos, false);
            }
            class_2350 direction = player.method_5735().method_10153();
            class_2248.method_36992(world, pos, direction, new class_1799(this));
            return class_9062.field_47728;
        }
        return super.method_55765(stack, state, world, pos, player, interactionHand, blockHitResult);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return state.method_11654(ANIMATED) ? class_2464.field_11456 : class_2464.field_11458;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return state.method_11654(ANIMATED) ? new StackBlockEntity(pos, state) : null;
    }
}
