package net.satisfy.foundation.recipe.book;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2371;

/** Moves recipe ingredients from the player inventory into the station input slots. */
public final class RecipePlacer {
    private RecipePlacer() {
    }

    /** True if the inventory plus whatever already sits in the input slots covers one craft. */
    public static boolean canCraft(class_1661 inventory, class_1703 menu, int[] inputSlots, class_2371<class_1856> ingredients) {
        if (ingredients.size() > inputSlots.length) {
            return false;
        }
        List<class_1799> pool = new ArrayList<>();
        for (class_1799 stack : inventory.field_7547) {
            pool.add(stack.method_7972());
        }
        for (int index : inputSlots) {
            pool.add(menu.method_7611(index).method_7677().method_7972());
        }
        for (class_1856 ingredient : ingredients) {
            if (ingredient.method_8103()) {
                continue;
            }
            class_1799 match = pool.stream().filter(stack -> !stack.method_7960() && ingredient.method_8093(stack)).findFirst().orElse(null);
            if (match == null) {
                return false;
            }
            match.method_7934(1);
        }
        return true;
    }

    /**
     * Server side. Puts the current inputs back, then fills one craft, or as many as fit when {@code max}.
     * Every round is all or nothing, so the inputs never end up half filled.
     */
    public static void place(class_1661 inventory, class_1703 menu, int[] inputSlots, class_2371<class_1856> ingredients, boolean max) {
        if (ingredients.size() > inputSlots.length) {
            return;
        }
        for (int index : inputSlots) {
            class_1735 slot = menu.method_7611(index);
            if (slot.method_7681()) {
                inventory.method_7398(slot.method_7677());
                slot.method_7673(class_1799.field_8037);
            }
        }
        int rounds = max ? 64 : 1;
        for (int round = 0; round < rounds; round++) {
            int[] sources = new int[ingredients.size()];
            int[] taken = new int[inventory.field_7547.size()];
            for (int i = 0; i < ingredients.size(); i++) {
                class_1856 ingredient = ingredients.get(i);
                sources[i] = -1;
                if (ingredient.method_8103()) {
                    continue;
                }
                class_1735 target = menu.method_7611(inputSlots[i]);
                class_1799 placed = target.method_7677();
                if (!placed.method_7960() && placed.method_7947() >= target.method_7676(placed)) {
                    return;
                }
                int source = findSource(inventory, ingredient, placed, taken);
                if (source < 0) {
                    return;
                }
                sources[i] = source;
                taken[source]++;
            }
            for (int i = 0; i < sources.length; i++) {
                if (sources[i] < 0) {
                    continue;
                }
                class_1735 target = menu.method_7611(inputSlots[i]);
                class_1799 moved = inventory.field_7547.get(sources[i]).method_7971(1);
                if (target.method_7681()) {
                    target.method_7677().method_7933(1);
                    target.method_7668();
                } else {
                    target.method_7673(moved);
                }
            }
        }
    }

    private static int findSource(class_1661 inventory, class_1856 ingredient, class_1799 placed, int[] taken) {
        for (int i = 0; i < inventory.field_7547.size(); i++) {
            class_1799 stack = inventory.field_7547.get(i);
            if (stack.method_7947() - taken[i] <= 0 || !ingredient.method_8093(stack)) {
                continue;
            }
            if (placed.method_7960() || class_1799.method_31577(placed, stack)) {
                return i;
            }
        }
        return -1;
    }
}
