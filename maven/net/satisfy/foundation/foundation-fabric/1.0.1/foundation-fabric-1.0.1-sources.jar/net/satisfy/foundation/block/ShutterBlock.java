package net.satisfy.foundation.block;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;

public class ShutterBlock extends class_2248 implements class_3737 {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2754<VerticalConnectingType> TYPE = class_2754.method_11850("type", VerticalConnectingType.class);
    public static final class_2746 LEFT = class_2746.method_11825("left");
    public static final class_2746 OPEN = class_2741.field_12537;
    public static final class_2746 POWERED = class_2741.field_12484;
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    private static final class_265[] SHAPES = {
            class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 3.0D),
            class_2248.method_9541(13.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D),
            class_2248.method_9541(0.0D, 0.0D, 13.0D, 16.0D, 16.0D, 16.0D),
            class_2248.method_9541(0.0D, 0.0D, 0.0D, 3.0D, 16.0D, 16.0D)
    };

    public ShutterBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(TYPE, VerticalConnectingType.NONE).method_11657(OPEN, false).method_11657(LEFT, false).method_11657(POWERED, false).method_11657(WATERLOGGED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, TYPE, OPEN, LEFT, POWERED, WATERLOGGED);
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        int index = state.method_11654(FACING).method_10161() + (state.method_11654(OPEN) ? (state.method_11654(LEFT) ? 3 : 1) : 0);
        return SHAPES[index % 4];
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8042().method_10153();
        class_1937 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_243 click = context.method_17698();

        boolean left = facing.method_10166() == class_2350.class_2351.field_11048 ? click.field_1350 - pos.method_10260() > 0.5D : click.field_1352 - pos.method_10263() > 0.5D;
        if (context.method_7715() == class_2350.field_11043 || context.method_7715() == class_2350.field_11034) {
            left = !left;
        }
        class_2680 state = method_9564().method_11657(FACING, facing).method_11657(LEFT, left);
        if (level.method_49803(pos)) {
            state = state.method_11657(OPEN, true).method_11657(POWERED, true);
        }
        state = state.method_11657(TYPE, getType(state, level.method_8320(pos.method_10084()), level.method_8320(pos.method_10074())));
        return state.method_11657(WATERLOGGED, level.method_8316(pos).method_15772() == class_3612.field_15910);
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        if (level.field_9236) {
            return;
        }
        class_2680 updated = state;
        boolean powered = level.method_49803(pos);
        if (powered != state.method_11654(POWERED)) {
            if (state.method_11654(OPEN) != powered) {
                updated = updated.method_11657(OPEN, powered);
                level.method_8396(null, pos, getSound(powered), class_3419.field_15245, 1.0F, 1.0F);
            }
            updated = updated.method_11657(POWERED, powered);
        }
        updated = updated.method_11657(TYPE, getType(updated, level.method_8320(pos.method_10084()), level.method_8320(pos.method_10074())));
        if (updated != state) {
            level.method_8652(pos, updated, 3);
        }
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        state = state.method_28493(OPEN);
        level.method_8652(pos, state, 3);
        if (!player.method_18276()) {
            toggleConnected(state, level, pos, state.method_11654(OPEN));
        }
        level.method_8396(null, pos, getSound(state.method_11654(OPEN)), class_3419.field_15245, 1.0F, 1.0F);
        return class_1269.method_29236(level.field_9236);
    }

    public void toggleConnected(class_2680 state, class_1937 level, class_2338 pos, boolean open) {
        VerticalConnectingType type = state.method_11654(TYPE);
        if (type == VerticalConnectingType.MIDDLE || type == VerticalConnectingType.BOTTOM) {
            toggleLine(state, level, pos, class_2350.field_11036, open);
        }
        if (type == VerticalConnectingType.MIDDLE || type == VerticalConnectingType.TOP) {
            toggleLine(state, level, pos, class_2350.field_11033, open);
        }
    }

    private void toggleLine(class_2680 state, class_1937 level, class_2338 pos, class_2350 direction, boolean open) {
        class_2338 current = pos.method_10093(direction);
        while (!level.method_31606(current)) {
            class_2680 other = level.method_8320(current);
            if (!other.method_27852(this) || other.method_11654(FACING) != state.method_11654(FACING) || other.method_11654(LEFT) != state.method_11654(LEFT) || other.method_11654(OPEN) == open) {
                return;
            }
            level.method_8652(current, other.method_11657(OPEN, open), 3);
            current = current.method_10093(direction);
        }
    }

    protected class_3414 getSound(boolean open) {
        return open ? class_3417.field_40063 : class_3417.field_40062;
    }

    public VerticalConnectingType getType(class_2680 state, class_2680 above, class_2680 below) {
        boolean aboveSame = isSameShutter(state, above);
        boolean belowSame = isSameShutter(state, below);
        if (aboveSame && belowSame) {
            return VerticalConnectingType.MIDDLE;
        }
        if (aboveSame) {
            return VerticalConnectingType.BOTTOM;
        }
        return belowSame ? VerticalConnectingType.TOP : VerticalConnectingType.NONE;
    }

    private boolean isSameShutter(class_2680 state, class_2680 other) {
        return other.method_27852(this) && other.method_11654(FACING) == state.method_11654(FACING) && other.method_11654(OPEN) == state.method_11654(OPEN) && other.method_11654(LEFT) == state.method_11654(LEFT);
    }

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    protected @NotNull class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    protected @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }
}
