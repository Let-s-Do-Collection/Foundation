package net.satisfy.foundation.block;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.satisfy.foundation.food.FoodBlock;
import net.satisfy.foundation.registry.FoundationBlockEntities;

public class StackBlockEntity extends class_2586 {
    private long wobbleStart = Long.MIN_VALUE / 2;

    public StackBlockEntity(class_2338 pos, class_2680 state) {
        super(FoundationBlockEntities.STACK.get(), pos, state);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_31664(class_2680 state) {
        class_2680 previous = method_11010();
        super.method_31664(state);
        if (field_11863 != null && field_11863.method_8608() && (changed(previous, state, StackableBlock.STACK_PROPERTY) || changed(previous, state, FoodBlock.BITES))) {
            wobbleStart = field_11863.method_8510();
        }
    }

    private static boolean changed(class_2680 previous, class_2680 state, class_2758 property) {
        return previous.method_28498(property) && state.method_28498(property) && !previous.method_11654(property).equals(state.method_11654(property));
    }

    public long getWobbleStart() {
        return wobbleStart;
    }
}
