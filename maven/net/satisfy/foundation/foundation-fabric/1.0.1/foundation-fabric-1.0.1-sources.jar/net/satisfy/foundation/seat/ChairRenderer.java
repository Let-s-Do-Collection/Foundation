package net.satisfy.foundation.seat;

import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import net.satisfy.foundation.seat.ChairEntity;

/** Renders nothing, the chair entity is invisible. */
public class ChairRenderer extends class_897<ChairEntity> {
    public ChairRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(ChairEntity entity, class_4604 frustum, double x, double y, double z) {
        return false;
    }

    @Override
    @SuppressWarnings("all")
    public class_2960 getTextureLocation(ChairEntity entity) {
        return null;
    }
}