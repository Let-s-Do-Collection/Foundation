package net.satisfy.foundation.menu;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import org.jetbrains.annotations.NotNull;

public class OutputSlot extends class_1735 {
    private final class_1657 player;
    private int removeCount;

    public OutputSlot(class_1657 player, class_1263 container, int index, int x, int y) {
        super(container, index, x, y);
        this.player = player;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public @NotNull class_1799 method_7671(int amount) {
        if (method_7681()) {
            removeCount += Math.min(amount, method_7677().method_7947());
        }
        return super.method_7671(amount);
    }

    @Override
    public void method_7667(class_1657 player, class_1799 stack) {
        method_7669(stack);
        super.method_7667(player, stack);
    }

    @Override
    protected void method_7678(class_1799 stack, int amount) {
        removeCount += amount;
        method_7669(stack);
    }

    @Override
    protected void method_7669(class_1799 stack) {
        stack.method_7982(player.method_37908(), player, removeCount);
        if (player.method_37908() instanceof class_3218 serverLevel && field_7871 instanceof ExperienceSource source) {
            source.dropExperience(serverLevel, player.method_19538());
        }
        removeCount = 0;
    }
}
