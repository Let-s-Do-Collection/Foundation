package net.satisfy.foundation.block;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.satisfy.foundation.text.TextEditableBlockEntity;
import org.jetbrains.annotations.NotNull;

public class WallDecorationBlockEntity extends class_2586 implements TextEditableBlockEntity {
    private static final int LINES = 3;

    private final class_2561[] text = {class_2561.method_43473(), class_2561.method_43473(), class_2561.method_43473()};
    private boolean glowing;

    public WallDecorationBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public class_2561 getText(int line) {
        return text[line];
    }

    @Override
    public void setText(int line, class_2561 component) {
        String value = component.getString();
        if (method_11010().method_26204() instanceof WallDecorationBlock block && value.length() > block.getMaxLength()) {
            value = value.substring(0, block.getMaxLength());
        }
        text[line] = class_2561.method_43470(value);
        sync();
    }

    @Override
    public int getTextLineCount() {
        return LINES;
    }

    public boolean isGlowing() {
        return glowing;
    }

    public void setGlowing(boolean glowing) {
        this.glowing = glowing;
        sync();
    }

    private void sync() {
        method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        glowing = tag.method_10577("Glowing");
        for (int i = 0; i < LINES; i++) {
            if (tag.method_10545("Text" + i)) {
                class_2561 component = class_2561.class_2562.method_10877(tag.method_10558("Text" + i), provider);
                text[i] = component != null ? component : class_2561.method_43473();
            }
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        tag.method_10556("Glowing", glowing);
        for (int i = 0; i < LINES; i++) {
            tag.method_10582("Text" + i, class_2561.class_2562.method_10867(text[i], provider));
        }
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 provider) {
        return method_38244(provider);
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
}
