package net.satisfy.foundation.registry;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.satisfy.foundation.Foundation;

/** Tags used by the lib, fill them via datapack from your mod. */
public final class FoundationTags {
    public static final class_6862<class_1792> CAKE_CUTTERS = class_6862.method_40092(class_7924.field_41197, Foundation.identifier("cake_cutters"));
    public static final class_6862<class_2248> ATTRACTS_FIREFLIES = class_6862.method_40092(class_7924.field_41254, Foundation.identifier("attracts_fireflies"));

    private FoundationTags() {
    }
}
