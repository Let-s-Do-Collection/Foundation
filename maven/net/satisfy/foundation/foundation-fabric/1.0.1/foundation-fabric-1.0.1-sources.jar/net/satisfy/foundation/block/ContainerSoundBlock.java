package net.satisfy.foundation.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;

public interface ContainerSoundBlock {
    void playSound(class_1937 level, class_2338 pos, boolean open);
}
