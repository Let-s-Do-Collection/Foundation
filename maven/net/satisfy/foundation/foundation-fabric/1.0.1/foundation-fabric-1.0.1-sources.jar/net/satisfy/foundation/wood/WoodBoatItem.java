package net.satisfy.foundation.wood;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1301;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1749;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3468;
import net.minecraft.class_3959;
import net.minecraft.class_5712;

public class WoodBoatItem extends class_1749 {
    private static final Predicate<class_1297> ENTITY_PREDICATE = class_1301.field_6155.and(class_1297::method_5863);
    private final Supplier<? extends class_1299<? extends WoodBoat>> entityType;
    private final class_2960 wood;

    public WoodBoatItem(Supplier<? extends class_1299<? extends WoodBoat>> entityType, class_2960 wood, class_1793 properties) {
        super(false, class_1690.class_1692.field_7727, properties);
        this.entityType = entityType;
        this.wood = wood;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_239 hit = method_7872(level, player, class_3959.class_242.field_1347);
        if (hit.method_17783() != class_239.class_240.field_1332) {
            return class_1271.method_22430(stack);
        }

        class_243 view = player.method_5828(1.0F);
        List<class_1297> entities = level.method_8333(player, player.method_5829().method_18804(view.method_1021(5.0D)).method_1014(1.0D), ENTITY_PREDICATE);
        class_243 eyes = player.method_33571();
        for (class_1297 entity : entities) {
            class_238 box = entity.method_5829().method_1014(entity.method_5871());
            if (box.method_1006(eyes)) {
                return class_1271.method_22430(stack);
            }
        }

        WoodBoat boat = entityType.get().method_5883(level);
        if (boat == null) {
            return class_1271.method_22431(stack);
        }
        class_243 location = hit.method_17784();
        boat.method_5808(location.field_1352, location.field_1351, location.field_1350, player.method_36454(), 0.0F);
        boat.setWood(Objects.requireNonNull(BoatWood.get(wood), () -> "Unknown boat wood " + wood));
        if (!level.method_8587(boat, boat.method_5829())) {
            return class_1271.method_22431(stack);
        }

        if (!level.field_9236) {
            level.method_8649(boat);
            level.method_43275(player, class_5712.field_28738, location);
            stack.method_57008(1, player);
        }
        player.method_7259(class_3468.field_15372.method_14956(this));
        return class_1271.method_29237(stack, level.method_8608());
    }
}
