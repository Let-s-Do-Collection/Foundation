package net.satisfy.foundation.storage;

import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2371;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.satisfy.foundation.storage.StorageBlock;
import net.satisfy.foundation.storage.StorageBlockEntity;

import java.util.HashMap;

/** Generic renderer for all storage blocks, delegates to the registered {@link StorageTypeRenderer}. */
public class StorageBlockEntityRenderer implements class_827<StorageBlockEntity> {
    private static final HashMap<class_2960, StorageTypeRenderer> STORAGE_TYPES = new HashMap<>();

    /** Register your renderer client side, the id must match {@link StorageBlock#type()}. */
    public static void  registerStorageType(class_2960 name, StorageTypeRenderer renderer) {
        STORAGE_TYPES.put(name, renderer);
    }

    public static StorageTypeRenderer getRendererForId(class_2960 name) {
        return STORAGE_TYPES.get(name);
    }

    public StorageBlockEntityRenderer() {
    }

    public void render(StorageBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        if (entity.method_11002()) {
            class_2680 state = entity.method_11010();
            class_2248 var9 = state.method_26204();
            if (var9 instanceof StorageBlock sB) {
                class_2371<class_1799> itemStacks = entity.getInventory();
                matrices.method_22903();
                applyBlockAngle(matrices, state, 180.0F);
                class_2960 type = sB.type();
                StorageTypeRenderer renderer = getRendererForId(type);
                if (renderer != null) {
                    renderer.render(entity, matrices, vertexConsumers, itemStacks);
                }

                matrices.method_22909();
            }

        }
    }

    /** Rotates the pose stack to the block facing. */
    public static void applyBlockAngle(class_4587 matrices, class_2680 state, float angleOffset) {
        float angle = state.method_11654(StorageBlock.field_11177).method_10144();
        matrices.method_22904(0.5, 0.0, 0.5);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(angleOffset - angle));
    }
}