package net.satisfy.foundation.food;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.satisfy.foundation.food.IngredientEffects;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Stores the ingredient effects of a placed food. Hunger gets filtered out,
 * nobody wants that.
 */
public class IngredientEffectFoodBlockEntity extends class_2586 {
    public static final String STORED_EFFECTS_KEY = "StoredEffects";
    private List<Pair<class_1293, Float>> effects;

    public IngredientEffectFoodBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public void addEffects(List<Pair<class_1293, Float>> effects) {
        this.effects = effects.stream()
                .filter(p -> p.getFirst().method_5579() != class_1294.field_5903)
                .collect(Collectors.toList());
    }

    public List<Pair<class_1293, Float>> getEffects() {
        return effects != null ? effects : Collections.emptyList();
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        this.effects = IngredientEffects.fromNbt(tag.method_10554(STORED_EFFECTS_KEY, 10));
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        if (effects == null) return;
        class_2499 list = new class_2499();
        for (Pair<class_1293, Float> effect : effects) {
            list.add(IngredientEffects.createNbt((short) class_7923.field_41174.method_40295().method_10206(effect.getFirst().method_5579()), effect));
        }
        tag.method_10566(STORED_EFFECTS_KEY, list);
    }
}
