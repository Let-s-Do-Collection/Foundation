package net.satisfy.foundation.overlay;

import java.util.List;
import dev.architectury.networking.NetworkManager;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.satisfy.foundation.Foundation;
import org.jetbrains.annotations.NotNull;

public final class BlockNotice {
    private BlockNotice() {
    }

    public record Packet(class_2338 pos, class_2561 message, List<class_2561> lines) implements class_8710 {
        public static final class_9154<Packet> TYPE = new class_9154<>(Foundation.identifier("block_notice"));
        public static final class_9139<class_9129, Packet> CODEC = class_9139.method_56436(
                class_2338.field_48404, Packet::pos,
                class_8824.field_48540, Packet::message,
                class_8824.field_48540.method_56433(class_9135.method_56363()), Packet::lines,
                Packet::new);

        @Override
        public @NotNull class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public static void init() {
        if (Platform.getEnvironment() == Env.CLIENT) {
            NetworkManager.registerReceiver(NetworkManager.s2c(), Packet.TYPE, Packet.CODEC, (packet, context) -> context.queue(() -> BlockInfoOverlay.showNotice(packet.pos(), packet.message(), packet.lines())));
        } else {
            NetworkManager.registerS2CPayloadType(Packet.TYPE, Packet.CODEC);
        }
    }

    public static void send(class_3222 player, class_2338 pos, class_2561 message) {
        send(player, pos, message, List.of());
    }

    public static void send(class_3222 player, class_2338 pos, class_2561 title, List<class_2561> lines) {
        NetworkManager.sendToPlayer(player, new Packet(pos, title, lines));
    }
}
