package net.satisfy.foundation.food;

import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4174;
import net.minecraft.class_5712;
import net.minecraft.class_9334;
import net.satisfy.foundation.block.FacingBlock;
import net.satisfy.foundation.block.StackBlockEntity;
import net.satisfy.foundation.block.StackableBlock;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;

/**
 * Placeable food (only when sneaking). Each click eats one bite until
 * {@code maxBites} is reached, then it is gone.
 */
public class FoodBlock extends FacingBlock implements class_2343 {
    public static final class_2753 FACING;
    public static final class_2758 BITES;
    public static final class_2746 ANIMATED = StackableBlock.ANIMATED;
    private final int maxBites;
    private final class_4174 foodComponent;
    private final class_265 SHAPE = class_259.method_1081(0.1875, 0, 0.1875, 0.8125, 0.875, 0.8125);
    private final class_265[][] shapes;

    public FoodBlock(class_2251 settings, int maxBites, class_4174 foodComponent) {
        super(settings);
        this.maxBites = maxBites;
        this.foodComponent = foodComponent;
        this.shapes = null;
        method_9590(this.method_9564().method_11657(BITES, 0).method_11657(field_11177, class_2350.field_11043).method_11657(ANIMATED, false));
    }

    public FoodBlock(class_2251 settings, int maxBites, class_4174 foodComponent, class_265... shapesNorthByBites) {
        super(settings);
        this.maxBites = maxBites;
        this.foodComponent = foodComponent;
        this.shapes = new class_265[shapesNorthByBites.length][4];
        for (int bites = 0; bites < shapesNorthByBites.length; bites++) {
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                this.shapes[bites][direction.method_10161()] = ShapeUtil.rotateShape(class_2350.field_11043, direction, shapesNorthByBites[bites]);
            }
        }
        method_9590(this.method_9564().method_11657(BITES, 0).method_11657(field_11177, class_2350.field_11043).method_11657(ANIMATED, false));
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        if (!Objects.requireNonNull(ctx.method_8036()).method_5715()) {
            return null;
        }
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153()).method_11657(ANIMATED, true);
    }

    @Override
    public @NotNull class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_21466;
        }
        return tryEat(world, pos, state, player);
    }

    private class_1269 tryEat(class_1936 world, class_2338 pos, class_2680 state, class_1657 player) {
        class_1799 stack = new class_1799(method_8389());
        class_4174 fp = stack.method_57824(class_9334.field_50075);
        if (fp == null) fp = this.foodComponent;

        player.method_7344().method_7585(fp.comp_2491(), fp.comp_2492());

        if (world instanceof class_1937 level) {
            for (class_4174.class_9423 effect : fp.comp_2495()) {
                if (effect.comp_2497() >= 1.0F || level.field_9229.method_43057() < effect.comp_2497()) {
                    player.method_6092(new class_1293(effect.comp_2496()));
                }
            }
        }

        world.method_8396(null, pos, class_3417.field_20614, class_3419.field_15248, 0.5f, world.method_8409().method_43057() * 0.1f + 0.9f);
        world.method_33596(player, class_5712.field_28735, pos);

        if (world instanceof class_1937 level) {
            for (int i = 0; i < 10; ++i) {
                double dx = level.field_9229.method_43059() * 0.02D;
                double dy = level.field_9229.method_43059() * 0.02D;
                double dz = level.field_9229.method_43059() * 0.02D;
                level.method_8406(new class_2388(class_2398.field_11217, state), pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, dx, dy, dz);
            }
        }

        int bites = state.method_11654(BITES);
        if (bites < maxBites - 1) {
            world.method_8652(pos, state.method_11657(BITES, bites + 1).method_11657(ANIMATED, true), 3);
        } else {
            world.method_22352(pos, false);
            world.method_33596(player, class_5712.field_28165, pos);
        }

        return class_1269.field_5812;
    }

    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, BITES, ANIMATED);
    }

    static {
        field_11177 = class_2741.field_12481;
        BITES = class_2758.method_11867("bites", 0, 9);
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (shapes == null || shapes.length == 0) {
            return SHAPE;
        }
        return shapes[Math.min(state.method_11654(BITES), shapes.length - 1)][state.method_11654(field_11177).method_10161()];
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return state.method_11654(ANIMATED) ? class_2464.field_11456 : class_2464.field_11458;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return state.method_11654(ANIMATED) ? new StackBlockEntity(pos, state) : null;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    public void method_9568(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        list.add(class_2561.method_43471("tooltip.foundation.canbeplaced").method_27692(class_124.field_1080));
    }
}
