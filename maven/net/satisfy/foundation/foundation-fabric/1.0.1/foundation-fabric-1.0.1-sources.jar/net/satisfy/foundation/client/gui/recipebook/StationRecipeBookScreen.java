package net.satisfy.foundation.client.gui.recipebook;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_8666;
import net.satisfy.foundation.recipe.book.StationRecipeBookMenu;

/**
 * Container screen with the green recipe book button, like the crafting table.
 * Extend it instead of {@link net.minecraft.class_465}
 * and the book works without any further calls.
 */
public abstract class StationRecipeBookScreen<M extends class_1703 & StationRecipeBookMenu> extends net.minecraft.class_465<M> {
    private static final class_8666 BUTTON_SPRITES = new class_8666(
            class_2960.method_60656("recipe_book/button"),
            class_2960.method_60656("recipe_book/button_highlighted"));

    protected final StationRecipeBook recipeBook = new StationRecipeBook();
    private class_344 recipeBookButton;

    protected StationRecipeBookScreen(M menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        recipeBook.init(field_22789, field_22790, field_22787, field_2797);
        field_2776 = recipeBook.updateScreenPosition(field_22789, field_2792);
        recipeBookButton = method_37063(new class_344(field_2776 + recipeBookButtonX(), field_2800 + recipeBookButtonY(), 20, 18, BUTTON_SPRITES, button -> {
            recipeBook.toggle();
            field_2776 = recipeBook.updateScreenPosition(field_22789, field_2792);
            button.method_48229(field_2776 + recipeBookButtonX(), field_2800 + recipeBookButtonY());
        }));
    }

    /** Button position relative to the screen, vanilla crafting table spot by default. */
    protected int recipeBookButtonX() {
        return 5;
    }

    protected int recipeBookButtonY() {
        return field_2779 / 2 - 49;
    }

    @Override
    protected void method_37432() {
        super.method_37432();
        recipeBook.tick();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        recipeBook.renderGhost(graphics, field_2776, field_2800, partialTick);
        recipeBook.render(graphics, mouseX, mouseY, partialTick);
        recipeBook.renderTooltip(graphics, mouseX, mouseY);
        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (recipeBook.mouseClicked(mouseX, mouseY, button)) {
            method_25395(null);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return recipeBook.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return recipeBook.charTyped(codePoint, modifiers) || super.method_25400(codePoint, modifiers);
    }

    @Override
    protected boolean method_2378(int x, int y, int width, int height, double mouseX, double mouseY) {
        return !recipeBook.isMouseOver(mouseX, mouseY) && super.method_2378(x, y, width, height, mouseX, mouseY);
    }

    @Override
    protected boolean method_2381(double mouseX, double mouseY, int guiLeft, int guiTop, int mouseButton) {
        return super.method_2381(mouseX, mouseY, guiLeft, guiTop, mouseButton) && !recipeBook.isMouseOver(mouseX, mouseY);
    }

    @Override
    protected void method_2383(class_1735 slot, int slotId, int mouseButton, class_1713 type) {
        super.method_2383(slot, slotId, mouseButton, type);
        recipeBook.clearGhost();
    }
}
