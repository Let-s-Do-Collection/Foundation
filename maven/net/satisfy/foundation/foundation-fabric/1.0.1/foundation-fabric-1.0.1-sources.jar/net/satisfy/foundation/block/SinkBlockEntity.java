package net.satisfy.foundation.block;

import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7225;
import net.satisfy.foundation.registry.FoundationBlockEntities;

public class SinkBlockEntity extends class_2586 {
    public static final int MAX_LEVEL = 3;
    public static final int FILL_TICKS = 60;
    public static final int TURN_TICKS = 8;

    private int waterLevel;
    private boolean open;
    private long toggleTime = -100;
    private int fillTicks;

    public SinkBlockEntity(class_2338 pos, class_2680 state) {
        super(FoundationBlockEntities.SINK.get(), pos, state);
    }

    public static void serverTick(class_1937 level, class_2338 pos, class_2680 state, SinkBlockEntity sink) {
        if (state.method_11654(SinkBlock.FILLED)) {
            sink.waterLevel = MAX_LEVEL;
            level.method_8652(pos, state.method_11657(SinkBlock.FILLED, false), class_2248.field_31036);
            sink.sync();
        }
        if (!sink.open || sink.waterLevel >= MAX_LEVEL) {
            return;
        }
        if (++sink.fillTicks >= FILL_TICKS) {
            sink.fillTicks = 0;
            sink.waterLevel++;
            level.method_8396(null, pos, class_3417.field_14834, class_3419.field_15245, 0.25F, 1.4F);
            sink.sync();
        }
    }

    public void toggle() {
        if (field_11863 == null) {
            return;
        }
        open = !open;
        toggleTime = field_11863.method_8510();
        fillTicks = 0;
        field_11863.method_8396(null, field_11867.method_10084(), class_3417.field_14962, class_3419.field_15245, 0.4F, open ? 1.2F : 0.9F);
        sync();
    }

    public int getWaterLevel() {
        return waterLevel;
    }

    public void setWaterLevel(int waterLevel) {
        this.waterLevel = Math.max(0, Math.min(MAX_LEVEL, waterLevel));
        sync();
    }

    public boolean isOpen() {
        return open;
    }

    public long getToggleTime() {
        return toggleTime;
    }

    private void sync() {
        method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31028);
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        waterLevel = tag.method_10550("WaterLevel");
        open = tag.method_10577("Open");
        toggleTime = tag.method_10545("ToggleTime") ? tag.method_10537("ToggleTime") : -100;
        fillTicks = tag.method_10550("FillTicks");
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        tag.method_10569("WaterLevel", waterLevel);
        tag.method_10556("Open", open);
        tag.method_10544("ToggleTime", toggleTime);
        tag.method_10569("FillTicks", fillTicks);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 provider) {
        class_2487 tag = super.method_16887(provider);
        method_11007(tag, provider);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
}
