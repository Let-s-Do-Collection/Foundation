package net.satisfy.foundation.client.render;

import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public final class WobbleAnimation {
    public static final int DURATION = 10;
    private static final float MAX_ANGLE = 4.0F;
    private static final float SWINGS = 2.5F;

    private WobbleAnimation() {
    }

    public static boolean isActive(class_1937 level, long startTime) {
        return level != null && level.method_8510() - startTime < DURATION;
    }

    public static void apply(class_4587 poseStack, class_1937 level, long startTime, float seed) {
        apply(poseStack, level, startTime, class_310.method_1551().method_60646().method_60637(false), seed);
    }

    public static void apply(class_4587 poseStack, class_1937 level, long startTime, float partialTick, float seed) {
        apply(poseStack, level, startTime, partialTick, seed, 1.0F);
    }

    public static void apply(class_4587 poseStack, class_1937 level, long startTime, float partialTick, float seed, float strength) {
        if (!isActive(level, startTime)) {
            return;
        }
        float swing = angle(level, startTime, partialTick) * strength;
        float direction = seed * class_3532.field_29846;
        poseStack.method_46416(0.5F, 0.0F, 0.5F);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(swing * class_3532.method_15362(direction)));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(swing * class_3532.method_15374(direction)));
        poseStack.method_46416(-0.5F, 0.0F, -0.5F);
    }

    public static float angle(class_1937 level, long startTime, float partialTick) {
        if (!isActive(level, startTime)) {
            return 0.0F;
        }
        float progress = class_3532.method_15363((level.method_8510() - startTime + partialTick) / DURATION, 0.0F, 1.0F);
        float damping = (1.0F - progress) * (1.0F - progress);
        return class_3532.method_15374(progress * SWINGS * class_3532.field_29846) * MAX_ANGLE * damping;
    }

    public static float seed(long value) {
        return (class_3532.method_15354((int) (value ^ (value >>> 32))) & 0xFFFF) / 65535.0F;
    }
}
