package net.satisfy.foundation.armor;

import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import org.jetbrains.annotations.NotNull;

public class TexturedArmorItem extends class_1738 {
    private final class_2960 texture;

    public TexturedArmorItem(class_6880<class_1741> material, class_8051 type, class_1793 properties, class_2960 texture) {
        super(material, type, properties);
        this.texture = texture;
    }

    public class_2960 getTexture() {
        return texture;
    }

    @Override
    public @NotNull class_1304 method_7685() {
        return field_41933.method_48399();
    }
}
