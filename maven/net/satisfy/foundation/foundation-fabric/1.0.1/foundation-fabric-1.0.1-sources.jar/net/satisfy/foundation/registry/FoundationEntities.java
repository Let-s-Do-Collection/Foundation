package net.satisfy.foundation.registry;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_7924;
import net.satisfy.foundation.Foundation;
import net.satisfy.foundation.seat.ChairEntity;

/** Entity types of the lib. Only the invisible chair seat for now. */
public final class FoundationEntities {
    private static final DeferredRegister<class_1299<?>> ENTITY_TYPES = DeferredRegister.create(Foundation.MOD_ID, class_7924.field_41266);

    public static final RegistrySupplier<class_1299<ChairEntity>> CHAIR = ENTITY_TYPES.register("chair", () -> class_1299.class_1300.method_5903(ChairEntity::new, class_1311.field_17715).method_17687(0.001F, 0.001F).method_5905(Foundation.identifier("chair").toString()));

    private FoundationEntities() {
    }

    public static void init() {
        ENTITY_TYPES.register();
    }
}
