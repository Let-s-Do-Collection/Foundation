package net.satisfy.foundation.block;

import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4174;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import net.minecraft.class_9334;
import net.satisfy.foundation.registry.FoundationTags;

import java.util.function.Supplier;

/**
 * Cake with 4 pieces. Cut it with anything in {@code foundation:cake_cutters} to get
 * a slice item, or sneak + empty hand to eat a piece directly. Empty hand on a
 * untouched cake picks it up again.
 */
public class SliceableCakeBlock extends class_2248 {
    public static final int MAX_CUTS = 3;
    public static final class_2758 CUTS = class_2758.method_11867("cuts", 0, MAX_CUTS);
    public static final class_2753 FACING = class_2383.field_11177;
    private static final double HEIGHT = 5;
    private static final double[][] QUARTERS_NORTH = {{2, 2, 8, 8}, {8, 2, 14, 8}, {2, 8, 8, 14}, {8, 8, 14, 14}};

    private final Supplier<? extends class_1935> slice;

    /** @param slice the slice item, its food component is also used when eating from the block */
    public SliceableCakeBlock(class_2251 properties, Supplier<? extends class_1935> slice) {
        super(properties);
        this.slice = slice;
        method_9590(field_10647.method_11664().method_11657(CUTS, 0).method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(CUTS, FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        class_265 shape = class_259.method_1073();
        int turns = state.method_11654(FACING).method_10161() - class_2350.field_11043.method_10161();
        for (int i = state.method_11654(CUTS); i < QUARTERS_NORTH.length; i++) {
            double[] quarter = QUARTERS_NORTH[i];
            double minX = quarter[0];
            double minZ = quarter[1];
            double maxX = quarter[2];
            double maxZ = quarter[3];
            for (int turn = 0; turn < Math.floorMod(turns, 4); turn++) {
                double rotatedMinX = 16 - maxZ;
                double rotatedMaxX = 16 - minZ;
                minZ = minX;
                maxZ = maxX;
                minX = rotatedMinX;
                maxX = rotatedMaxX;
            }
            shape = class_259.method_1084(shape, class_2248.method_9541(minX, 0, minZ, maxX, HEIGHT, maxZ));
        }
        return shape;
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (player.method_5715() && stack.method_7960()) {
            return eat(level, pos, state, player);
        }
        if (stack.method_31573(FoundationTags.CAKE_CUTTERS)) {
            if (!level.field_9236) {
                removePiece(level, pos, state);
                drop(level, pos, player, new class_1799(slice.get()));
                level.method_8396(null, pos, class_3417.field_14983, class_3419.field_15248, 0.75F, 1.2F);
            }
            return class_9062.method_55644(level.field_9236);
        }
        if (stack.method_7960() && state.method_11654(CUTS) == 0) {
            if (!level.field_9236) {
                level.method_8650(pos, false);
                drop(level, pos, player, new class_1799(this));
            }
            return class_9062.method_55644(level.field_9236);
        }
        return class_9062.field_47731;
    }

    private class_9062 eat(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (!player.method_7332(false)) {
            return class_9062.field_47731;
        }
        if (!level.field_9236) {
            class_4174 food = new class_1799(slice.get()).method_57824(class_9334.field_50075);
            if (food != null) {
                player.method_7344().method_7585(food.comp_2491(), food.comp_2492());
                food.comp_2495().forEach(effect -> player.method_6092(new class_1293(effect.comp_2496())));
            }
            removePiece(level, pos, state);
            level.method_8396(null, pos, class_3417.field_20614, class_3419.field_15248, 0.8F, 0.8F);
        }
        return class_9062.method_55644(level.field_9236);
    }

    private static void removePiece(class_1937 level, class_2338 pos, class_2680 state) {
        int cuts = state.method_11654(CUTS);
        if (cuts < MAX_CUTS) {
            level.method_8652(pos, state.method_11657(CUTS, cuts + 1), class_2248.field_31036);
        } else {
            level.method_8650(pos, false);
        }
    }

    private static void drop(class_1937 level, class_2338 pos, class_1657 player, class_1799 stack) {
        class_2350 direction = player.method_5735().method_10153();
        class_1542 item = new class_1542(level, pos.method_10263() + 0.5, pos.method_10264() + 0.4, pos.method_10260() + 0.5, stack, direction.method_10148() * 0.13, 0.35, direction.method_10165() * 0.13);
        level.method_8649(item);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighbor, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return direction == class_2350.field_11033 && !state.method_26184(level, pos) ? class_2246.field_10124.method_9564() : super.method_9559(state, direction, neighbor, level, pos, neighborPos);
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return level.method_8320(pos.method_10074()).method_51367();
    }
}
