package net.satisfy.foundation.block;

import net.minecraft.class_1767;
import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public enum ClothColor implements class_3542 {
    NONE(null),
    WHITE(class_1767.field_7952),
    ORANGE(class_1767.field_7946),
    MAGENTA(class_1767.field_7958),
    LIGHT_BLUE(class_1767.field_7951),
    YELLOW(class_1767.field_7947),
    LIME(class_1767.field_7961),
    PINK(class_1767.field_7954),
    GRAY(class_1767.field_7944),
    LIGHT_GRAY(class_1767.field_7967),
    CYAN(class_1767.field_7955),
    PURPLE(class_1767.field_7945),
    BLUE(class_1767.field_7966),
    BROWN(class_1767.field_7957),
    GREEN(class_1767.field_7942),
    RED(class_1767.field_7964),
    BLACK(class_1767.field_7963);

    @Nullable
    private final class_1767 color;

    ClothColor(@Nullable class_1767 color) {
        this.color = color;
    }

    @Nullable
    public class_1767 color() {
        return color;
    }

    public int tint() {
        return color == null ? 0xFFFFFFFF : color.method_7787();
    }

    public static ClothColor of(class_1767 color) {
        for (ClothColor cloth : values()) {
            if (cloth.color == color) return cloth;
        }
        return NONE;
    }

    @Override
    public @NotNull String method_15434() {
        return color == null ? "none" : color.method_15434();
    }
}
