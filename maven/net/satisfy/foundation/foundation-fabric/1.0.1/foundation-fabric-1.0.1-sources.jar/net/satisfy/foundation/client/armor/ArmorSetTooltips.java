package net.satisfy.foundation.client.armor;

import dev.architectury.event.events.client.ClientTooltipEvent;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.satisfy.foundation.armor.ArmorSet;
import net.satisfy.foundation.armor.ArmorSets;
import net.satisfy.foundation.armor.Wearing;

import java.util.List;

public final class ArmorSetTooltips {
    private static boolean initialized;

    private ArmorSetTooltips() {
    }

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        ClientTooltipEvent.ITEM.register((stack, tooltip, context, flag) -> ArmorSets.find(stack.method_7909())
                .filter(ArmorSet::isTooltipVisible)
                .ifPresent(set -> append(set, tooltip)));
    }

    private static void append(ArmorSet set, List<class_2561> tooltip) {
        class_1657 player = class_310.method_1551().field_1724;
        List<List<class_1792>> pieces = set.pieces();
        int worn = player == null ? 0 : set.wornPieces(player);
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43471(set.nameKey()).method_27693(" (" + worn + "/" + pieces.size() + ")").method_27692(class_124.field_1075));
        for (List<class_1792> piece : pieces) {
            boolean pieceWorn = player != null && Wearing.isWearingAny(player, piece);
            tooltip.add(class_2561.method_43470("- [").method_10852(name(piece)).method_27693("]").method_27692(pieceWorn ? class_124.field_1060 : class_124.field_1080));
        }
        if (set.bonusKey() != null) {
            boolean active = player != null && set.isBonusActive(player);
            tooltip.add(class_2561.method_43473());
            tooltip.add(class_2561.method_43471("tooltip.foundation.set_bonus").method_27692(class_124.field_1080));
            tooltip.add(class_2561.method_43471(set.bonusKey()).method_27692(active ? class_124.field_1077 : class_124.field_1080));
        }
    }

    private static class_2561 name(List<class_1792> piece) {
        class_5250 name = class_2561.method_43473();
        for (int i = 0; i < piece.size(); i++) {
            if (i > 0) name.method_27693(" / ");
            name.method_10852(piece.get(i).method_7848());
        }
        return name;
    }
}
