package net.satisfy.foundation.seat;

import com.mojang.datafixers.util.Pair;
import net.satisfy.foundation.seat.ChairEntity;
import net.satisfy.foundation.registry.FoundationEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import java.util.*;

/**
 * Everything around sitting on blocks. Keeps track of chair entities per
 * dimension and pos (server side only).
 */
public final class SeatUtil {
    private SeatUtil() {
    }

    private static final Map<class_2960, Map<class_2338, Pair<ChairEntity, class_2338>>> CHAIRS = new HashMap<>();

    public static class_2338 getPreviousPlayerPosition(class_1657 player, ChairEntity chairEntity) {
        if (!player.method_37908().method_8608()) {
            class_2960 id = getDimensionTypeId(player.method_37908());
            if (CHAIRS.containsKey(id)) {
                Iterator var3 = ((Map)CHAIRS.get(id)).values().iterator();

                while(var3.hasNext()) {
                    Pair<ChairEntity, class_2338> pair = (Pair)var3.next();
                    if (pair.getFirst() == chairEntity) {
                        return (class_2338)pair.getSecond();
                    }
                }
            }
        }

        return null;
    }

    /**
     * Call from {@code useItemOn} of your seat block. Needs an empty hand, no sneaking.
     *
     * @param extraHeight added to the default seat height of 0.25
     */
    public static class_9062 onUse(class_1937 world, class_1657 player, class_1268 hand, class_3965 hit, double extraHeight) {
        if (world.field_9236) return class_9062.field_47731;
        if (player.method_5715()) return class_9062.field_47731;
        if (isPlayerSitting(player)) return class_9062.field_47731;
        if (hit.method_17780() == class_2350.field_11033) return class_9062.field_47731;
        class_2338 hitPos = hit.method_17777();
        if (!isOccupied(world, hitPos) && player.method_5998(hand).method_7960()) {
            ChairEntity chair = FoundationEntities.CHAIR.get().method_5883(world);
            assert chair != null;
            chair.method_5808(hitPos.method_10263() + 0.5D, hitPos.method_10264() + 0.25D + extraHeight, hitPos.method_10260() + 0.5D, 0, 0);
            if (addChairEntity(world, hitPos, chair, player.method_24515())) {
                world.method_8649(chair);
                player.method_5804(chair);
                return class_9062.field_47728;
            }
        }
        return class_9062.field_47731;
    }

    public static boolean isOccupied(class_1937 world, class_2338 pos) {
        class_2960 id = getDimensionTypeId(world);
        return CHAIRS.containsKey(id) && CHAIRS.get(id).containsKey(pos);
    }

    public static boolean isPlayerSitting(class_1657 player) {
        for (class_2960 i : CHAIRS.keySet()) {
            for (Pair<ChairEntity, class_2338> pair : CHAIRS.get(i).values()) {
                if (pair.getFirst().method_5626(player))
                    return true;
            }
        }
        return false;
    }

    private static class_2960 getDimensionTypeId(class_1937 world) {
        return world.method_27983().method_29177();
    }

    /** Call from {@code onRemove}, kicks the player off when the block is gone. */
    public static void onStateReplaced(class_1937 world, class_2338 pos) {
        if (!world.field_9236) {
            ChairEntity entity = getChairEntity(world, pos);
            if (entity != null) {
                removeChairEntity(world, pos);
                entity.method_5772();
            }
        }
    }

    public static boolean addChairEntity(class_1937 world, class_2338 blockPos, ChairEntity entity, class_2338 playerPos) {
        if (!world.field_9236) {
            class_2960 id = getDimensionTypeId(world);
            if (!CHAIRS.containsKey(id)) CHAIRS.put(id, new HashMap<>());
            CHAIRS.get(id).put(blockPos, Pair.of(entity, playerPos));
            return true;
        }
        return false;
    }

    public static void removeChairEntity(class_1937 world, class_2338 pos) {
        if (!world.field_9236) {
            class_2960 id = getDimensionTypeId(world);
            if (CHAIRS.containsKey(id)) {
                CHAIRS.get(id).remove(pos);
            }
        }
    }

    public static ChairEntity getChairEntity(class_1937 world, class_2338 pos) {
        if (!world.method_8608()) {
            class_2960 id = getDimensionTypeId(world);
            if (CHAIRS.containsKey(id) && CHAIRS.get(id).containsKey(pos))
                return CHAIRS.get(id).get(pos).getFirst();
        }
        return null;
    }
}
