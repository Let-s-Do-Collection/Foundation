package net.satisfy.foundation.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2383;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_4970;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Plain horizontal facing block, faces the player on placement. Nothing fancy. */
public class FacingBlock extends class_2383 {

    public static final MapCodec<FacingBlock> field_46280 = method_54094(FacingBlock::new);

    public FacingBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    protected @NotNull MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    public @Nullable class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}