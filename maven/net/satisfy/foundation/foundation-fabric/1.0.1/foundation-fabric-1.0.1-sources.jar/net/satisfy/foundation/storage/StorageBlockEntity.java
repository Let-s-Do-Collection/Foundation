package net.satisfy.foundation.storage;

import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3829;
import net.minecraft.class_7225;
import net.satisfy.foundation.util.LibUtil;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

/** Inventory holder for {@link StorageBlock}. Syncs to tracking players on every change. */
public class StorageBlockEntity extends class_2586 implements class_3829 {
    private int size;
    private class_2371<class_1799> inventory;
    private long wobbleStart = Long.MIN_VALUE / 2;
    private long[] slotWobbleStart = new long[0];

    public StorageBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public StorageBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state, int size) {
        super(type, pos, state);
        this.size = size;
        this.inventory = class_2371.method_10213(this.size, class_1799.field_8037);
    }

    public class_1799 removeStack(int slot) {
        class_1799 stack = (class_1799)this.inventory.set(slot, class_1799.field_8037);
        this.method_5431();
        return stack;
    }

    public void setStack(int slot, class_1799 stack) {
        this.inventory.set(slot, stack);
        this.method_5431();
    }

    public void method_5431() {
        class_1937 var2 = this.field_11863;
        if (var2 instanceof class_3218 serverLevel) {
            if (!this.field_11863.method_8608()) {
                class_2596<class_2602> updatePacket = this.method_38235();

                for (class_3222 player : LibUtil.tracking(serverLevel, this.method_11016())) {
                    player.field_13987.method_14364(updatePacket);
                }
            }
        }

        super.method_5431();
    }

    @Override
    protected void method_11014(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11014(compoundTag, provider);
        class_2371<class_1799> previous = this.inventory;
        int previousCount = previous == null ? -1 : countItems();
        this.size = compoundTag.method_10550("size");
        this.inventory = class_2371.method_10213(this.size, class_1799.field_8037);
        class_1262.method_5429(compoundTag, this.inventory, provider);
        if (this.slotWobbleStart.length != this.size) {
            this.slotWobbleStart = new long[this.size];
            Arrays.fill(this.slotWobbleStart, Long.MIN_VALUE / 2);
        }
        if (previous != null && this.field_11863 != null && this.field_11863.method_8608()) {
            long time = this.field_11863.method_8510();
            if (previousCount != countItems()) {
                this.wobbleStart = time;
            }
            for (int slot = 0; slot < this.size && slot < previous.size(); slot++) {
                if (previous.get(slot).method_7960() && !this.inventory.get(slot).method_7960()) {
                    this.slotWobbleStart[slot] = time;
                }
            }
        }
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 provider) {
        class_1262.method_5426(nbt, this.inventory, provider);
        nbt.method_10569("size", this.size);
        super.method_11007(nbt, provider);
    }

    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 provider) {
        return this.method_38244(provider);
    }

    public void setInventory(class_2371<class_1799> inventory) {
        for(int i = 0; i < inventory.size(); ++i) {
            this.inventory.set(i, inventory.get(i));
        }

    }

    private int countItems() {
        int count = 0;
        for (class_1799 stack : this.inventory) {
            if (!stack.method_7960()) {
                count++;
            }
        }
        return count;
    }

    public long getWobbleStart() {
        return this.wobbleStart;
    }

    public long getWobbleStart(int slot) {
        return slot >= 0 && slot < this.slotWobbleStart.length ? this.slotWobbleStart[slot] : Long.MIN_VALUE / 2;
    }

    public class_2371<class_1799> getInventory() {
        return this.inventory;
    }

    @Override
    public void method_5448() {
        inventory.clear();
    }
}