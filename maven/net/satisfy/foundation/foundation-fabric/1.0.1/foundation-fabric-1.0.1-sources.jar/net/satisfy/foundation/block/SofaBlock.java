package net.satisfy.foundation.block;

import net.satisfy.foundation.util.DyeHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.satisfy.foundation.seat.SeatUtil;
import org.jetbrains.annotations.NotNull;

public class SofaBlock extends LineConnectingBlock {
    public static final class_2754<ClothColor> COLOR = class_2754.method_11850("color", ClothColor.class);

    private final double seatHeight;

    public SofaBlock(class_2251 properties) {
        this(properties, 0.2);
    }

    public SofaBlock(class_2251 properties, double seatHeight) {
        super(properties);
        this.seatHeight = seatHeight;
        method_9590(method_9564().method_11657(COLOR, ClothColor.NONE));
    }

    protected class_265 getSofaShape(LineConnectingType type, class_2350 facing) {
        return class_259.method_1077();
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return getSofaShape(state.method_11654(TYPE), state.method_11654(FACING));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(COLOR);
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (stack.method_7909() instanceof class_1769 dye && state.method_11654(COLOR).color() != dye.method_7802()) {
            return DyeHelper.apply(stack, dye.method_7802(), state.method_11657(COLOR, ClothColor.of(dye.method_7802())), level, pos, player);
        }
        return SeatUtil.onUse(level, player, hand, hit, seatHeight);
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        SeatUtil.onStateReplaced(level, pos);
        super.method_9536(state, level, pos, newState, moved);
    }
}
