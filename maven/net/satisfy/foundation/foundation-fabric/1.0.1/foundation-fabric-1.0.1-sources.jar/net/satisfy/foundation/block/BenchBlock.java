package net.satisfy.foundation.block;

import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2353;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.satisfy.foundation.block.LineConnectingBlock;
import net.satisfy.foundation.seat.SeatUtil;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Sittable bench that connects with its neighbours.
 * Sitting is handled by {@link net.satisfy.foundation.seat.SeatUtil}.
 */
@SuppressWarnings("unused")
public class BenchBlock extends LineConnectingBlock {
    public BenchBlock(class_2251 settings) {
        super(settings);
    }

    private static final Supplier<class_265> voxelShapeSupplier = () -> {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1082(shape, class_259.method_1081(0, 0, 0.125, 1, 0.4375, 0.875), class_247.field_1366);
        return shape;
    };

    public static final Map<class_2350, class_265> SHAPE = class_156.method_654(new HashMap<>(), map -> {
        for (class_2350 direction : class_2353.field_11062.method_29716().toList()) {
            map.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, voxelShapeSupplier.get()));
        }
    });

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE.get(state.method_11654(FACING));
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        return SeatUtil.onUse(level, player, interactionHand, blockHitResult, 0.1);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        SeatUtil.onStateReplaced(world, pos);
    }
}
