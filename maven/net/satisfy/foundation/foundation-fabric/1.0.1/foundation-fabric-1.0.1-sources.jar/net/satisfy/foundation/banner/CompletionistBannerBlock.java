package net.satisfy.foundation.banner;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * The standing completionist banner. Gives nearby players a small speed boost
 * as a little thank you. Each mod passes its own {@link BannerSettings}.
 */
public class CompletionistBannerBlock extends class_2237 {
    public static final class_2758 ROTATION = class_2741.field_12532;
    private static final class_265 SHAPE = class_2248.method_9541(4.0D, 0.0D, 4.0D, 12.0D, 16.0D, 12.0D);

    private final BannerSettings settings;

    public CompletionistBannerBlock(class_2251 properties, BannerSettings settings) {
        super(properties);
        this.settings = settings;
        makeDefaultState();
    }

    public BannerSettings getSettings() {
        return this.settings;
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return method_54094(properties -> new CompletionistBannerBlock(properties, this.settings));
    }

    @Nullable
    @Override
    public class_2586 method_10123(@NotNull class_2338 blockPos, @NotNull class_2680 blockState) {
        return new CompletionistBannerEntity(blockPos, blockState);
    }

    protected void makeDefaultState() {
        method_9590(this.field_10647.method_11664().method_11657(ROTATION, 0));
    }

    @Override
    public boolean method_9558(@NotNull class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        class_2680 belowBlockState = levelReader.method_8320(blockPos.method_10074());
        return belowBlockState.method_51367();
    }

    @Override
    public boolean method_9538(@NotNull class_2680 blockState) {
        return true;
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 blockState, @NotNull class_1922 blockGetter, @NotNull class_2338 blockPos, @NotNull class_3726 collisionContext) {
        return SHAPE;
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 clickedFace = context.method_8038();
        if (clickedFace == class_2350.field_11036 || clickedFace == class_2350.field_11033) {
            return this.method_9564().method_11657(ROTATION, class_3532.method_15357((double) ((180.0f + context.method_8044()) * 16.0f / 360.0f) + 0.5) & 0xF);
        }
        return this.settings.wallBanner().get().method_9564().method_11657(class_2383.field_11177, clickedFace.method_10153());
    }


    @Override
    public @NotNull class_2680 method_9598(class_2680 blockState, class_2470 rotation) {
        return blockState.method_11657(ROTATION, rotation.method_10502(blockState.method_11654(ROTATION), 16));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 blockState, class_2415 mirror) {
        return blockState.method_11657(ROTATION, mirror.method_10344(blockState.method_11654(ROTATION), 16));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION);
    }

    @Override
    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return level.field_9236 ? null : method_31618(type, this.settings.type().get(), (level1, pos, state1, entity) -> CompletionistBannerEntity.tick(level1, pos, state1));
    }

    @Override
    public @NotNull class_2680 method_9559(@NotNull class_2680 blockState, @NotNull class_2350 direction, @NotNull class_2680 blockState2, @NotNull class_1936 levelAccessor, @NotNull class_2338 blockPos, @NotNull class_2338 blockPos2) {
        if (direction == class_2350.field_11033 && !blockState.method_26184(levelAccessor, blockPos)) {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(blockState, direction, blockState2, levelAccessor, blockPos, blockPos2);
    }

    public class_2960 getRenderTexture() {
        return this.settings.texture();
    }

    @Override
    public void method_9568(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        String prefix = this.settings.tooltipPrefix();
        tooltip.add(class_2561.method_43471(prefix + ".thankyou_1").method_27695(class_124.field_1056, class_124.field_1080));
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43471(prefix + ".thankyou_2").method_27692(class_124.field_1064));
        tooltip.add(class_2561.method_43471(prefix + ".thankyou_4").method_27692(class_124.field_1078));
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43471(prefix + ".thankyou_3").method_27692(class_124.field_1065));
    }

}
