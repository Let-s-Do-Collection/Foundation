package net.satisfy.foundation.block;

import org.jetbrains.annotations.NotNull;

import java.util.function.ToIntFunction;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3749;
import net.minecraft.class_3965;

public class LampBlock extends class_3749 {
    public static final class_2746 LUMINANCE = class_2746.method_11825("luminance");

    private final class_265 standingShape;
    private final class_265 hangingShape;

    public LampBlock(class_2251 properties, class_265 standingShape, class_265 hangingShape) {
        super(properties);
        this.standingShape = standingShape;
        this.hangingShape = hangingShape;
        method_9590(method_9564().method_11657(field_16545, false).method_11657(field_26441, false).method_11657(LUMINANCE, false));
    }

    public static ToIntFunction<class_2680> lightWhenOn(int level) {
        return state -> state.method_11654(LUMINANCE) ? level : 0;
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return state.method_11654(field_16545) ? hangingShape : standingShape;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(LUMINANCE);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!level.method_8608()) {
            level.method_8501(pos, state.method_28493(LUMINANCE));
            level.method_8396(null, pos, class_3417.field_14961, class_3419.field_15245, 1.0F, 1.0F);
        }
        return class_1269.method_29236(level.method_8608());
    }
}
