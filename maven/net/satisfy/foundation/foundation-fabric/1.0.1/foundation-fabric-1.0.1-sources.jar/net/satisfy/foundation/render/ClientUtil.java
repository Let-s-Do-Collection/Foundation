package net.satisfy.foundation.render;

import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;

/** Render shortcuts for block entity renderers, uses the light at the block entity pos. */
public class ClientUtil {

    public static <T extends class_2586> void renderBlock(class_2680 state, class_4587 matrices, class_4597 vertexConsumers, T entity) {
        class_1937 level = entity.method_10997();
        if (level != null) {
            class_310.method_1551().method_1541().method_3353(state, matrices, vertexConsumers, getLightLevel(level, entity.method_11016()), class_4608.field_21444);
        }
    }

    public static <T extends class_2586> void renderBlockFromItem(class_1747 item, class_4587 matrices, class_4597 vertexConsumers, T entity) {
        renderBlock(item.method_7711().method_9564(), matrices, vertexConsumers, entity);
    }

    public static <T extends class_2586> void renderItem(class_1799 stack, class_4587 matrices, class_4597 vertexConsumers, T entity) {
        class_1937 level = entity.method_10997();
        if (level != null) {
            class_310.method_1551().method_1480().method_23178(stack, class_811.field_4317, getLightLevel(level, entity.method_11016()), class_4608.field_21444, matrices, vertexConsumers, level, 1);
        }
    }

    /** Packed block + sky light at pos. */
    public static int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, sLight);
    }

    public static void renderGuiItemForEntity(class_1799 stack, class_4587 matrices, class_4597 vertexConsumers, class_1937 level, class_2338 pos) {
        if (level != null) {
            class_310.method_1551().method_1480().method_23178(stack, class_811.field_4317, getLightLevel(level, pos), class_4608.field_21444, matrices, vertexConsumers, level, 1);
        }
    }

}