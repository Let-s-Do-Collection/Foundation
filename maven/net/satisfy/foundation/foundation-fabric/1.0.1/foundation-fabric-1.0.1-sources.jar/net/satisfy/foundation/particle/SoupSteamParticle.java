package net.satisfy.foundation.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_9381;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.NotNull;

/** Slow rising steam, grows and fades out. */
public class SoupSteamParticle extends class_4003 {
    private final class_4002 sprites;

    protected SoupSteamParticle(class_638 level, double x, double y, double z, double velocityX, double velocityY, double velocityZ, class_4002 sprites) {
        super(level, x, y, z);
        this.sprites = sprites;

        this.field_3847 = 60 + this.field_3840.method_43048(30);
        this.field_3844 = -0.0008F;

        this.field_3852 = velocityX * 0.2;
        this.field_3869 = 0.02 + this.field_3840.method_43058() * 0.01;
        this.field_3850 = velocityZ * 0.2;

        this.field_17867 = 0.12F + this.field_3840.method_43057() * 0.04F;
        this.field_3841 = 0.6F;

        this.method_18142(sprites);
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;

        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }

        this.field_3852 *= 0.96;
        this.field_3850 *= 0.96;

        this.method_3069(this.field_3852, this.field_3869, this.field_3850);

        if (this.field_3866 > this.field_3847 * 0.6) {
            this.field_3841 *= 0.94F;
        }

        this.field_17867 *= 1.002F;

        this.method_18142(this.sprites);
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17829;
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
            return new SoupSteamParticle(level, x, y + 0.25, z, velocityX, velocityY, velocityZ, this.sprites);
        }
    }

    public static class ColoredProvider implements class_707<class_9381> {
        private final class_4002 sprites;

        public ColoredProvider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_9381 color, class_638 level, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
            SoupSteamParticle particle = new SoupSteamParticle(level, x, y, z, velocityX, velocityY, velocityZ, this.sprites);
            particle.method_3084(color.method_58259(), color.method_58263(), color.method_58264());
            return particle;
        }
    }
}