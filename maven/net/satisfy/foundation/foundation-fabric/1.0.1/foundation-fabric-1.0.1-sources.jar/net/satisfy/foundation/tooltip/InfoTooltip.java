package net.satisfy.foundation.tooltip;

import dev.architectury.event.events.client.ClientTooltipEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_5251;
import net.minecraft.class_7923;

/**
 * Builder for extra item tooltips without touching the item class.
 *
 * <pre>{@code
 * InfoTooltip.of(MyItems.JAR).placeable().details(2).register();
 * }</pre>
 * Detail keys are {@code tooltip.<ns>.<item>.info_0..n} and only show while holding shift.
 */
public final class InfoTooltip {
    private static final int TEXT_COLOR = 0xFFD966;
    private static final int KEY_COLOR = 0xFFD700;
    private static final Map<class_1792, Entry> ENTRIES = new HashMap<>();
    private static boolean initialized;

    private InfoTooltip() {
    }

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        ClientTooltipEvent.ITEM.register((stack, lines, context, flag) -> {
            Entry entry = ENTRIES.get(stack.method_7909());
            if (entry != null && entry.enabled.getAsBoolean()) {
                entry.append(lines);
            }
        });
    }

    /** Starts a tooltip for the item, don't forget {@code register()}. */
    public static Builder of(class_1935 item) {
        return new Builder(item.method_8389());
    }

    public static final class Builder {
        private final class_1792 item;
        private final List<String> lines = new ArrayList<>();
        private boolean placeable;
        private int details;
        private BooleanSupplier enabled = () -> true;

        private Builder(class_1792 item) {
            this.item = item;
        }

        /** Adds the "can be placed" line. */
        public Builder placeable() {
            this.placeable = true;
            return this;
        }

        /** Extra grey line, always visible. */
        public Builder line(String translationKey) {
            this.lines.add(translationKey);
            return this;
        }

        /** Amount of shift-detail lines. */
        public Builder details(int count) {
            this.details = count;
            return this;
        }

        /** Only show when this is true, e.g. a config toggle. */
        public Builder when(BooleanSupplier enabled) {
            this.enabled = enabled;
            return this;
        }

        public void register() {
            class_2960 id = class_7923.field_41178.method_10221(this.item);
            ENTRIES.put(this.item, new Entry(this.placeable, List.copyOf(this.lines), this.details, "tooltip." + id.method_12836() + "." + id.method_12832() + ".info_", this.enabled));
        }
    }

    private record Entry(boolean placeable, List<String> lines, int details, String detailPrefix, BooleanSupplier enabled) {
        void append(List<class_2561> tooltip) {
            if (this.placeable) {
                tooltip.add(class_2561.method_43471("tooltip.foundation.canbeplaced").method_27692(class_124.field_1080));
            }
            for (String line : this.lines) {
                tooltip.add(class_2561.method_43471(line).method_27692(class_124.field_1080));
            }
            if (this.details <= 0) {
                return;
            }
            tooltip.add(class_2561.method_43473());
            class_2583 text = class_2583.field_24360.method_27703(class_5251.method_27717(TEXT_COLOR));
            if (!class_437.method_25442()) {
                class_2561 key = class_2561.method_43470("[SHIFT]").method_27696(class_2583.field_24360.method_27703(class_5251.method_27717(KEY_COLOR)));
                tooltip.add(class_2561.method_43469("tooltip.foundation.hold_shift", key).method_27696(text));
                return;
            }
            for (int i = 0; i < this.details; i++) {
                if (i > 0) {
                    tooltip.add(class_2561.method_43473());
                }
                tooltip.add(class_2561.method_43471(this.detailPrefix + i).method_27696(text));
            }
        }
    }
}
