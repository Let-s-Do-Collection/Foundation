package net.satisfy.foundation.particle;

import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_9381;
import org.jetbrains.annotations.NotNull;

/** Colored splash when dyeing a block, color comes from the particle option. */
public class DyeSplashParticle extends class_4003 {
    private static final float GRAVITY = 0.9F;
    private static final double UPWARD_BOOST = 0.12;

    protected DyeSplashParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_9381 color) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.field_3852 = xSpeed + (this.field_3840.method_43058() - 0.5) * 0.1;
        this.field_3869 = Math.abs(ySpeed) + UPWARD_BOOST + this.field_3840.method_43058() * 0.08;
        this.field_3850 = zSpeed + (this.field_3840.method_43058() - 0.5) * 0.1;
        this.field_3844 = GRAVITY;
        this.field_28786 = 0.96F;
        this.field_3847 = 10 + this.field_3840.method_43048(8);
        this.field_17867 *= 0.8F;
        this.field_3861 = color.method_58259();
        this.field_3842 = color.method_58263();
        this.field_3859 = color.method_58264();
        this.field_3862 = true;
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17828;
    }

    public static class Provider implements class_707<class_9381> {
        private final class_4002 spriteSet;

        public Provider(class_4002 spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Override
        public class_703 createParticle(class_9381 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            DyeSplashParticle particle = new DyeSplashParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, type);
            particle.method_18140(this.spriteSet);
            return particle;
        }
    }
}
