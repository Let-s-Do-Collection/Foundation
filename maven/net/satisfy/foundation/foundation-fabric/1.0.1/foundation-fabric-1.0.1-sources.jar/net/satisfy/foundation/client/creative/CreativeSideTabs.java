package net.satisfy.foundation.client.creative;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public final class CreativeSideTabs {
    private static final Map<class_5321<class_1761>, List<SideTab>> SIDE_TABS = new HashMap<>();
    private static final Map<class_5321<class_1761>, Integer> SELECTED = new HashMap<>();

    private CreativeSideTabs() {
    }

    public static void register(class_5321<class_1761> tab, SideTab... sideTabs) {
        SIDE_TABS.put(tab, List.of(sideTabs));
    }

    public static List<SideTab> get(class_1761 tab) {
        Optional<class_5321<class_1761>> key = class_7923.field_44687.method_29113(tab);
        return key.map(k -> SIDE_TABS.getOrDefault(k, List.of())).orElse(List.of());
    }

    public static int getSelected(class_1761 tab) {
        return class_7923.field_44687.method_29113(tab).map(k -> SELECTED.getOrDefault(k, 0)).orElse(0);
    }

    public static void select(class_1761 tab, int index) {
        class_7923.field_44687.method_29113(tab).ifPresent(k -> SELECTED.put(k, index));
    }

    public static final class SideTab {
        private final class_2561 title;
        private final Supplier<class_1799> icon;
        private final Consumer<class_1761.class_7704> contents;
        private Set<class_1792> items;

        public SideTab(class_2561 title, Supplier<class_1799> icon, Consumer<class_1761.class_7704> contents) {
            this.title = title;
            this.icon = icon;
            this.contents = contents;
        }

        public class_2561 title() {
            return title;
        }

        public class_1799 icon() {
            return icon.get();
        }

        public boolean contains(class_1799 stack) {
            if (items == null) {
                Set<class_1792> collected = new HashSet<>();
                contents.accept((stack1, visibility) -> collected.add(stack1.method_7909()));
                items = collected;
            }
            return items.contains(stack.method_7909());
        }

        public static SideTab of(class_2561 title, class_1935 icon, Consumer<class_1761.class_7704> contents) {
            return new SideTab(title, () -> new class_1799(icon), contents);
        }
    }
}
