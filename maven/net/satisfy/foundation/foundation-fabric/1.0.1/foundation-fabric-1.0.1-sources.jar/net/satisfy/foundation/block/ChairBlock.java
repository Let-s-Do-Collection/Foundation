package net.satisfy.foundation.block;

import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import net.satisfy.foundation.seat.SeatUtil;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

/**
 * Two block high chair (seat + backrest). Placing it places the upper half too,
 * breaking one half removes the other.
 */
@SuppressWarnings("unused")
public class ChairBlock extends class_2248 {
    public static final class_2754<class_2756> HALF = class_2741.field_12533;
    public static final class_2753 FACING = class_2741.field_12481;

    private static final class_265 SHAPE_LOWER = makeLowerShape();
    private static final class_265 SHAPE_UPPER = makeUpperShape();

    public static final Map<class_2350, class_265> SHAPE_LOWER_MAP = net.minecraft.class_156.method_654(new HashMap<>(), map -> {
        for (class_2350 direction : class_2350.class_2353.field_11062.method_29716().toList()) {
            map.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, SHAPE_LOWER));
        }
    });

    public static final Map<class_2350, class_265> SHAPE_UPPER_MAP = net.minecraft.class_156.method_654(new HashMap<>(), map -> {
        for (class_2350 direction : class_2350.class_2353.field_11062.method_29716().toList()) {
            map.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, SHAPE_UPPER));
        }
    });

    private static class_265 makeLowerShape() {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1072(shape, class_259.method_1081(0.1875, 0.5625, 0.1875, 0.8125, 0.625, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.6875, 0, 0.1875, 0.8125, 0.5625, 0.3125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.1875, 0, 0.1875, 0.3125, 0.5625, 0.3125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.1875, 0, 0.6875, 0.3125, 0.5625, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.6875, 0, 0.6875, 0.8125, 0.5625, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.6875, 0.625, 0.6875, 0.8125, 1, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.1875, 0.625, 0.6875, 0.3125, 1, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.25, 0.5, 0.25, 0.75, 0.5625, 0.75), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.3125, 0.625, 0.75, 0.6875, 1, 0.8125), class_247.field_1366);
        return shape;
    }

    private static class_265 makeUpperShape() {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1072(shape, class_259.method_1081(0.6875, 0, 0.6875, 0.8125, 0.3125, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.1875, 0, 0.6875, 0.3125, 0.3125, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.25, 0.3125, 0.6875, 0.75, 0.375, 0.8125), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.3125, 0, 0.75, 0.6875, 0.3125, 0.8125), class_247.field_1366);
        return shape;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 blockPos, class_2680 blockState, @Nullable class_1309 livingEntity, class_1799 itemStack) {
        class_2338 abovePos = blockPos.method_10084();
        level.method_8652(abovePos, this.method_9564().method_11657(HALF, class_2756.field_12609).method_11657(FACING, blockState.method_11654(FACING)), 3);
        super.method_9567(level, blockPos, blockState, livingEntity, itemStack);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        if (state.method_11654(HALF) != class_2756.field_12609) {
            return super.method_9558(state, world, pos);
        } else {
            class_2680 belowState = world.method_8320(pos.method_10074());
            return belowState.method_27852(this) && belowState.method_11654(HALF) == class_2756.field_12607;
        }
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2338 pos = context.method_8037();
        class_1937 world = context.method_8045();
        return pos.method_10264() < world.method_31600() - 1 && world.method_8320(pos.method_10084()).method_26166(context) ? this.method_9564().method_11657(FACING, context.method_8042().method_10153()).method_11657(HALF, class_2756.field_12607) : null;
    }

    public ChairBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(HALF, class_2756.field_12607));
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        if (interactionHand == class_1268.field_5810) {
            return class_9062.field_47731;
        }
        if (blockState.method_11654(HALF) == class_2756.field_12607) {
            return SeatUtil.onUse(level, player, interactionHand, blockHitResult, 0.2);
        }
        return class_9062.field_47731;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            if (state.method_11654(HALF) == class_2756.field_12607) {
                class_2338 abovePos = pos.method_10084();
                class_2680 aboveState = world.method_8320(abovePos);
                if (aboveState.method_26204() == this && aboveState.method_11654(HALF) == class_2756.field_12609) {
                    world.method_8652(abovePos, net.minecraft.class_2246.field_10124.method_9564(), 35);
                }
            } else {
                class_2338 belowPos = pos.method_10074();
                class_2680 belowState = world.method_8320(belowPos);
                if (belowState.method_26204() == this && belowState.method_11654(HALF) == class_2756.field_12607) {
                    world.method_8652(belowPos, net.minecraft.class_2246.field_10124.method_9564(), 35);
                }
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    @Override
    protected boolean method_9516(class_2680 blockState, class_10 pathComputationType) {
        return false;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, HALF);
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return state.method_11654(HALF) == class_2756.field_12609 ? SHAPE_UPPER_MAP.get(state.method_11654(FACING)) : SHAPE_LOWER_MAP.get(state.method_11654(FACING));
    }
}