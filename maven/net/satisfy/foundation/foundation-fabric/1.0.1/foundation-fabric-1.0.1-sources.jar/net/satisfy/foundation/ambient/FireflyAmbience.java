package net.satisfy.foundation.ambient;

import net.satisfy.foundation.block.LampBlock;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.satisfy.foundation.ambient.Fireflies;
import net.satisfy.foundation.registry.FoundationTags;

/**
 * Client side ambience that spawns fireflies around blocks tagged with
 * {@code foundation:attracts_fireflies}. Lit property is respected (unlit lanterns = no bugs).
 */
public final class FireflyAmbience {
    private static final List<BooleanSupplier> CONDITIONS = new ArrayList<>();
    private static boolean initialized;
    private static final int RANGE = 12;
    private static final int SAMPLES = 390;
    private static final int CHANCE = 2;
    private static final double SPREAD = 1.5;
    private static final double HANGING_OFFSET = 0.1;
    private static final double STANDING_OFFSET = 0.2;

    private FireflyAmbience() {
    }

    /**
     * Hooks the ambience into the client tick. Can be called by several mods,
     * every condition gets and-ed together so one mod can turn it off (e.g. via config).
     *
     * @param enabled condition for this caller, usually a config value
     */
    public static void init(BooleanSupplier enabled) {
        CONDITIONS.add(enabled);
        if (!initialized) {
            initialized = true;
            ClientTickEvent.CLIENT_POST.register(FireflyAmbience::tick);
        }
    }

    private static boolean isEnabled() {
        return CONDITIONS.stream().allMatch(BooleanSupplier::getAsBoolean);
    }

    private static void tick(class_310 minecraft) {
        class_1937 level = minecraft.field_1687;
        if (level == null || minecraft.field_1724 == null || minecraft.method_1493() || !isEnabled()) {
            return;
        }
        class_5819 random = level.field_9229;
        class_2338 center = minecraft.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int i = 0; i < SAMPLES; i++) {
            pos.method_10103(center.method_10263() + random.method_43048(RANGE * 2 + 1) - RANGE, center.method_10264() + random.method_43048(RANGE * 2 + 1) - RANGE, center.method_10260() + random.method_43048(RANGE * 2 + 1) - RANGE);
            class_2680 state = level.method_8320(pos);
            if (!state.method_26164(FoundationTags.ATTRACTS_FIREFLIES) || random.method_43048(CHANCE) != 0) {
                continue;
            }
            if (state.method_28498(class_2741.field_12548) && !state.method_11654(class_2741.field_12548) || state.method_28498(LampBlock.LUMINANCE) && !state.method_11654(LampBlock.LUMINANCE)) {
                continue;
            }
            if (!Fireflies.isActive(level, pos)) {
                continue;
            }
            boolean hanging = state.method_28498(class_2741.field_16561) && state.method_11654(class_2741.field_16561);
            Fireflies.spawn(level, pos, random, SPREAD, hanging ? HANGING_OFFSET : STANDING_OFFSET);
        }
    }
}
