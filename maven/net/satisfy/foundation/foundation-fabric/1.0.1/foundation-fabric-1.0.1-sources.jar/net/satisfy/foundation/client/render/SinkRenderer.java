package net.satisfy.foundation.client.render;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.class_1058;
import net.minecraft.class_1163;
import net.minecraft.class_1723;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.satisfy.foundation.Foundation;
import net.satisfy.foundation.block.SinkBlock;
import net.satisfy.foundation.block.SinkBlockEntity;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SinkRenderer implements class_827<SinkBlockEntity> {
    private static final class_2960 FAUCET_MODEL = Foundation.identifier("models/block/sink_faucet.json");
    private static final class_2960 FAUCET_TEXTURE = Foundation.identifier("block/sink_faucet");
    private static final class_2960 WATER_TEXTURE = class_2960.method_60656("block/water_still");
    private static final float PIXEL = 1.0F / 16.0F;
    private static final float HANDLE_TURN = 135.0F;
    private static List<Element> faucet;

    public SinkRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(SinkBlockEntity sink, float partialTick, class_4587 poseStack, class_4597 buffers, int light, int overlay) {
        class_1937 level = sink.method_10997();
        if (level == null || !(sink.method_11010().method_26204() instanceof SinkBlock)) {
            return;
        }
        class_2350 facing = sink.method_11010().method_11654(SinkBlock.FACING);
        float yaw = switch (facing) {
            case field_11034 -> 90.0F;
            case field_11035 -> 180.0F;
            case field_11039 -> 270.0F;
            default -> 0.0F;
        };
        poseStack.method_22903();
        poseStack.method_46416(0.5F, 0.0F, 0.5F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
        poseStack.method_46416(-0.5F, 0.0F, -0.5F);

        if (sink.getWaterLevel() > 0) {
            drawWater(poseStack, buffers, level, sink.method_11016(), sink.getWaterLevel(), light);
        }

        float turn = class_3532.method_15363((level.method_8510() + partialTick - sink.getToggleTime()) / SinkBlockEntity.TURN_TICKS, 0.0F, 1.0F);
        float eased = 1.0F - (1.0F - turn) * (1.0F - turn);
        float handle = (sink.isOpen() ? eased : 1.0F - eased) * HANDLE_TURN;
        poseStack.method_46416(0.0F, 1.0F, 0.0F);
        int faucetLight = class_761.method_23794(level, sink.method_11016().method_10084());
        drawFaucet(poseStack, buffers, handle, faucetLight);
        poseStack.method_22909();
    }

    private static void drawWater(class_4587 poseStack, class_4597 buffers, class_1937 level, class_2338 pos, int waterLevel, int light) {
        class_1058 sprite = class_310.method_1551().method_1549(class_1723.field_21668).apply(WATER_TEXTURE);
        int color = class_1163.method_4961(level, pos);
        float r = (color >> 16 & 255) / 255.0F, g = (color >> 8 & 255) / 255.0F, b = (color & 255) / 255.0F;
        float y = (12.0F + waterLevel) * PIXEL;
        float x0 = 3 * PIXEL, x1 = 13 * PIXEL, z0 = 3 * PIXEL, z1 = 12 * PIXEL;
        class_4588 consumer = buffers.getBuffer(class_1921.method_23583());
        class_4587.class_4665 pose = poseStack.method_23760();
        float[][] corners = {{x0, z0}, {x0, z1}, {x1, z1}, {x1, z0}};
        for (float[] corner : corners) {
            consumer.method_56824(pose, corner[0], y, corner[1])
                    .method_22915(r, g, b, 0.85F)
                    .method_22913(sprite.method_4580(corner[0]), sprite.method_4570(corner[1]))
                    .method_60803(light)
                    .method_60831(pose, 0.0F, 1.0F, 0.0F);
        }
    }

    private static void drawFaucet(class_4587 poseStack, class_4597 buffers, float handleAngle, int light) {
        class_1058 sprite = class_310.method_1551().method_1549(class_1723.field_21668).apply(FAUCET_TEXTURE);
        class_4588 consumer = buffers.getBuffer(class_1921.method_23581());
        for (Element element : faucet()) {
            poseStack.method_22903();
            if (element.handle) {
                float cy = (element.from[1] + element.to[1]) / 2.0F * PIXEL;
                float cz = (element.from[2] + element.to[2]) / 2.0F * PIXEL;
                poseStack.method_46416(0.0F, cy, cz);
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(handleAngle));
                poseStack.method_46416(0.0F, -cy, -cz);
            }
            element.draw(poseStack.method_23760(), consumer, sprite, light);
            poseStack.method_22909();
        }
    }

    private static List<Element> faucet() {
        if (faucet == null) {
            faucet = new ArrayList<>();
            class_310.method_1551().method_1478().method_14486(FAUCET_MODEL).ifPresent(resource -> {
                try (Reader reader = resource.method_43039()) {
                    JsonObject model = JsonParser.parseReader(reader).getAsJsonObject();
                    for (JsonElement entry : model.getAsJsonArray("elements")) {
                        faucet.add(Element.parse(entry.getAsJsonObject()));
                    }
                } catch (Exception exception) {
                    Foundation.LOGGER.warn("Could not read sink faucet model", exception);
                }
            });
        }
        return faucet;
    }

    private record Face(class_2350 direction, float[] uv, int rotation) {
    }

    private record Element(float[] from, float[] to, boolean handle, List<Face> faces) {
        static Element parse(JsonObject json) {
            List<Face> faces = new ArrayList<>();
            for (Map.Entry<String, JsonElement> entry : json.getAsJsonObject("faces").entrySet()) {
                JsonObject face = entry.getValue().getAsJsonObject();
                class_2350 direction = class_2350.method_10168(entry.getKey());
                if (direction != null) {
                    faces.add(new Face(direction, floats(face.getAsJsonArray("uv")), face.has("rotation") ? face.get("rotation").getAsInt() : 0));
                }
            }
            return new Element(floats(json.getAsJsonArray("from")), floats(json.getAsJsonArray("to")), json.has("name") && "handle".equals(json.get("name").getAsString()), faces);
        }

        private static float[] floats(JsonArray array) {
            float[] values = new float[array.size()];
            for (int index = 0; index < values.length; index++) {
                values[index] = array.get(index).getAsFloat();
            }
            return values;
        }

        void draw(class_4587.class_4665 pose, class_4588 consumer, class_1058 sprite, int light) {
            float x0 = from[0] * PIXEL, y0 = from[1] * PIXEL, z0 = from[2] * PIXEL;
            float x1 = to[0] * PIXEL, y1 = to[1] * PIXEL, z1 = to[2] * PIXEL;
            for (Face face : faces) {
                float[][] points = switch (face.direction) {
                    case field_11036 -> new float[][]{{x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, {x1, y1, z0}};
                    case field_11033 -> new float[][]{{x0, y0, z1}, {x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}};
                    case field_11043 -> new float[][]{{x1, y1, z0}, {x1, y0, z0}, {x0, y0, z0}, {x0, y1, z0}};
                    case field_11035 -> new float[][]{{x0, y1, z1}, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}};
                    case field_11039 -> new float[][]{{x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}};
                    case field_11034 -> new float[][]{{x1, y1, z1}, {x1, y0, z1}, {x1, y0, z0}, {x1, y1, z0}};
                };
                float u0 = face.uv[0], v0 = face.uv[1], u1 = face.uv[2], v1 = face.uv[3];
                float[][] uvs = {{u0, v0}, {u0, v1}, {u1, v1}, {u1, v0}};
                int shift = (face.rotation / 90) % 4;
                float shade = switch (face.direction) {
                    case field_11036 -> 1.0F;
                    case field_11033 -> 0.5F;
                    case field_11043, field_11035 -> 0.8F;
                    default -> 0.6F;
                };
                for (int corner = 0; corner < 4; corner++) {
                    float[] uv = uvs[(corner + shift) % 4];
                    consumer.method_56824(pose, points[corner][0], points[corner][1], points[corner][2])
                            .method_22915(shade, shade, shade, 1.0F)
                            .method_22913(sprite.method_4580(uv[0] / 16.0F), sprite.method_4570(uv[1] / 16.0F))
                            .method_60803(light)
                            .method_60831(pose, face.direction.method_10148(), face.direction.method_10164(), face.direction.method_10165());
                }
            }
        }
    }
}
