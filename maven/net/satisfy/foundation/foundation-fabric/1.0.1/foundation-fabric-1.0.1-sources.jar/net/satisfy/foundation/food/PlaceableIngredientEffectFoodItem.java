package net.satisfy.foundation.food;

import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

/** Placeable version of {@link IngredientEffectFoodItem}, sneak to place. */
public class PlaceableIngredientEffectFoodItem extends class_1747 implements IngredientEffectCarrier {

    private final int foodStages;

    public PlaceableIngredientEffectFoodItem(class_2248 block, class_1793 properties, int foodStages) {
        super(block, properties);
        this.foodStages = foodStages;
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.field_9236) {
            List<Pair<class_1293, Float>> effects = IngredientEffects.getEffects(stack);
            for (Pair<class_1293, Float> effect : effects) {
                if (effect.getFirst() != null && world.field_9229.method_43057() < effect.getSecond()) {
                    user.method_6092(new class_1293(effect.getFirst()));
                }
            }
        }
        int stage = IngredientEffects.getStage(stack);
        int slot = -1;
        class_1661 inv = null;
        if (user instanceof class_1657 player && !player.method_7337()) {
            inv = player.method_31548();
            slot = inv.method_7371(stack);
        }
        class_1799 eaten = user.method_60492(world, stack);
        if (inv != null && stage < this.foodStages) {
            class_1799 next = IngredientEffects.setStage(new class_1799(this), stage + 1);
            if (slot >= 0 && slot < inv.field_7547.size()) {
                if (inv.method_5438(slot).method_7960()) {
                    inv.method_7367(slot, next);
                    return eaten;
                }
            }
            int space = inv.method_7390(next);
            if (space >= 0 && space < inv.field_7547.size()) {
                inv.method_7367(space, next);
            }
        }
        return eaten;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        IngredientEffects.getTooltip(itemStack, tooltipContext, tooltip);
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43471("tooltip.foundation.canbeplaced").method_27695(class_124.field_1056, class_124.field_1080));
    }

    @Override
    public @NotNull class_1269 method_7712(class_1750 context) {
        class_1657 player = context.method_8036();
        if (player != null && player.method_5715()) {
            return super.method_7712(context);
        }
        return class_1269.field_5811;
    }
}