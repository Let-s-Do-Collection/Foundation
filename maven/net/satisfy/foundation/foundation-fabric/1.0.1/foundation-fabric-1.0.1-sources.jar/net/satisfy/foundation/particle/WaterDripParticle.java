package net.satisfy.foundation.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.NotNull;

/**
 * Water drop with 3 stages: hang, fall, land. Tinted with the biome water color.
 * No velocity = starts hanging, with velocity = falls right away.
 */
public class WaterDripParticle extends class_4003 {
    private static final int HANG = 0;
    private static final int FALL = 1;
    private static final int LAND = 2;

    private final class_4002 sprites;
    private int stage;
    private int stageAge;

    protected WaterDripParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_4002 sprites) {
        super(level, x, y, z);
        this.sprites = sprites;
        WaterTint.apply(this, level, x, y, z);
        this.method_3080(0.01F, 0.01F);
        this.field_3862 = true;
        this.field_28786 = 0.98F;
        this.field_3847 = 200;
        if (ySpeed != 0.0 || xSpeed != 0.0 || zSpeed != 0.0) {
            this.field_3852 = xSpeed;
            this.field_3869 = ySpeed;
            this.field_3850 = zSpeed;
            setStage(FALL);
        } else {
            this.field_3852 = 0.0;
            this.field_3869 = 0.0;
            this.field_3850 = 0.0;
            setStage(HANG);
        }
    }

    private void setStage(int stage) {
        this.stage = stage;
        this.stageAge = 0;
        this.method_18141(this.sprites.method_18138(stage, LAND));
        this.field_3844 = stage == FALL ? 0.06F : 0.0F;
        if (stage == LAND) {
            this.field_3852 = 0.0;
            this.field_3869 = 0.0;
            this.field_3850 = 0.0;
        }
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        this.stageAge++;

        switch (this.stage) {
            case HANG -> {
                if (this.stageAge > 40) {
                    setStage(FALL);
                }
            }
            case FALL -> {
                this.field_3869 -= this.field_3844;
                this.method_3069(this.field_3852, this.field_3869, this.field_3850);
                this.field_3852 *= this.field_28786;
                this.field_3850 *= this.field_28786;
                if (this.field_3845) {
                    setStage(LAND);
                }
            }
            case LAND -> {
                if (this.stageAge > 8 + this.field_3840.method_43048(8)) {
                    this.method_3085();
                }
            }
            default -> this.method_3085();
        }
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17828;
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new WaterDripParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
        }
    }
}
