package net.satisfy.foundation.food;

import net.minecraft.class_124;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.satisfy.foundation.util.LibUtil;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;

/**
 * Food item with potion-like effect tooltip, optionally gives the bowl back.
 *
 * Note: {@code duration} is unused, same as in {@link EffectDrinkItem}.
 */
@SuppressWarnings("unused")
public class EffectFoodItem extends class_1792 {
    private final boolean returnBowl;

    public EffectFoodItem(class_1793 properties, int duration, boolean returnBowl) {
        super(properties);
        this.returnBowl = returnBowl;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        List<class_4174.class_9423> list2 = itemStack.method_57826(class_9334.field_50075) ? Objects.requireNonNull(itemStack.method_57824(class_9334.field_50075)).comp_2495() : Lists.newArrayList();
        List<Pair<class_6880<class_1320>, class_1322>> list3 = Lists.newArrayList();
        if (list2.isEmpty()) {
            tooltip.add(class_2561.method_43471("effect.none").method_27692(class_124.field_1080));
        } else {
            for (class_4174.class_9423 statusEffectInstance : list2) {
                class_5250 mutableText = class_2561.method_43471(statusEffectInstance.comp_2496().method_5586());
                class_1293 statusEffect = statusEffectInstance.comp_2496();

                statusEffect.method_5579().comp_349().method_55650(statusEffect.method_5578(), (holderx, attributeModifierx) -> {
                    class_1322 entityAttributeModifier = new class_1322(
                            attributeModifierx.comp_2447(),
                            attributeModifierx.comp_2449() * (double)(statusEffect.method_5578() + 1),
                            attributeModifierx.comp_2450()
                    );
                    list3.add(new Pair<>(holderx, entityAttributeModifier));
                });
                if (statusEffectInstance.comp_2496().method_5584() > 20) {
                    mutableText = class_2561.method_43469(
                            "potion.withDuration",
                            mutableText, class_1292.method_5577(statusEffect, statusEffectInstance.comp_2497(), tooltipContext.method_59531()));
                }

                tooltip.add(mutableText.method_27692(statusEffect.method_5579().comp_349().method_18792().method_18793()));
            }
        }

        if (!list3.isEmpty()) {
            tooltip.add(class_2561.method_43473());
            tooltip.add(class_2561.method_43471("potion.whenDrank").method_27692(class_124.field_1064));

            for (Pair<class_6880<class_1320>, class_1322> pair : list3) {
                class_1322 entityAttributeModifier3 = pair.getSecond();
                double d = entityAttributeModifier3.comp_2449();
                double e;
                if (entityAttributeModifier3.comp_2450() != class_1322.class_1323.field_6330 && entityAttributeModifier3.comp_2450() != class_1322.class_1323.field_6331) {
                    e = entityAttributeModifier3.comp_2449();
                } else {
                    e = entityAttributeModifier3.comp_2449() * 100.0;
                }

                if (d > 0.0) {
                    tooltip.add(
                            class_2561.method_43469(
                                            "attribute.modifier.plus." + entityAttributeModifier3.comp_2450().method_56082(),
                                            class_9285.field_49329.format(e), class_2561.method_43471(pair.getFirst().comp_349().method_26830()))
                                    .method_27692(class_124.field_1078)
                    );
                } else if (d < 0.0) {
                    e *= -1.0;
                    tooltip.add(
                            class_2561.method_43469(
                                            "attribute.modifier.take." + entityAttributeModifier3.comp_2450().method_56082(),
                                            class_9285.field_49329.format(e), class_2561.method_43471(pair.getFirst().comp_349().method_26830()))
                                    .method_27692(class_124.field_1061)
                    );
                }
            }
        }
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 itemStack, class_1937 level, class_1309 livingEntity) {
        class_1799 eaten = livingEntity.method_60492(level, itemStack);
        if (this.returnBowl) {
            return LibUtil.convertStackAfterFinishUsing(livingEntity, eaten, class_1802.field_8428, this);
        }
        return eaten;
    }
}
