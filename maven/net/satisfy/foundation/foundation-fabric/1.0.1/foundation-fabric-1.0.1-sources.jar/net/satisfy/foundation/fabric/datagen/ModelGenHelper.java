package net.satisfy.foundation.fabric.datagen;

import java.util.List;
import java.util.stream.IntStream;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;

public record ModelGenHelper(String namespace) {
    public class_2960 blockId(String path) {
        return class_2960.method_60655(namespace, "block/" + path);
    }

    public class_2960 itemId(String path) {
        return class_2960.method_60655(namespace, "item/" + path);
    }

    public List<class_2960> variantIds(String pattern, int amount) {
        return IntStream.range(0, amount).mapToObj(i -> blockId(String.format(pattern, i))).toList();
    }

    public static List<class_4935> variants(List<class_2960> models) {
        return models.stream().map(id -> class_4935.method_25824().method_25828(class_4936.field_22887, id)).toList();
    }

    public static class_4935[] variantArray(List<class_2960> models) {
        return variants(models).toArray(class_4935[]::new);
    }

    public static void slabFromTexture(class_4910 generators, class_2248 slab, class_2960 texture) {
        class_4944 mapping = class_4944.method_25875(texture);
        class_2960 bottom = class_4943.field_22909.method_25852(class_4941.method_25843(slab, "_bottom"), mapping, generators.field_22831);
        class_2960 top = class_4943.field_22910.method_25852(class_4941.method_25843(slab, "_top"), mapping, generators.field_22831);
        generators.field_22830.accept(class_4910.method_25668(slab, bottom, top, texture));
        generators.method_25538(slab.method_8389(), bottom);
    }
}
