package net.satisfy.foundation.util;

import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_9139;

/** Extra stream codecs. */
public final class StreamCodecUtil {
    /** Codec for a NonNullList, size prefixed. */
    public static <T, B extends class_2540> class_9139<B, class_2371<T>> nonNullList(class_9139<B, T> elementCodec, T defaultElement) {
        return class_9139.method_56437((buf, value) -> {
            buf.method_10804(value.size());

            for (T element : value) {
                elementCodec.encode(buf, element);
            }
        }, buf -> {
            class_2371<T> list = class_2371.method_10213(buf.method_10816(), defaultElement);

            list.replaceAll(element -> elementCodec.decode(buf));

            return list;
        });
    }
}