package net.satisfy.foundation.block;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3726;
import net.minecraft.class_6088;
import net.satisfy.foundation.util.ShapeUtil;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class BigTableBlock extends class_2383 {
	public static final class_2754<class_2742> PART = class_2741.field_12483;

	private static final Supplier<class_265> voxelShapeSupplier = () -> {
		class_265 shape = class_259.method_1073();
		shape = class_259.method_1082(shape, class_259.method_1081(0, 0, 0.0625, 0.9375, 0.875, 0.9375), class_247.field_1366);
		shape = class_259.method_1082(shape, class_259.method_1081(0, 0.9375, 0.0625, 0.9375, 1, 0.9375), class_247.field_1366);
		shape = class_259.method_1082(shape, class_259.method_1081(0, 0.875, 0, 1, 1, 0.0625), class_247.field_1366);
		shape = class_259.method_1082(shape, class_259.method_1081(0, 0.875, 0.9375, 1, 1, 1), class_247.field_1366);
		shape = class_259.method_1082(shape, class_259.method_1081(0.9375, 0.875, 0.0625, 1, 1, 0.9375), class_247.field_1366);
		return shape;
	};

	public static final Map<class_2350, class_265> SHAPE = net.minecraft.class_156.method_654(new HashMap<>(), map -> {
		for (class_2350 direction : class_2350.class_2353.field_11062) {
			map.put(direction, ShapeUtil.rotateShape(class_2350.field_11034, direction, voxelShapeSupplier.get()));
		}
	});

	public static final class_2753 FACING = class_2383.field_11177;

	public BigTableBlock(class_2251 settings) {
		super(settings);
		this.method_9590(this.method_9564().method_11657(field_11177, class_2350.field_11043).method_11657(PART, class_2742.field_12557));
	}

	public static final MapCodec<BigTableBlock> field_46280 = method_54094(BigTableBlock::new);

	@Override
	protected @NotNull MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}

	public @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
		if (direction == getDirectionTowardsOtherPart(state.method_11654(PART), state.method_11654(field_11177))) {
			return neighborState.method_27852(this) && neighborState.method_11654(PART) != state.method_11654(PART) ? state : class_2246.field_10124.method_9564();
		} else {
			return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
		}
	}
	
	private static class_2350 getDirectionTowardsOtherPart(class_2742 part, class_2350 direction) {
		return part == class_2742.field_12557 ? direction : direction.method_10153();
	}

	public @NotNull class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
		if (!world.field_9236 && player.method_7337()) {
			removeOtherPart(world, pos, state, player);
		}

		return super.method_9576(world, pos, state, player);
	}

	@Nullable
	public class_2680 method_9605(class_1750 ctx) {
		class_2350 direction = ctx.method_8042().method_10170();
		class_2338 blockPos = ctx.method_8037();
		class_2338 blockPos2 = blockPos.method_10093(direction);
		class_1937 world = ctx.method_8045();
		return world.method_8320(blockPos2).method_26166(ctx) && world.method_8621().method_11952(blockPos2) ? this.method_9564().method_11657(field_11177, direction) : null;
	}

	@Override
	protected @NotNull class_265 method_25959(class_2680 state, class_1922 world, class_2338 pos) {
		return class_259.method_1077();
	}

	public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		class_2350 direction = getOppositePartDirection(state).method_10153();
		return SHAPE.get(direction);
	}

	public static class_2350 getOppositePartDirection(class_2680 state) {
		class_2350 direction = state.method_11654(field_11177);
		return state.method_11654(PART) == class_2742.field_12560 ? direction.method_10153() : direction;
	}

	public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
		super.method_9567(world, pos, state, placer, itemStack);
		if (!world.field_9236) {
			placeOtherPart(world, pos, state);
		}
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(field_11177, PART);
	}
	
	private void placeOtherPart(class_1937 world, class_2338 pos, class_2680 state) {
		class_2338 blockPos = pos.method_10093(state.method_11654(field_11177));
		world.method_8652(blockPos, state.method_11657(PART, class_2742.field_12560), class_2248.field_31036);
		world.method_8408(pos, class_2246.field_10124);
		state.method_30101(world, pos, class_2248.field_31036);
	}
	
	private void removeOtherPart(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
		class_2742 bedPart = state.method_11654(PART);
		if (bedPart == class_2742.field_12557) {
			class_2338 blockPos = pos.method_10093(getDirectionTowardsOtherPart(bedPart, state.method_11654(field_11177)));
			class_2680 blockState = world.method_8320(blockPos);
			if (blockState.method_27852(this) && blockState.method_11654(PART) == class_2742.field_12560) {
				world.method_8652(blockPos, class_2246.field_10124.method_9564(), class_2248.field_31036 | class_2248.field_31032);
				if (player != null)
					world.method_8444(player, class_6088.field_31144, blockPos, class_2248.method_9507(blockState));
			}
		}
	}
}