package net.satisfy.foundation.client.render;

import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.satisfy.foundation.block.WallDecorationBlock;
import net.satisfy.foundation.block.WallDecorationBlockEntity;

public class WallDecorationRenderer implements class_827<WallDecorationBlockEntity> {
    private static final int TEXT_COLOR = 0xFADFB0;
    private static final int FULL_BRIGHT = 0xF000F0;

    public WallDecorationRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(WallDecorationBlockEntity entity, float partialTick, class_4587 poseStack, class_4597 buffer, int light, int overlay) {
        String text = entity.getText(0).getString();
        if (entity.method_11010().method_26204() instanceof WallDecorationBlock block && text.length() > block.getMaxLength()) {
            text = text.substring(0, block.getMaxLength());
        }
        if (text.isEmpty()) {
            return;
        }
        class_327 font = class_310.method_1551().field_1772;
        class_2350 facing = entity.method_11010().method_11654(WallDecorationBlock.field_11177);
        float rotation = switch (facing) {
            case field_11043 -> 180F;
            case field_11039 -> -90F;
            case field_11034 -> 90F;
            default -> 0F;
        };
        poseStack.method_22903();
        poseStack.method_22904(0.5, 1.0, 0.5);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
        poseStack.method_22904(0, -0.45, -0.425);
        poseStack.method_22905(0.01F, -0.01F, 0.01F);
        float x = -font.method_1727(text) / 2F;
        if (entity.isGlowing()) {
            class_4597.class_4598 seeThrough = class_310.method_1551().method_22940().method_23000();
            font.method_22942(class_2561.method_43470(text).method_30937(), x, 0, TEXT_COLOR, false, poseStack.method_23760().method_23761(), seeThrough, class_327.class_6415.field_33994, 0, FULL_BRIGHT);
            seeThrough.method_22993();
        } else {
            font.method_22942(class_2561.method_43470(text).method_30937(), x, 0, TEXT_COLOR, false, poseStack.method_23760().method_23761(), buffer, class_327.class_6415.field_33993, 0, light);
        }
        poseStack.method_22909();
    }
}
