package net.satisfy.foundation.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import net.satisfy.foundation.rarity.FoundationRarities;
import net.satisfy.foundation.rarity.FoundationRarity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Colors the held item name above the hotbar with its {@link FoundationRarity}. */
@Mixin(class_329.class)
public abstract class GuiMixin {
    @Redirect(method = "renderSelectedItemName", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getHoverName()Lnet/minecraft/network/chat/Component;"), require = 0)
    private class_2561 foundation$rarityName(class_1799 stack) {
        FoundationRarity rarity = FoundationRarities.get(stack);
        class_2561 name = stack.method_7964();
        return rarity == null ? name : rarity.apply(name);
    }
}
