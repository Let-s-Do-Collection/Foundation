package net.satisfy.foundation.overlay;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

/** Supplies the content of the {@link BlockInfoOverlay} for a block. */
public interface BlockInfoProvider {
    /**
     * @param hit null if the block is tracked but not targeted
     * @return sections to show, empty list = not my block
     */
    List<InfoSection> describe(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_3965 hit);

    /** Hook right before the background gets drawn, e.g. to mark a {@link net.satisfy.foundation.tooltip.TooltipBorder}. */
    default void beforeBackground(class_1937 level, class_2338 pos, class_2680 state) {
    }
}
