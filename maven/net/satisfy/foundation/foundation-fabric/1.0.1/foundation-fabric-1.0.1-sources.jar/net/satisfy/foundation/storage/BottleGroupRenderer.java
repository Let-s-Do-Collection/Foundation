package net.satisfy.foundation.storage;

import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.satisfy.foundation.client.render.WobbleAnimation;
import net.satisfy.foundation.render.ClientUtil;

public class BottleGroupRenderer implements StorageTypeRenderer {
    private static final String FAKE_MODEL = "fake_model";

    @Override
    public void render(StorageBlockEntity entity, class_4587 poseStack, class_4597 buffers, class_2371<class_1799> items) {
        poseStack.method_22904(-0.5, 0, -0.5);
        switch (count(items)) {
            case 1 -> renderOne(entity, poseStack, buffers, items);
            case 2 -> renderTwo(entity, poseStack, buffers, items);
            case 3 -> renderThree(entity, poseStack, buffers, items);
        }
    }

    protected boolean isLying(class_1799 stack) {
        return false;
    }

    protected class_2680 stateFor(class_1747 item) {
        class_2680 state = item.method_7711().method_9564();
        for (class_2769<?> property : state.method_28501()) {
            if (property instanceof class_2746 fake && property.method_11899().equals(FAKE_MODEL)) {
                return state.method_11657(fake, false);
            }
        }
        return state;
    }

    protected void renderBottle(class_1799 stack, int index, StorageBlockEntity entity, class_4587 poseStack, class_4597 buffers) {
        if (!(stack.method_7909() instanceof class_1747 item)) {
            return;
        }
        poseStack.method_22903();
        WobbleAnimation.apply(poseStack, entity.method_10997(), entity.getWobbleStart(), WobbleAnimation.seed(entity.method_11016().method_10063() + index));
        ClientUtil.renderBlock(stateFor(item), poseStack, buffers, entity);
        poseStack.method_22909();
    }

    private static int count(class_2371<class_1799> items) {
        int count = 0;
        for (class_1799 stack : items) {
            if (!stack.method_7960()) {
                count++;
            }
        }
        return count;
    }

    private void renderOne(StorageBlockEntity entity, class_4587 poseStack, class_4597 buffers, class_2371<class_1799> items) {
        renderBottle(items.get(0), 0, entity, poseStack, buffers);
    }

    private void renderTwo(StorageBlockEntity entity, class_4587 poseStack, class_4597 buffers, class_2371<class_1799> items) {
        poseStack.method_46416(-0.15F, 0F, -0.25F);
        renderBottle(items.get(0), 0, entity, poseStack, buffers);
        poseStack.method_46416(0.1F, 0F, 0.8F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(30));
        renderBottle(items.get(1), 1, entity, poseStack, buffers);
    }

    private void renderThree(StorageBlockEntity entity, class_4587 poseStack, class_4597 buffers, class_2371<class_1799> items) {
        poseStack.method_46416(-0.25F, 0F, -0.25F);
        renderBottle(items.get(0), 0, entity, poseStack, buffers);
        poseStack.method_46416(0.15F, 0F, 0.5F);
        renderBottle(items.get(1), 1, entity, poseStack, buffers);
        class_1799 third = items.get(2);
        if (isLying(third)) {
            poseStack.method_46416(0.35F, 0.7F, -0.13F);
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(90));
        } else {
            poseStack.method_46416(0.1F, 0F, 0F);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(30));
        }
        renderBottle(third, 2, entity, poseStack, buffers);
    }
}
