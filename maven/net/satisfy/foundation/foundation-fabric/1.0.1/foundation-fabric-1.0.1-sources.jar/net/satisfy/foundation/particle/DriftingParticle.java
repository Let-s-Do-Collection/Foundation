package net.satisfy.foundation.particle;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.BooleanSupplier;
import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class DriftingParticle extends class_4003 {
    private static final int FADE_DURATION = 6;

    public enum Style {
        LEAF(0.98F, 0.82F, 0.88F, false),
        FLUFF(0.96F, 0.85F, 0.9F, true);

        private final float friction;
        private final float swayZFactor;
        private final float growthDamping;
        private final boolean translucent;

        Style(float friction, float swayZFactor, float growthDamping, boolean translucent) {
            this.friction = friction;
            this.swayZFactor = swayZFactor;
            this.growthDamping = growthDamping;
            this.translucent = translucent;
        }
    }

    public record MotionProfile(int minimumLifetime, int maximumLifetime, float minimumSwaySpeed, float maximumSwaySpeed, float minimumSwayAmount, float maximumSwayAmount, float minimumUpwardVelocityStart, float maximumUpwardVelocityStart, float minimumUpwardVelocityEnd, float maximumUpwardVelocityEnd, float minimumSideVelocity, float maximumSideVelocity, float minimumRotationSpeed, float maximumRotationSpeed, float targetAlpha, float initialScale, float initialScaleVariance, float minimumScale, float maximumScale, float growthSpeed, float minimumGravityStrength, float maximumGravityStrength, float minimumDownwardAcceleration, float maximumDownwardAcceleration, float minimumGlideStrength, float maximumGlideStrength) {
        public static final MotionProfile LEAF = new MotionProfile(30, 42, 1.4F, 2.1F, 0.055F, 0.105F, 0.03F, 0.055F, -0.015F, 0.0F, 0.03F, 0.06F, 0.035F, 0.07F, 1.0F, 0.075F, 0.015F, 0.095F, 0.135F, 0.012F, 0.7F, 1.0F, 0.022F, 0.036F, 0.1F, 0.16F);
        public static final MotionProfile LEAF_RISING = new MotionProfile(34, 46, 1.25F, 1.9F, 0.05F, 0.09F, 0.065F, 0.095F, -0.005F, 0.01F, 0.008F, 0.02F, 0.03F, 0.06F, 1.0F, 0.075F, 0.015F, 0.095F, 0.135F, 0.012F, 0.62F, 0.9F, 0.018F, 0.03F, 0.08F, 0.14F);
        public static final MotionProfile FLUFF = new MotionProfile(28, 42, 1.1F, 1.8F, 0.045F, 0.085F, 0.05F, 0.085F, -0.02F, 0.005F, 0.01F, 0.03F, 0.0F, 0.0F, 0.92F, 0.09F, 0.03F, 0.11F, 0.18F, 0.012F, 0.45F, 0.72F, 0.012F, 0.024F, 0.08F, 0.14F);
    }

    private final Style style;
    private final float swayPhase;
    private final float swaySpeed;
    private final float swayAmountX;
    private final float swayAmountZ;
    private final float upwardVelocityStart;
    private final float upwardVelocityEnd;
    private final float sideVelocityX;
    private final float sideVelocityZ;
    private final float targetAlpha;
    private final float maximumScale;
    private final float gravityStrength;
    private final float downwardAcceleration;
    private final float glideStrength;
    private float rotationSpeed;
    private float previousQuadSize;
    private float growthSpeed;

    protected DriftingParticle(class_638 level, double x, double y, double z, Style style, MotionProfile profile) {
        super(level, x, y, z, 0.0D, 0.0D, 0.0D);
        this.style = style;
        this.field_28786 = style.friction;
        this.field_3844 = 0.0F;
        this.field_3862 = true;
        this.field_3847 = profile.minimumLifetime + field_3840.method_43048(profile.maximumLifetime - profile.minimumLifetime + 1);
        this.swayPhase = field_3840.method_43057() * class_3532.field_29846;
        this.swaySpeed = range(profile.minimumSwaySpeed, profile.maximumSwaySpeed);
        this.swayAmountX = range(profile.minimumSwayAmount, profile.maximumSwayAmount);
        this.swayAmountZ = range(profile.minimumSwayAmount, profile.maximumSwayAmount);
        this.upwardVelocityStart = range(profile.minimumUpwardVelocityStart, profile.maximumUpwardVelocityStart);
        this.upwardVelocityEnd = range(profile.minimumUpwardVelocityEnd, profile.maximumUpwardVelocityEnd);
        this.sideVelocityX = range(profile.minimumSideVelocity, profile.maximumSideVelocity) * randomSign();
        this.sideVelocityZ = range(profile.minimumSideVelocity, profile.maximumSideVelocity) * randomSign();
        this.rotationSpeed = range(profile.minimumRotationSpeed, profile.maximumRotationSpeed) * randomSign();
        this.targetAlpha = profile.targetAlpha;
        this.maximumScale = range(profile.minimumScale, profile.maximumScale);
        this.gravityStrength = range(profile.minimumGravityStrength, profile.maximumGravityStrength);
        this.downwardAcceleration = range(profile.minimumDownwardAcceleration, profile.maximumDownwardAcceleration);
        this.glideStrength = range(profile.minimumGlideStrength, profile.maximumGlideStrength);
        this.field_17867 = profile.initialScale + field_3840.method_43057() * profile.initialScaleVariance;
        this.previousQuadSize = field_17867;
        this.growthSpeed = profile.growthSpeed;
        this.field_3841 = 0.0F;

        if (style == Style.LEAF) {
            this.field_3839 = field_3840.method_43057() * class_3532.field_29846;
            int foliage = level.method_23753(class_2338.method_49637(x, y, z)).comp_349().method_8698();
            this.field_3861 = (foliage >> 16 & 255) / 255.0F;
            this.field_3842 = (foliage >> 8 & 255) / 255.0F;
            this.field_3859 = (foliage & 255) / 255.0F;
        } else {
            this.field_3839 = field_3840.method_43057() * 0.15F - 0.075F;
            this.field_3861 = 0.96F + field_3840.method_43057() * 0.03F;
            this.field_3842 = 0.95F + field_3840.method_43057() * 0.03F;
            this.field_3859 = 0.93F + field_3840.method_43057() * 0.03F;
        }
        this.field_3857 = field_3839;
    }

    private float range(float min, float max) {
        return min + field_3840.method_43057() * (max - min);
    }

    private float randomSign() {
        return field_3840.method_43056() ? 1.0F : -1.0F;
    }

    @Override
    public void method_3070() {
        field_3858 = field_3874;
        field_3838 = field_3854;
        field_3856 = field_3871;
        field_3857 = field_3839;
        previousQuadSize = field_17867;

        if (field_3866++ >= field_3847) {
            method_3085();
            return;
        }

        float progress = (float) field_3866 / (float) field_3847;
        float swayAngle = swayPhase + progress * class_3532.field_29846 * swaySpeed;
        float upwardVelocity = class_3532.method_16439(progress, upwardVelocityStart, upwardVelocityEnd);
        float glideCurve = class_3532.method_15374(progress * class_3532.field_29844) * glideStrength;
        float verticalVelocity = upwardVelocity - (gravityStrength * progress * progress + downwardAcceleration * field_3866 * progress - glideCurve);

        field_3852 = sideVelocityX + class_3532.method_15374(swayAngle) * swayAmountX * 0.08F;
        field_3850 = sideVelocityZ + class_3532.method_15362(swayAngle * style.swayZFactor) * swayAmountZ * 0.08F;
        field_3869 = verticalVelocity * 0.08F;
        method_3069(field_3852, field_3869, field_3850);

        if (field_3845) {
            if (style == Style.LEAF) {
                field_3852 = 0.0D;
                field_3850 = 0.0D;
                rotationSpeed = 0.0F;
            } else {
                field_3852 *= 0.35D;
                field_3850 *= 0.35D;
            }
            field_3869 = 0.0D;
        }

        if (style == Style.LEAF) {
            field_3839 += rotationSpeed;
        } else {
            field_3839 = class_3532.method_15374(progress * class_3532.field_29846 + swayPhase) * 0.12F;
        }

        if (field_17867 < maximumScale) {
            field_17867 = Math.min(maximumScale, field_17867 + growthSpeed);
            growthSpeed *= style.growthDamping;
        }

        if (field_3866 < FADE_DURATION) {
            field_3841 = class_3532.method_16439((float) field_3866 / FADE_DURATION, 0.0F, targetAlpha);
        } else {
            int remaining = field_3847 - field_3866;
            field_3841 = remaining < FADE_DURATION ? targetAlpha * ((float) remaining / FADE_DURATION) : targetAlpha;
        }
    }

    @Override
    public float method_18132(float partialTick) {
        return class_3532.method_16439(partialTick, previousQuadSize, field_17867);
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return style.translucent ? class_3999.field_17829 : class_3999.field_17828;
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;
        private final Style style;
        private final MotionProfile profile;
        private final BooleanSupplier enabled;

        public Provider(class_4002 sprites, Style style, MotionProfile profile) {
            this(sprites, style, profile, () -> true);
        }

        public Provider(class_4002 sprites, Style style, MotionProfile profile, BooleanSupplier enabled) {
            this.sprites = sprites;
            this.style = style;
            this.profile = profile;
            this.enabled = enabled;
        }

        @Override
        public @Nullable class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            if (!enabled.getAsBoolean()) {
                return null;
            }
            DriftingParticle particle = new DriftingParticle(level, x, y, z, style, profile);
            particle.method_18140(sprites);
            return particle;
        }
    }
}
