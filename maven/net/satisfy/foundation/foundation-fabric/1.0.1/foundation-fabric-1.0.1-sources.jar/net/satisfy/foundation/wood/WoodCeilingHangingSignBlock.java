package net.satisfy.foundation.wood;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_2680;
import net.minecraft.class_4719;
import net.minecraft.class_5558;
import net.minecraft.class_7713;

public class WoodCeilingHangingSignBlock extends class_7713 {
    private final Supplier<? extends class_2591<?>> blockEntityType;

    public WoodCeilingHangingSignBlock(class_4719 woodType, class_2251 properties, Supplier<? extends class_2591<?>> blockEntityType) {
        super(woodType, properties);
        this.blockEntityType = blockEntityType;
    }

    @Override
    public @NotNull class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new WoodHangingSignBlockEntity(blockEntityType.get(), pos, state);
    }

    @Override
    public <T extends class_2586> @Nullable class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return type == blockEntityType.get() ? (tickLevel, pos, tickState, blockEntity) -> class_2625.method_49837(tickLevel, pos, tickState, (class_2625) blockEntity) : null;
    }
}
