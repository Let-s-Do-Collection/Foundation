package net.satisfy.foundation.recipe;

import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2960;
import net.minecraft.class_4284;
import net.minecraft.class_7225;

/**
 * World saved data holding the unlocked recipes per player uuid.
 * (name still says farm_and_charm, kept so old worlds keep their data)
 */
public class RecipeUnlockSavedData extends class_18 {
    private final Map<UUID, Set<class_2960>> playerRecipes = new HashMap<>();
    public static final String DATA_NAME = "farm_and_charm_recipe_unlock_data";

    public RecipeUnlockSavedData() {}

    public RecipeUnlockSavedData(class_2487 compoundTag, class_7225.class_7874 provider) {
    }

    public static RecipeUnlockSavedData fromNbt(class_2487 tag) {
        RecipeUnlockSavedData data = new RecipeUnlockSavedData();
        class_2487 playersTag = tag.method_10562("players");
        for (String key : playersTag.method_10541()) {
            class_2499 list = playersTag.method_10554(key, 8);
            Set<class_2960> recipes = new HashSet<>();
            for (int i = 0; i < list.size(); i++) {
                recipes.add(class_2960.method_60654(list.method_10608(i)));
            }
            try {
                UUID uuid = UUID.fromString(key);
                data.playerRecipes.put(uuid, recipes);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return data;
    }

    @Override
    public class_2487 method_75(class_2487 compoundTag, class_7225.class_7874 provider) {
        class_2487 playersTag = new class_2487();
        for (Map.Entry<UUID, Set<class_2960>> entry : playerRecipes.entrySet()) {
            class_2499 list = new class_2499();
            for (class_2960 recipe : entry.getValue()) {
                list.add(class_2519.method_23256(recipe.toString()));
            }
            playersTag.method_10566(entry.getKey().toString(), list);
        }
        compoundTag.method_10566("players", playersTag);
        return compoundTag;
    }

    public Set<class_2960> getPlayerRecipes(UUID uuid) {
        return playerRecipes.computeIfAbsent(uuid, k -> new HashSet<>());
    }

    public void setPlayerRecipes(UUID uuid, Set<class_2960> recipes) {
        playerRecipes.put(uuid, recipes);
        method_80();
    }

    public static class_8645<RecipeUnlockSavedData> factory() {
        return new class_18.class_8645<RecipeUnlockSavedData>(RecipeUnlockSavedData::new, RecipeUnlockSavedData::new, class_4284.field_45079);
    }
}