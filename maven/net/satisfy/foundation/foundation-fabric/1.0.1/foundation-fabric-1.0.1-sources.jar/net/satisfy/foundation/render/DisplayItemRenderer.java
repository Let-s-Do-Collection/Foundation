package net.satisfy.foundation.render;

import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

/** Renders items as displayed on shelves, plates etc. */
public final class DisplayItemRenderer {
    private DisplayItemRenderer() {
    }

    /** Item lying flat on the surface. */
    public static void renderFlat(class_1799 stack, class_4587 poseStack, class_4597 buffers, int light, int overlay, @Nullable class_1937 level, double x, double y, double z, float yaw, float scale, int seed) {
        if (stack.method_7960()) {
            return;
        }
        poseStack.method_22903();
        poseStack.method_22904(x, y, z);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(yaw));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
        poseStack.method_22905(scale, scale, scale);
        class_310.method_1551().method_1480().method_23178(stack, class_811.field_4319, light, overlay, poseStack, buffers, level, seed);
        poseStack.method_22909();
    }

    /** Item standing upright, no roll. */
    public static void renderUpright(class_1799 stack, class_4587 poseStack, class_4597 buffers, int light, int overlay, @Nullable class_1937 level, double x, double y, double z, float yaw, float scale, int seed) {
        renderUpright(stack, poseStack, buffers, light, overlay, level, x, y, z, yaw, 0.0F, scale, seed);
    }

    /** Item standing upright, tilted by {@code roll} degrees. */
    public static void renderUpright(class_1799 stack, class_4587 poseStack, class_4597 buffers, int light, int overlay, @Nullable class_1937 level, double x, double y, double z, float yaw, float roll, float scale, int seed) {
        if (stack.method_7960()) {
            return;
        }
        poseStack.method_22903();
        poseStack.method_22904(x, y, z);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(yaw));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(roll));
        poseStack.method_22905(scale, scale, scale);
        class_310.method_1551().method_1480().method_23178(stack, class_811.field_4319, light, overlay, poseStack, buffers, level, seed);
        poseStack.method_22909();
    }
}
