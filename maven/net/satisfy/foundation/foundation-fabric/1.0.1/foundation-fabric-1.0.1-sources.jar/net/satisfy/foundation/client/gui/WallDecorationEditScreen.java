package net.satisfy.foundation.client.gui;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.satisfy.foundation.block.WallDecorationBlock;
import net.satisfy.foundation.block.WallDecorationBlockEntity;
import net.satisfy.foundation.text.SetTextPacket;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class WallDecorationEditScreen extends class_437 {
    private static final int IMAGE_SIZE = 128;
    private static final int TEXT_COLOR = 0xFADFB0;

    private final WallDecorationBlockEntity entity;
    private final class_2960 texture;
    private final int maxLength;
    private class_342 textField;

    private WallDecorationEditScreen(WallDecorationBlockEntity entity, class_2960 texture, int maxLength) {
        super(class_2561.method_43471("gui.foundation.wall_decoration.edit"));
        this.entity = entity;
        this.texture = texture;
        this.maxLength = maxLength;
    }

    public static void open(WallDecorationBlockEntity entity) {
        if (entity.method_11010().method_26204() instanceof WallDecorationBlock block) {
            class_310.method_1551().method_1507(new WallDecorationEditScreen(entity, block.getEditTexture(), block.getMaxLength()));
        }
    }

    @Override
    protected void method_25426() {
        textField = new class_342(field_22793, field_22789 / 2 - 18, field_22790 / 2 - 23, 200, 20, class_2561.method_43473());
        textField.method_1880(maxLength);
        textField.method_1852(entity.getText(0).getString());
        textField.method_1858(false);
        textField.method_1868(TEXT_COLOR);
        method_37063(textField);
        method_48265(textField);
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), button -> method_25419())
                .method_46434(field_22789 / 2 - 50, field_22790 - 40, 100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        method_57735(graphics);
        graphics.method_25293(texture, field_22789 / 2 - 65, field_22790 / 2 - 90, IMAGE_SIZE, IMAGE_SIZE, 0, 0, 16, 16, 16, 16);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);
    }

    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        SetTextPacket.sendToServer(new SetTextPacket(entity.method_11016(), List.of(textField.method_1882())));
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
