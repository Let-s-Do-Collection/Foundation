package net.satisfy.foundation.menu;

import net.minecraft.class_243;
import net.minecraft.class_3218;

public interface ExperienceSource {
    void dropExperience(class_3218 level, class_243 pos);
}
