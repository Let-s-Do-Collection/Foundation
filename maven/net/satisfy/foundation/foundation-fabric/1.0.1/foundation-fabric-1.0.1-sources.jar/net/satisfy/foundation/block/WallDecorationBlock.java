package net.satisfy.foundation.block;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import net.satisfy.foundation.client.gui.WallDecorationEditScreen;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class WallDecorationBlock extends FacingBlock implements class_2343 {
    private static final Map<class_2350, class_265> SHAPES = new EnumMap<>(Map.of(
            class_2350.field_11043, class_2248.method_9541(0, 0, 15, 16, 16, 16),
            class_2350.field_11035, class_2248.method_9541(0, 0, 0, 16, 16, 1),
            class_2350.field_11039, class_2248.method_9541(15, 0, 0, 16, 16, 16),
            class_2350.field_11034, class_2248.method_9541(0, 0, 0, 1, 16, 16)));

    private final Supplier<? extends class_2591<? extends WallDecorationBlockEntity>> blockEntityType;
    private final class_2960 editTexture;
    private final int maxLength;

    public WallDecorationBlock(class_2251 properties, Supplier<? extends class_2591<? extends WallDecorationBlockEntity>> blockEntityType, class_2960 editTexture, int maxLength) {
        super(properties);
        this.blockEntityType = blockEntityType;
        this.editTexture = editTexture;
        this.maxLength = maxLength;
    }

    public class_2960 getEditTexture() {
        return editTexture;
    }

    public int getMaxLength() {
        return maxLength;
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPES.get(state.method_11654(field_11177));
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2350 direction = state.method_11654(field_11177);
        class_2338 supportPos = pos.method_10093(direction.method_10153());
        return level.method_8320(supportPos).method_26206(level, supportPos, direction);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2680 state = method_9564();
        for (class_2350 direction : context.method_7718()) {
            if (direction.method_10166().method_10179()) {
                state = state.method_11657(field_11177, direction.method_10153());
                if (state.method_26184(context.method_8045(), context.method_8037())) {
                    return state;
                }
            }
        }
        return null;
    }

    @Override
    public @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (direction.method_10153() == state.method_11654(field_11177) && !state.method_26184(level, pos)) {
            return class_2246.field_10124.method_9564();
        }
        return state;
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!(level.method_8321(pos) instanceof WallDecorationBlockEntity decoration)) {
            return class_9062.field_47731;
        }
        if (stack.method_31574(class_1802.field_28410)) {
            if (decoration.isGlowing()) {
                return class_9062.field_47729;
            }
            decoration.setGlowing(true);
            if (!player.method_7337()) {
                stack.method_7934(1);
            }
            return class_9062.field_47728;
        }
        if (level.field_9236) {
            WallDecorationEditScreen.open(decoration);
        }
        return class_9062.field_47728;
    }

    @Override
    public @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return blockEntityType.get().method_11032(pos, state);
    }

    @Override
    public void method_9568(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        tooltip.add(class_2561.method_43471("tooltip.foundation.canbeplacedwall").method_27692(class_124.field_1080));
    }
}
