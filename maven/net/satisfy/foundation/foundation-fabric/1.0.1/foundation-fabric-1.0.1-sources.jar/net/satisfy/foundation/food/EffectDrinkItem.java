package net.satisfy.foundation.food;

import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.satisfy.foundation.util.LibUtil;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Objects;
import org.jetbrains.annotations.NotNull;

/**
 * Drink item that shows its food effects in the tooltip like a potion does.
 *
 * Note: {@code duration} in the constructor is not used anymore, kept for compat.
 */
@SuppressWarnings("unused")
public class EffectDrinkItem extends class_1792 {
    private final boolean returnBottle;

    public EffectDrinkItem(class_1793 properties, int duration, boolean returnBottle) {
        super(properties);
        this.returnBottle = returnBottle;
    }

    @Override
    public @NotNull class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 itemStack, class_1937 level, class_1309 livingEntity) {
        class_1799 eaten = livingEntity.method_60492(level, itemStack);
        if (this.returnBottle) {
            return LibUtil.convertStackAfterFinishUsing(livingEntity, eaten, class_1802.field_8469, this);
        }
        return eaten;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        super.method_7851(itemStack, tooltipContext, tooltip, tooltipFlag);

        List<class_4174.class_9423> possibleEffects = itemStack.method_57826(class_9334.field_50075)
                ? Objects.requireNonNull(itemStack.method_57824(class_9334.field_50075)).comp_2495()
                : Lists.newArrayList();

        List<Pair<class_6880<class_1320>, class_1322>> attributeModifiers = Lists.newArrayList();

        if (possibleEffects.isEmpty()) {
            tooltip.add(class_2561.method_43471("effect.none").method_27692(class_124.field_1080));
        } else {
            for (class_4174.class_9423 possibleEffect : possibleEffects) {
                class_5250 effectLine = class_2561.method_43471(possibleEffect.comp_2496().method_5586());
                class_1291 mobEffect = possibleEffect.comp_2496().method_5579().comp_349();

                mobEffect.method_55650(possibleEffect.comp_2496().method_5578(), (attributeHolder, baseModifier) -> {
                    class_1322 scaledModifier = new class_1322(
                            baseModifier.comp_2447(),
                            baseModifier.comp_2449() * (double) (possibleEffect.comp_2496().method_5578() + 1),
                            baseModifier.comp_2450()
                    );
                    attributeModifiers.add(new Pair<>(attributeHolder, scaledModifier));
                });

                if (possibleEffect.comp_2496().method_5584() > 20) {
                    effectLine = class_2561.method_43469(
                            "potion.withDuration",
                            effectLine,
                            class_1292.method_5577(possibleEffect.comp_2496(), possibleEffect.comp_2497(), tooltipContext.method_59531())
                    );
                }

                tooltip.add(effectLine.method_27692(mobEffect.method_18792().method_18793()));
            }
        }

        if (!attributeModifiers.isEmpty()) {
            tooltip.add(class_2561.method_43473());
            tooltip.add(class_2561.method_43471("potion.whenDrank").method_27692(class_124.field_1064));

            for (Pair<class_6880<class_1320>, class_1322> pair : attributeModifiers) {
                class_1322 modifier = pair.getSecond();
                double amount = modifier.comp_2449();
                double displayValue;

                if (modifier.comp_2450() != class_1322.class_1323.field_6330 && modifier.comp_2450() != class_1322.class_1323.field_6331) {
                    displayValue = amount;
                } else {
                    displayValue = amount * 100.0;
                }

                if (amount > 0.0) {
                    tooltip.add(class_2561.method_43469(
                            "attribute.modifier.plus." + modifier.comp_2450().method_56082(),
                            class_9285.field_49329.format(displayValue),
                            class_2561.method_43471(pair.getFirst().comp_349().method_26830())
                    ).method_27692(class_124.field_1078));
                } else if (amount < 0.0) {
                    displayValue *= -1.0;
                    tooltip.add(class_2561.method_43469(
                            "attribute.modifier.take." + modifier.comp_2450().method_56082(),
                            class_9285.field_49329.format(displayValue),
                            class_2561.method_43471(pair.getFirst().comp_349().method_26830())
                    ).method_27692(class_124.field_1061));
                }
            }
        }
    }
}
