package net.satisfy.foundation.wood;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

public record BoatWood(class_2960 id, Supplier<? extends class_1792> boat, Supplier<? extends class_1792> chestBoat) {
    private static final Map<class_2960, BoatWood> WOODS = new LinkedHashMap<>();

    public static BoatWood register(class_2960 id, Supplier<? extends class_1792> boat, Supplier<? extends class_1792> chestBoat) {
        BoatWood wood = new BoatWood(id, boat, chestBoat);
        WOODS.put(id, wood);
        return wood;
    }

    public static @Nullable BoatWood get(class_2960 id) {
        return WOODS.get(id);
    }

    public static List<BoatWood> all() {
        return Collections.unmodifiableList(new ArrayList<>(WOODS.values()));
    }

    public static List<BoatWood> byNamespace(String namespace) {
        return WOODS.values().stream().filter(wood -> wood.id.method_12836().equals(namespace)).toList();
    }

    public class_1792 item(boolean chest) {
        return chest ? chestBoat.get() : boat.get();
    }

    public class_2960 texture(boolean chest) {
        return id.method_45134(path -> "textures/entity/" + (chest ? "chest_boat/" : "boat/") + path + ".png");
    }

    public class_2960 modelName(boolean chest) {
        return id.method_45134(path -> (chest ? "chest_boat/" : "boat/") + path);
    }
}
