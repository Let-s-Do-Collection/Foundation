package net.satisfy.foundation.banner;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

/** Wall variant of the completionist banner, needs a solid block behind it. */
public class CompletionistWallBannerBlock extends CompletionistBannerBlock {
    public static final class_2753 FACING = class_2383.field_11177;
    private static final Map<class_2350, class_265> SHAPES = Maps.newEnumMap(ImmutableMap.of(class_2350.field_11035, method_9541(0.0, 0.0, 14.0, 16.0, 12.5, 16.0), class_2350.field_11043, method_9541(0.0, 0.0, 0.0, 16.0, 12.5, 2.0), class_2350.field_11034, method_9541(14.0, 0.0, 0.0, 16.0, 12.5, 16.0), class_2350.field_11039, method_9541(0.0, 0.0, 0.0, 2.0, 12.5, 16.0)));

    public CompletionistWallBannerBlock(class_2251 properties, BannerSettings settings) {
        super(properties, settings);
    }

    protected void makeDefaultState() {
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    public @NotNull String method_9539() {
        return this.method_8389().method_7876();
    }

    public boolean method_9558(@NotNull class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return levelReader.method_8320(blockPos.method_10093(blockState.method_11654(FACING))).method_51367();
    }

    public @NotNull class_2680 method_9559(@NotNull class_2680 blockState, @NotNull class_2350 direction, @NotNull class_2680 blockState2, @NotNull class_1936 levelAccessor, @NotNull class_2338 blockPos, @NotNull class_2338 blockPos2) {
        if (direction == blockState.method_11654(FACING) && !blockState.method_26184(levelAccessor, blockPos)) {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(blockState, direction, blockState2, levelAccessor, blockPos, blockPos2);
    }

    public @NotNull class_265 method_9530(@NotNull class_2680 blockState, @NotNull class_1922 blockGetter, @NotNull class_2338 blockPos, @NotNull class_3726 collisionContext) {
        return SHAPES.get(blockState.method_11654(FACING));
    }

    public class_2680 method_9605(class_1750 context) {
        class_2680 blockState = this.method_9564();
        class_1937 level = context.method_8045();
        class_2338 blockPos = context.method_8037();

        for (class_2350 direction : context.method_7718()) {
            if (direction.method_10166().method_10179()) {
                class_2350 oppositeDirection = direction.method_10153();
                class_2680 oppositeState = blockState.method_11657(FACING, oppositeDirection);
                if (oppositeState.method_26184(level, blockPos)) {
                    return oppositeState;
                }
            }
        }
        return null;
    }

    public @NotNull class_2680 method_9598(class_2680 blockState, class_2470 rotation) {
        return blockState.method_11657(FACING, rotation.method_10503(blockState.method_11654(FACING)));
    }

    public @NotNull class_2680 method_9569(class_2680 blockState, class_2415 mirror) {
        return blockState.method_26186(mirror.method_10345(blockState.method_11654(FACING)));
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
