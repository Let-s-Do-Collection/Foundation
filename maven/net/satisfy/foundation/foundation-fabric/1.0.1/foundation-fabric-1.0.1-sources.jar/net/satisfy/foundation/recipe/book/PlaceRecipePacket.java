package net.satisfy.foundation.recipe.book;

import dev.architectury.networking.NetworkManager;
import net.minecraft.class_1703;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_8786;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.satisfy.foundation.Foundation;
import net.satisfy.foundation.recipe.RecipeUnlockManager;

/** Client -> server: recipe clicked in the station recipe book, fill the inputs. */
public record PlaceRecipePacket(int containerId, class_2960 recipe, boolean max) implements class_8710 {
    public static final class_9154<PlaceRecipePacket> TYPE = new class_9154<>(Foundation.identifier("place_recipe"));
    public static final class_9139<class_9129, PlaceRecipePacket> CODEC = class_9139.method_56436(
            class_9135.field_48550, PlaceRecipePacket::containerId,
            class_2960.field_48267, PlaceRecipePacket::recipe,
            class_9135.field_48547, PlaceRecipePacket::max,
            PlaceRecipePacket::new);

    public static void init() {
        NetworkManager.registerReceiver(NetworkManager.c2s(), TYPE, CODEC, (packet, context) -> context.queue(() -> {
            if (context.getPlayer() instanceof class_3222 player) {
                handle(packet, player);
            }
        }));
    }

    private static void handle(PlaceRecipePacket packet, class_3222 player) {
        class_1703 menu = player.field_7512;
        if (menu.field_7763 != packet.containerId || !(menu instanceof StationRecipeBookMenu book) || !menu.method_7597(player)) {
            return;
        }
        class_8786<?> recipe = player.method_51469().method_8433().method_8130(packet.recipe).orElse(null);
        if (recipe == null || !book.recipeBookTypes().contains(recipe.comp_1933().method_17716())) {
            return;
        }
        if (book.recipeBookRequiresUnlock() && !RecipeUnlockManager.isUnlocked(player, recipe)) {
            return;
        }
        RecipePlacer.place(player.method_31548(), menu, book.recipeBookPlacementSlots(recipe), book.recipeBookPlacementIngredients(recipe), packet.max);
        menu.method_7623();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
