package net.satisfy.foundation.entity.ai;

import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1366;

public class AnimationAttackGoal extends class_1366 {
    private static final int TIMEOUT = 20 * 3;
    private final AttackAnimationMob animated;
    private final int attackDelay;
    private final int attackTick;
    private int counter;
    private int timeout;

    public <T extends class_1314 & AttackAnimationMob> AnimationAttackGoal(T mob, double speedModifier, boolean followingTargetEvenIfNotSeen, int attackDelay, int attackTick) {
        super(mob, speedModifier, followingTargetEvenIfNotSeen);
        this.animated = mob;
        this.attackDelay = attackDelay;
        this.attackTick = attackTick;
    }

    @Override
    public void method_6269() {
        timeout = 0;
        super.method_6269();
    }

    @Override
    public boolean method_6266() {
        return super.method_6266() && timeout < TIMEOUT;
    }

    @Override
    public void method_6268() {
        super.method_6268();
        animated.setAttacking(counter != 0);
        if (counter != 0) {
            counter++;
        }
        if (counter >= attackDelay) {
            counter = 0;
        }
    }

    @Override
    protected void method_6288(class_1309 target) {
        if (method_28347() && field_6503.method_42150(target) && field_6503.method_5985().method_6369(target)) {
            if (counter == 0) {
                counter++;
            }
            if (counter == attackTick) {
                animated.performAttack(target);
            }
            timeout = 0;
        } else {
            timeout++;
        }
    }

    @Override
    public void method_6270() {
        animated.setAttacking(false);
        counter = 0;
        super.method_6270();
    }
}
