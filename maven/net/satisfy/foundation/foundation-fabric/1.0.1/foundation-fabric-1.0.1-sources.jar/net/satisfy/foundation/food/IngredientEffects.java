package net.satisfy.foundation.food;

import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1263;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1844;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_4174.class_4175;
import net.minecraft.class_4174.class_9423;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9285;
import net.minecraft.class_9334;

/**
 * Helpers for moving mob effects from ingredients onto a result item.
 * Effects are {@code Pair<effect, chance>} everywhere.
 */
public class IngredientEffects {

    private static float saturationModifierOf(class_4174 base) {
        if (base.comp_2491() <= 0) return 0.0f;
        return base.comp_2492() / (base.comp_2491() * 2.0f);
    }

    /** Adds the effect to the stack's food component, skips if that effect type is already on it. */
    public static void addEffect(class_1799 stack, Pair<class_1293, Float> effect) {
        var base = stack.method_57824(class_9334.field_50075);
        if (base == null) return;
        var target = effect.getFirst().method_5579();
        for (var e : base.comp_2495()) {
            if (e.comp_2496().method_5579() == target) return;
        }
        var b = new class_4174.class_4175().method_19238(base.comp_2491()).method_19237(saturationModifierOf(base));
        if (base.comp_2493()) b.method_19240();
        if (base.comp_2494() == 0.8f) b.method_19241();
        for (var e : base.comp_2495()) b.method_19239(e.comp_2496(), e.comp_2497());
        b.method_19239(effect.getFirst(), effect.getSecond());
        stack.method_57379(class_9334.field_50075, b.method_19242());
    }

    private static void rebuildWithout(class_1799 stack) {
        var base = stack.method_57824(class_9334.field_50075);
        if (base == null) return;
        var b = new class_4174.class_4175().method_19238(base.comp_2491()).method_19237(saturationModifierOf(base));
        if (base.comp_2493()) b.method_19240();
        if (base.comp_2494() == 0.8f) b.method_19241();
        for (var e : base.comp_2495()) {
            if (e.comp_2496().method_5579() != class_1294.field_5903) b.method_19239(e.comp_2496(), e.comp_2497());
        }
        stack.method_57379(class_9334.field_50075, b.method_19242());
    }

    private static void removeHungerEffect(class_1799 stack) {
        rebuildWithout(stack);
    }

    private static void removeRawChickenEffects(class_1799 stack) {
        if (stack.method_7909() != class_1802.field_8726) return;
        removeHungerEffect(stack);
    }

    /**
     * Reads all effects of a stack (potion contents or food effects).
     * Heads up: strips hunger from the stack as a side effect.
     */
    public static List<Pair<class_1293, Float>> getEffects(class_1799 stack) {
        removeHungerEffect(stack);
        removeRawChickenEffects(stack);
        var out = Lists.<Pair<class_1293, Float>>newArrayList();
        if (stack.method_7909() instanceof class_1812) {
            var pc = stack.method_57825(class_9334.field_49651, class_1844.field_49274);
            pc.comp_2378().ifPresent(p -> {
                for (var e : p.comp_349().method_8049()) out.add(new Pair<>(e, 1.0f));
            });
            for (var e : pc.comp_2380()) out.add(new Pair<>(e, 1.0f));
            return out;
        }
        var base = stack.method_57824(class_9334.field_50075);
        if (base != null) for (var e : base.comp_2495()) out.add(new Pair<>(e.comp_2496(), e.comp_2497()));
        return out;
    }

    /** Rebuilds the food component, does nothing for potions. */
    public static void applyEffects(class_1799 stack) {
        var pc = stack.method_57825(class_9334.field_49651, class_1844.field_49274);
        if (pc.method_57405()) return;
        var base = stack.method_57824(class_9334.field_50075);
        if (base == null) return;
        var b = new class_4174.class_4175().method_19238(base.comp_2491()).method_19237(saturationModifierOf(base));
        if (base.comp_2493()) b.method_19240();
        if (base.comp_2494() == 0.8f) b.method_19241();
        for (var e : base.comp_2495()) b.method_19239(e.comp_2496(), e.comp_2497());
        stack.method_57379(class_9334.field_50075, b.method_19242());
    }

    /** Serializes one effect incl. chance. */
    public static class_2487 createNbt(short id, Pair<class_1293, Float> effect) {
        class_2487 nbtCompound = new class_2487();
        nbtCompound.method_10575("id", id);
        nbtCompound.method_10569("duration", effect.getFirst().method_5584());
        nbtCompound.method_10569("amplifier", effect.getFirst().method_5578());
        nbtCompound.method_10548("chance", effect.getSecond());
        return nbtCompound;
    }

    /** Counterpart to {@link #createNbt(short, Pair)}. */
    public static List<Pair<class_1293, Float>> fromNbt(class_2499 list) {
        List<Pair<class_1293, Float>> effects = Lists.newArrayList();
        for (int i = 0; i < list.size(); ++i) {
            class_2487 nbtCompound = list.method_10602(i);
            Optional<class_6880.class_6883<class_1291>> effect = class_7923.field_41174.method_40265(nbtCompound.method_10568("id"));
            effect.ifPresent(mobEffectReference -> effects.add(new Pair<>(new class_1293(mobEffectReference, nbtCompound.method_10550("duration"), nbtCompound.method_10550("amplifier")), nbtCompound.method_10583("chance"))));
        }
        return effects;
    }

    /** Sets the eating stage (stored as custom model data, so models can switch). */
    public static class_1799 setStage(class_1799 stack, int stage) {
        stack.method_57379(class_9334.field_49637, new class_9280(stage));
        return stack;
    }

    public static int getStage(class_1799 stack) {
        return stack.method_57825(class_9334.field_49637, new class_9280(0)).comp_2382();
    }

    /** Appends the potion-style effect tooltip. */
    public static void getTooltip(class_1799 stack, class_1792.class_9635 tooltipContext, List<class_2561> tooltip) {
        List<class_4174.class_9423> effects = stack.method_57826(class_9334.field_50075) ? Objects.requireNonNull(stack.method_57824(class_9334.field_50075)).comp_2495() : Lists.newArrayList();
        List<Pair<class_6880<class_1320>, class_1322>> attrs = Lists.newArrayList();
        if (effects.isEmpty()) {
            tooltip.add(class_2561.method_43471("effect.none").method_27692(class_124.field_1080));
            return;
        }
        for (class_4174.class_9423 pe : effects) {
            class_5250 name = class_2561.method_43471(pe.comp_2496().method_5586());
            class_1291 eff = pe.comp_2496().method_5579().comp_349();
            eff.method_55650(pe.comp_2496().method_5578(), (h, base) -> {
                class_1322 m = new class_1322(base.comp_2447(), base.comp_2449() * (double)(pe.comp_2496().method_5578() + 1), base.comp_2450());
                attrs.add(new Pair<>(h, m));
            });
            if (pe.comp_2496().method_5584() > 20) {
                name = class_2561.method_43469("potion.withDuration", name, class_1292.method_5577(pe.comp_2496(), pe.comp_2497(), tooltipContext.method_59531()));
            }
            tooltip.add(name.method_27692(eff.method_18792().method_18793()));
        }
        if (!attrs.isEmpty()) {
            tooltip.add(class_2561.method_43473());
            tooltip.add(class_2561.method_43471("potion.whenDrank").method_27692(class_124.field_1064));
            for (Pair<class_6880<class_1320>, class_1322> pair : attrs) {
                class_1322 m = pair.getSecond();
                double amt = m.comp_2449();
                double shown = (m.comp_2450() == class_1322.class_1323.field_6330 || m.comp_2450() == class_1322.class_1323.field_6331) ? amt * 100.0 : amt;
                if (amt > 0.0) {
                    tooltip.add(class_2561.method_43469("attribute.modifier.plus." + m.comp_2450().method_56082(), class_9285.field_49329.format(shown), class_2561.method_43471(pair.getFirst().comp_349().method_26830())).method_27692(class_124.field_1078));
                } else if (amt < 0.0) {
                    tooltip.add(class_2561.method_43469("attribute.modifier.take." + m.comp_2450().method_56082(), class_9285.field_49329.format(-shown), class_2561.method_43471(pair.getFirst().comp_349().method_26830())).method_27692(class_124.field_1061));
                }
            }
        }
    }

    /** Keeps only the strongest instance per effect: higher amplifier wins, then longer duration. */
    public static Map<class_6880<class_1291>, class_1293> bestEffects(Iterable<Pair<class_1293, Float>> effects) {
        Map<class_6880<class_1291>, class_1293> best = new HashMap<>();
        for (Pair<class_1293, Float> p : effects) {
            class_1293 cur = p.getFirst();
            class_6880<class_1291> key = cur.method_5579();
            class_1293 prev = best.get(key);
            if (prev == null || cur.method_5578() > prev.method_5578() || (cur.method_5578() == prev.method_5578() && cur.method_5584() > prev.method_5584())) {
                best.put(key, cur);
            }
        }
        return best;
    }

    /** Collects effects of all stacks, merged via {@link #bestEffects(Iterable)} and sorted by registry id. */
    public static List<class_1293> collectMergedSortedEffects(Iterable<class_1799> stacks) {
        List<Pair<class_1293, Float>> collected = new ArrayList<>();
        for (class_1799 in : stacks) if (!in.method_7960()) collected.addAll(getEffects(in));
        Map<class_6880<class_1291>, class_1293> best = bestEffects(collected);
        List<class_1293> sorted = new ArrayList<>(best.values());
        sorted.sort(Comparator.comparingInt(a -> class_7923.field_41174.method_10206(a.method_5579().comp_349())));
        return sorted;
    }

    /** Same, for a slot range of a container. {@code to} is inclusive! */
    public static List<class_1293> collectMergedSortedEffects(class_1263 container, int from, int to) {
        List<class_1799> stacks = new ArrayList<>();
        for (int i = from; i <= to; i++) stacks.add(container.method_5438(i));
        return collectMergedSortedEffects(stacks);
    }
}