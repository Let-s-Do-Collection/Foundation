package net.satisfy.foundation.wood;

import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_2680;

public class WoodSignBlockEntity extends class_2625 {
    public WoodSignBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }
}
