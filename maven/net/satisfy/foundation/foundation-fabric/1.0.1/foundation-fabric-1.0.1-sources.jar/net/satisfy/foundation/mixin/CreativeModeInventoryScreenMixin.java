package net.satisfy.foundation.mixin;

import net.minecraft.class_1661;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.satisfy.foundation.client.creative.CreativeSideTabs;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_481.class)
public abstract class CreativeModeInventoryScreenMixin extends class_465<class_481.class_483> {
    @Unique
    private static final class_2960 foundation$TAB_SPRITE = class_2960.method_60656("advancements/tab_left_middle");
    @Unique
    private static final class_2960 foundation$SELECTED_TAB_SPRITE = class_2960.method_60656("advancements/tab_left_middle_selected");
    @Unique
    private static final int foundation$TAB_WIDTH = 32;
    @Unique
    private static final int foundation$TAB_HEIGHT = 28;

    @Shadow
    private static class_1761 selectedTab;

    @Shadow
    private float scrollOffs;

    private CreativeModeInventoryScreenMixin(class_481.class_483 menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Inject(method = "selectTab", at = @At("TAIL"))
    private void foundation$filterSideTab(class_1761 tab, CallbackInfo ci) {
        foundation$applySideTab();
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void foundation$clickSideTab(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        List<CreativeSideTabs.SideTab> sideTabs = CreativeSideTabs.get(selectedTab);
        for (int i = 0; i < sideTabs.size(); i++) {
            if (foundation$isOverTab(i, mouseX, mouseY)) {
                CreativeSideTabs.select(selectedTab, i);
                foundation$applySideTab();
                cir.setReturnValue(true);
                return;
            }
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void foundation$renderSideTabs(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        List<CreativeSideTabs.SideTab> sideTabs = CreativeSideTabs.get(selectedTab);
        int selected = CreativeSideTabs.getSelected(selectedTab);
        for (int i = 0; i < sideTabs.size(); i++) {
            int x = foundation$tabX();
            int y = foundation$tabY(i);
            graphics.method_52706(i == selected ? foundation$SELECTED_TAB_SPRITE : foundation$TAB_SPRITE, x, y, foundation$TAB_WIDTH, foundation$TAB_HEIGHT);
            graphics.method_51427(sideTabs.get(i).icon(), x + 10, y + 6);
        }
        for (int i = 0; i < sideTabs.size(); i++) {
            if (foundation$isOverTab(i, mouseX, mouseY)) {
                graphics.method_51438(field_22793, sideTabs.get(i).title(), mouseX, mouseY);
            }
        }
    }

    @Unique
    private void foundation$applySideTab() {
        List<CreativeSideTabs.SideTab> sideTabs = CreativeSideTabs.get(selectedTab);
        if (sideTabs.isEmpty()) {
            return;
        }
        int selected = Math.min(CreativeSideTabs.getSelected(selectedTab), sideTabs.size() - 1);
        CreativeSideTabs.SideTab sideTab = sideTabs.get(selected);
        field_2797.field_2897.clear();
        for (class_1799 stack : selectedTab.method_47313()) {
            if (sideTab.contains(stack)) {
                field_2797.field_2897.add(stack);
            }
        }
        scrollOffs = 0.0F;
        field_2797.method_2473(0.0F);
    }

    @Unique
    private int foundation$tabX() {
        return field_2776 - foundation$TAB_WIDTH + 4;
    }

    @Unique
    private int foundation$tabY(int index) {
        return field_2800 + 4 + index * foundation$TAB_HEIGHT;
    }

    @Unique
    private boolean foundation$isOverTab(int index, double mouseX, double mouseY) {
        int x = foundation$tabX();
        int y = foundation$tabY(index);
        return mouseX >= x && mouseX < x + foundation$TAB_WIDTH - 4 && mouseY >= y && mouseY < y + foundation$TAB_HEIGHT;
    }
}
