package net.satisfy.foundation.storage;

import net.satisfy.foundation.util.ShapeUtil;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5712;
import net.minecraft.class_9062;
import net.satisfy.foundation.block.FacingBlock;
import net.satisfy.foundation.storage.StorageBlockEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

/**
 * Block with a small display inventory (shelves, racks...). Where you click
 * on the front face decides the slot, see {@link #getSection(Float, Float)}.
 * Rendering goes through {@link StorageTypeRenderer}s registered under {@link #type()}.
 */
public abstract class StorageBlock extends FacingBlock implements class_2343 {

    public StorageBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof StorageBlockEntity storageEntity) {
            Optional<class_3545<Float, Float>> hitCoordinates = ShapeUtil.getRelativeHitCoordinatesForBlockFace(hit, state.method_11654(field_11177), this.unAllowedDirections());
            if (hitCoordinates.isEmpty()) {
                return class_9062.field_47731;
            }

            class_3545<Float, Float> coordinates = hitCoordinates.get();
            int section = this.getSection(coordinates.method_15442(), coordinates.method_15441());
            if (section == Integer.MIN_VALUE) {
                return class_9062.field_47731;
            }

            if (!storageEntity.getInventory().get(section).method_7960()) {
                this.remove(world, pos, player, storageEntity, section);
                return class_9062.method_55644(world.field_9236);
            }

            if (!stack.method_7960() && this.canInsertStack(stack)) {
                this.add(world, pos, player, storageEntity, stack, section);
                return class_9062.method_55644(world.field_9236);
            }

            return class_9062.field_47729;
        }

        return class_9062.field_47731;
    }

    public void add(class_1937 level, class_2338 pos, class_1657 player, StorageBlockEntity storageEntity, class_1799 itemStack, int index) {
        if (!level.field_9236) {
            class_3414 sound = this.getAddSound(level, pos, player, index);
            storageEntity.setStack(index, itemStack.method_7971(1));
            level.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
            if (player.method_7337()) {
                itemStack.method_7933(1);
            }

            level.method_33596(player, class_5712.field_28733, pos);
        }
    }

    public void remove(class_1937 level, class_2338 pos, class_1657 player, StorageBlockEntity storageEntity, int index) {
        if (!level.field_9236) {
            class_1799 removedStack = storageEntity.removeStack(index);
            class_3414 sound = this.getRemoveSound(level, pos, player, index);
            level.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
            if (!player.method_31548().method_7394(removedStack)) {
                player.method_7328(removedStack, false);
            }

            level.method_33596(player, class_5712.field_28733, pos);
        }
    }

    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof StorageBlockEntity storageEntity) {
                if (world instanceof class_3218 serverLevel) {
                    class_1264.method_17349(serverLevel, pos, storageEntity.getInventory());
                }

                world.method_8455(pos, this);
            }

            super.method_9536(state, world, pos, newState, moved);
        }
    }

    public @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    public class_3414 getAddSound(class_1937 level, class_2338 pos, class_1657 player, int index) {
        return class_3417.field_14718;
    }

    public class_3414 getRemoveSound(class_1937 level, class_2338 pos, class_1657 player, int index) {
        return class_3417.field_15215;
    }

    public abstract class_2591<?> blockEntityType();

    /** Amount of slots. */
    public abstract int size();

    /** Id of the {@link StorageTypeRenderer} to use. */
    public abstract class_2960 type();

    /** Faces that can not be clicked. */
    public abstract class_2350[] unAllowedDirections();

    public abstract boolean canInsertStack(class_1799 stack);

    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new StorageBlockEntity(this.blockEntityType(), pos, state, this.size());
    }

    /**
     * Maps relative hit coords (0-1) to a slot.
     * @return slot index or {@link Integer#MIN_VALUE} for none
     */
    public abstract int getSection(Float x, Float y);
}