package net.satisfy.foundation.food;

import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_9285;
import net.minecraft.class_9334;

/**
 * Drinkable block item (jugs, kettles...). Sneak to place, gives the
 * crafting remainder back after drinking.
 */
public class TeaJugItem extends class_1747 {
    public TeaJugItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    @Override
    public @NotNull class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        super.method_7851(itemStack, tooltipContext, tooltip, tooltipFlag);

        List<class_4174.class_9423> list2 = itemStack.method_57826(class_9334.field_50075) ? Objects.requireNonNull(itemStack.method_57824(class_9334.field_50075)).comp_2495() : Lists.newArrayList();
        List<Pair<class_6880<class_1320>, class_1322>> list3 = Lists.newArrayList();
        if (list2.isEmpty()) {
            tooltip.add(class_2561.method_43471("effect.none").method_27692(class_124.field_1080));
        } else {
            for (class_4174.class_9423 statusEffectInstance : list2) {
                class_5250 mutableText = class_2561.method_43471(statusEffectInstance.comp_2496().method_5586());
                class_1291 statusEffect = statusEffectInstance.comp_2496().method_5579().comp_349();

                statusEffect.method_55650(statusEffectInstance.comp_2496().method_5578(), (holderx, attributeModifierx) -> {
                    class_1322 entityAttributeModifier = new class_1322(
                            attributeModifierx.comp_2447(),
                            attributeModifierx.comp_2449() * (double) (statusEffectInstance.comp_2496().method_5578() + 1),
                            attributeModifierx.comp_2450()
                    );
                    list3.add(new Pair<>(holderx, entityAttributeModifier));
                });

                if (statusEffectInstance.comp_2496().method_5584() > 20) {
                    mutableText = class_2561.method_43469(
                            "potion.withDuration",
                            mutableText, class_1292.method_5577(statusEffectInstance.comp_2496(), statusEffectInstance.comp_2497(), tooltipContext.method_59531()));
                }

                tooltip.add(mutableText.method_27692(statusEffect.method_18792().method_18793()));
            }
        }

        if (!list3.isEmpty()) {
            tooltip.add(class_2561.method_43473());
            tooltip.add(class_2561.method_43471("potion.whenDrank").method_27692(class_124.field_1064));

            for (Pair<class_6880<class_1320>, class_1322> pair : list3) {
                class_1322 entityAttributeModifier3 = pair.getSecond();
                double d = entityAttributeModifier3.comp_2449();
                double e;
                if (entityAttributeModifier3.comp_2450() != class_1322.class_1323.field_6330 && entityAttributeModifier3.comp_2450() != class_1322.class_1323.field_6331) {
                    e = entityAttributeModifier3.comp_2449();
                } else {
                    e = entityAttributeModifier3.comp_2449() * 100.0;
                }

                if (d > 0.0) {
                    tooltip.add(class_2561.method_43469("attribute.modifier.plus." + entityAttributeModifier3.comp_2450().method_56082(), class_9285.field_49329.format(e), class_2561.method_43471(pair.getFirst().comp_349().method_26830())).method_27692(class_124.field_1078));
                } else if (d < 0.0) {
                    e *= -1.0;
                    tooltip.add(class_2561.method_43469("attribute.modifier.take." + entityAttributeModifier3.comp_2450().method_56082(), class_9285.field_49329.format(e), class_2561.method_43471(pair.getFirst().comp_349().method_26830())).method_27692(class_124.field_1061));
                }
            }
        }
    }

    @Override
    public @NotNull class_1269 method_7712(class_1750 context) {
        class_1657 player = context.method_8036();
        if (player != null && player.method_5715()) {
            return super.method_7712(context);
        }
        return class_1269.field_5811;
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 consumer) {
        class_1799 containerStack = class_1799.field_8037;
        if (stack.method_7909().method_7857()) {
            assert stack.method_7909().method_7858() != null;
            containerStack = new class_1799(stack.method_7909().method_7858());
        }

        super.method_7861(stack, level, consumer);

        if (!containerStack.method_7960()) {
            if (stack.method_7960()) {
                return containerStack;
            }

            if (consumer instanceof class_1657 player && !player.method_31549().field_7477) {
                if (!player.method_31548().method_7394(containerStack)) {
                    player.method_7328(containerStack, false);
                }
            }
        }

        return stack;
    }
}
