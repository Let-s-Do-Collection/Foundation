package net.satisfy.foundation.block;

import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_9323;
import net.minecraft.class_9334;

public class CabinetBlock extends class_2237 implements ContainerSoundBlock {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 OPEN = class_2741.field_12537;
    public static final MapCodec<CabinetBlock> field_46280 = method_54094(properties -> new CabinetBlock(properties, () -> null, null, null));

    private final Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType;
    @Nullable
    private final class_3414 openSound;
    @Nullable
    private final class_3414 closeSound;

    public CabinetBlock(class_2251 properties, Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType) {
        this(properties, blockEntityType, null, null);
    }

    public CabinetBlock(class_2251 properties, Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType, @Nullable class_3414 openSound, @Nullable class_3414 closeSound) {
        super(properties);
        this.blockEntityType = blockEntityType;
        this.openSound = openSound;
        this.closeSound = closeSound;
        method_9590(field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(OPEN, false));
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return blockEntityType.get().method_11032(pos, state);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level.field_9236) {
            return class_1269.field_5812;
        }
        if (level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
            player.method_17355(cabinet);
        }
        return class_1269.field_21466;
    }

    @Override
    public void playSound(class_1937 level, class_2338 pos, boolean open) {
        class_3414 sound = open ? openSound : closeSound;
        if (sound != null) {
            level.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.1F);
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
            cabinet.recheckOpen();
        }
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, OPEN);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    protected @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            if (level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
                class_1264.method_5451(level, pos, cabinet);
                level.method_8455(pos, this);
            }
            super.method_9536(state, level, pos, newState, moved);
        }
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        if (stack.method_57826(class_9334.field_49631) && level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
            cabinet.method_58684(class_9323.method_57827().method_57840(class_9334.field_49631, stack.method_7964()).method_57838());
        }
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        return class_1703.method_7608(level.method_8321(pos));
    }

    @Override
    protected @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }
}
