package net.satisfy.foundation.particle;

import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_9381;
import org.jetbrains.annotations.NotNull;

/** Colored feather that pops up and slowly sways down. */
public class FeatherParticle extends class_4003 {
    private static final double POP = 0.12;
    private static final float FALL_SPEED = 0.025F;
    private static final float SWAY = 0.04F;

    private final float swayPhase;
    private final float spin;

    protected FeatherParticle(class_638 level, double x, double y, double z, double xSpeed, double zSpeed, class_9381 color) {
        super(level, x, y, z);
        this.field_3852 = xSpeed;
        this.field_3869 = POP + this.field_3840.method_43058() * 0.06;
        this.field_3850 = zSpeed;
        this.field_3847 = 40 + this.field_3840.method_43048(25);
        this.field_3844 = 0.0F;
        this.field_28786 = 0.9F;
        this.field_17867 = 0.07F + this.field_3840.method_43057() * 0.03F;
        this.swayPhase = this.field_3840.method_43057() * class_3532.field_29846;
        this.spin = (this.field_3840.method_43057() - 0.5F) * 0.2F;
        this.field_3839 = this.field_3840.method_43057() * class_3532.field_29846;
        this.field_3861 = color.method_58259();
        this.field_3842 = color.method_58263();
        this.field_3859 = color.method_58264();
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        this.field_3857 = this.field_3839;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        this.field_3869 = Math.max(this.field_3869 * 0.8 - 0.01, -FALL_SPEED);
        this.field_3852 = this.field_3852 * this.field_28786 + class_3532.method_15374(this.field_3866 * 0.25F + this.swayPhase) * SWAY * 0.1;
        this.field_3850 = this.field_3850 * this.field_28786 + class_3532.method_15362(this.field_3866 * 0.2F + this.swayPhase) * SWAY * 0.1;
        this.method_3069(this.field_3852, this.field_3869, this.field_3850);
        if (!this.field_3845) {
            this.field_3839 += this.spin;
        }
        if (this.field_3847 - this.field_3866 < 10) {
            this.field_3841 = (this.field_3847 - this.field_3866) / 10.0F;
        }
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17829;
    }

    public static class Provider implements class_707<class_9381> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_9381 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            FeatherParticle particle = new FeatherParticle(level, x, y, z, xSpeed, zSpeed, type);
            particle.method_18140(this.sprites);
            return particle;
        }
    }
}
