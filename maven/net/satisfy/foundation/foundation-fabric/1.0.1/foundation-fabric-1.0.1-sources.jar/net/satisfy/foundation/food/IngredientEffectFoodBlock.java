package net.satisfy.foundation.food;

import net.satisfy.foundation.util.ShapeUtil;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4174;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.world.level.block.*;
import net.satisfy.foundation.food.IngredientEffectFoodBlockEntity;
import net.satisfy.foundation.food.IngredientEffects;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Supplier;

/**
 * Placed version of an ingredient effect food. The effects from the item get
 * stored in the {@link IngredientEffectFoodBlockEntity} and applied on every bite.
 * Subclasses only need to provide the block entity.
 */
public abstract class IngredientEffectFoodBlock extends class_2237 {
    public static final class_2753 FACING;
    public static final class_2758 BITES;
    private static final Supplier<class_265> voxelShapeSupplier = () -> {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1084(shape, class_259.method_1081(0.125, 0, 0.125, 0.875, 0.0625, 0.875));
        shape = class_259.method_1084(shape, class_259.method_1081(0.1875, 0.0625, 0.1875, 0.8125, 0.4375, 0.8125));


        return shape;
    };
    public static final Map<class_2350, class_265> SHAPE = class_156.method_654(new HashMap<>(), map -> {
        for (class_2350 direction : class_2350.class_2353.field_11062.method_29716().toList()) {
            map.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, voxelShapeSupplier.get()));
        }
    });

    static {
        FACING = class_2741.field_12481;
        BITES = class_2758.method_11867("bites", 0, 3);
    }

    private final int maxBites;
    private final class_4174 foodComponent;

    public IngredientEffectFoodBlock(class_2251 properties) {
        super(properties);
        this.maxBites = 3;
        this.foodComponent = new class_4174.class_4175().method_19238(1).method_19242();
    }

    public IngredientEffectFoodBlock(class_2251 settings, int maxBites, class_4174 foodComponent) {
        super(settings);
        this.maxBites = maxBites;
        this.foodComponent = foodComponent;
        method_9590(this.method_9564().method_11657(BITES, 0).method_11657(FACING, class_2350.field_11043));
    }


    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        if (!Objects.requireNonNull(ctx.method_8036()).method_5715()) {
            return null;
        }

        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public boolean method_9558(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return ShapeUtil.isFullAndSolid(levelReader, blockPos);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof IngredientEffectFoodBlockEntity effectFoodBlockEntity) {
            effectFoodBlockEntity.addEffects(IngredientEffects.getEffects(itemStack));
        }
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 blockHitResult) {
        class_1268 hand = player.method_6058();
        class_1799 itemStack = player.method_5998(hand);
        if (world.field_9236) {
            if (tryEat(world, pos, state, player).method_23665()) {
                return class_1269.field_5812;
            }

            if (itemStack.method_7960()) {
                return class_1269.field_21466;
            }
        }
        return tryEat(world, pos, state, player);
    }

    private class_1269 tryEat(class_1936 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!player.method_7332(false)) {
            return class_1269.field_5811;
        }

        class_2586 blockEntity = world.method_8321(pos);
        List<Pair<class_1293, Float>> storedEffects = Collections.emptyList();
        if (blockEntity instanceof IngredientEffectFoodBlockEntity effectFoodBlockEntity) {
            storedEffects = effectFoodBlockEntity.getEffects();
        }

        player.method_7344().method_7585(foodComponent.comp_2491(), foodComponent.comp_2492());
        world.method_8396(null, pos, class_3417.field_18060, class_3419.field_15248, 0.5f, world.method_8409().method_43057() * 0.1f + 0.9f);
        world.method_33596(player, class_5712.field_28735, pos);

        int bites = state.method_11654(BITES);
        if (bites < maxBites) {
            world.method_8652(pos, state.method_11657(BITES, bites + 1), 3);
        } else {
            world.method_22352(pos, false);
            world.method_33596(player, class_5712.field_28165, pos);
        }

        for (Pair<class_1293, Float> effect : storedEffects) {
            player.method_6092(effect.getFirst());
        }

        return class_1269.field_5812;
    }

    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, BITES);
    }

    @Override
    public @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE.get(state.method_11654(FACING));
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        super.method_9536(state, world, pos, newState, moved);
    }

    @Nullable
    @Override
    public abstract class_2586 method_10123(class_2338 pos, class_2680 state);
}
