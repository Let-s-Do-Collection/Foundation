package net.satisfy.foundation.block;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3726;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;

public class CabinetWallBlock extends CabinetBlock {
    private static final Map<class_2350, class_265> SHAPES = new EnumMap<>(class_2350.class);

    static {
        class_265 north = class_259.method_1081(0, 0, 0.25, 1, 1, 1);
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            SHAPES.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, north));
        }
    }

    public CabinetWallBlock(class_2251 properties, Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType) {
        super(properties, blockEntityType);
    }

    public CabinetWallBlock(class_2251 properties, Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType, @Nullable class_3414 openSound, @Nullable class_3414 closeSound) {
        super(properties, blockEntityType, openSound, closeSound);
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPES.get(state.method_11654(FACING));
    }
}
