package net.satisfy.foundation.entity.ai;

import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1352;
import net.minecraft.class_5134;
import net.minecraft.class_5819;
import net.satisfy.foundation.Foundation;

import java.util.EnumSet;

public class RandomActionGoal extends class_1352 {
    private static final class_1322 FREEZE = new class_1322(Foundation.identifier("random_action_freeze"), -1000, class_1322.class_1323.field_6328);
    private final class_1309 mob;
    private final RandomAction action;
    private final class_5819 random = class_5819.method_43047();
    private int counter;

    public <T extends class_1309 & RandomAction> RandomActionGoal(T mob) {
        this.mob = mob;
        this.action = mob;
        method_6265(EnumSet.of(class_4134.field_18406, class_4134.field_18405, class_4134.field_18407));
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6267() {
        return action.isInterruptable();
    }

    @Override
    public boolean method_6264() {
        return random.method_43057() < action.chance() && action.isPossible();
    }

    @Override
    public boolean method_6266() {
        return counter > 0 && counter < action.duration() && action.isPossible();
    }

    @Override
    public void method_6269() {
        counter = 0;
        action.onStart();
        class_1324 speed = mob.method_5996(class_5134.field_23719);
        if (!action.canMove() && speed != null && !speed.method_6196(FREEZE.comp_2447())) {
            speed.method_26835(FREEZE);
        }
    }

    @Override
    public void method_6268() {
        counter++;
        action.onTick(counter);
    }

    @Override
    public void method_6270() {
        action.onStop();
        class_1324 speed = mob.method_5996(class_5134.field_23719);
        if (speed != null) {
            speed.method_6200(FREEZE.comp_2447());
        }
    }
}
