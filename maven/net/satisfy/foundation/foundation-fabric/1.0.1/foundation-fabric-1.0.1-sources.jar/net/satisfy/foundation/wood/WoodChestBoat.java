package net.satisfy.foundation.wood;

import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1690;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_4838;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5630;
import net.minecraft.class_5712;
import net.minecraft.class_7248;
import net.minecraft.class_7265;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class WoodChestBoat extends WoodBoat implements class_7248, class_7265 {
    private static final int CONTAINER_SIZE = 27;
    private class_2371<class_1799> itemStacks = class_2371.method_10213(CONTAINER_SIZE, class_1799.field_8037);
    @Nullable
    private class_5321<class_52> lootTable;
    private long lootTableSeed;

    public WoodChestBoat(class_1299<? extends class_1690> type, class_1937 level) {
        super(type, level);
    }

    @Override
    protected float method_42280() {
        return 0.15F;
    }

    @Override
    protected int method_42281() {
        return 1;
    }

    @Override
    protected void method_5652(class_2487 tag) {
        super.method_5652(tag);
        method_42288(tag, method_37908().method_30349());
    }

    @Override
    protected void method_5749(class_2487 tag) {
        super.method_5749(tag);
        method_42285(tag, method_37908().method_30349());
    }

    @Override
    public void method_7516(class_1282 source) {
        super.method_7516(source);
        method_42283(source, method_37908(), this);
    }

    @Override
    public void method_5650(class_5529 reason) {
        if (!method_37908().method_8608() && reason.method_31486()) {
            class_1264.method_5452(method_37908(), this, this);
        }
        super.method_5650(reason);
    }

    @Override
    public @NotNull class_1269 method_5688(class_1657 player, class_1268 hand) {
        return method_5818(player) && !player.method_21823() ? super.method_5688(player, hand) : method_42284(player);
    }

    @Override
    public void method_6722(class_1657 player) {
        player.method_17355(this);
        if (!player.method_37908().method_8608()) {
            method_32875(class_5712.field_28176, player);
            class_4838.method_24733(player, true);
        }
    }

    @Override
    public @NotNull class_1792 method_7557() {
        return getWood().item(true);
    }

    @Override
    public void method_5448() {
        method_42293();
    }

    @Override
    public int method_5439() {
        return CONTAINER_SIZE;
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        return method_42290(slot);
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        return method_42286(slot, amount);
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        return method_42289(slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        method_42287(slot, stack);
    }

    @Override
    public @NotNull class_5630 method_32318(int slot) {
        return method_42292(slot);
    }

    @Override
    public void method_5431() {
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return method_42294(player);
    }

    @Override
    public @Nullable class_1703 createMenu(int containerId, class_1661 inventory, class_1657 player) {
        if (lootTable != null && player.method_7325()) {
            return null;
        }
        method_42291(inventory.field_7546);
        return class_1707.method_19245(containerId, inventory, this);
    }

    @Override
    public @Nullable class_5321<class_52> method_42276() {
        return lootTable;
    }

    @Override
    public void method_42275(@Nullable class_5321<class_52> lootTable) {
        this.lootTable = lootTable;
    }

    @Override
    public long method_42277() {
        return lootTableSeed;
    }

    @Override
    public void method_42274(long seed) {
        this.lootTableSeed = seed;
    }

    @Override
    public @NotNull class_2371<class_1799> method_42278() {
        return itemStacks;
    }

    @Override
    public void method_42273() {
        itemStacks = class_2371.method_10213(method_5439(), class_1799.field_8037);
    }
}
