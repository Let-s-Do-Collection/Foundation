package net.satisfy.foundation.client.wood;

import net.minecraft.class_1690;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4595;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_554;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_7752;
import net.minecraft.class_7755;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.satisfy.foundation.wood.BoatWood;
import net.satisfy.foundation.wood.WoodBoat;
import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionf;

import java.util.HashMap;
import java.util.Map;

public class WoodBoatRenderer extends class_897<WoodBoat> {
    private final class_5617.class_5618 context;
    private final boolean chest;
    private final Map<BoatWood, class_4595<class_1690>> models = new HashMap<>();

    public WoodBoatRenderer(class_5617.class_5618 context, boolean chest) {
        super(context);
        this.context = context;
        this.chest = chest;
        this.field_4673 = 0.8F;
    }

    public static class_5601 layer(BoatWood wood, boolean chest) {
        return new class_5601(wood.modelName(chest), "main");
    }

    private class_4595<class_1690> model(BoatWood wood) {
        return models.computeIfAbsent(wood, key -> {
            class_630 part = context.method_32167(layer(key, chest));
            return chest ? new class_7752(part) : new class_554(part);
        });
    }

    @Override
    public void render(WoodBoat boat, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight) {
        poseStack.method_22903();
        poseStack.method_46416(0.0F, 0.375F, 0.0F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - entityYaw));
        float hurtTime = boat.method_54295() - partialTicks;
        float damage = Math.max(boat.method_54294() - partialTicks, 0.0F);
        if (hurtTime > 0.0F) {
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(class_3532.method_15374(hurtTime) * hurtTime * damage / 10.0F * boat.method_54296()));
        }
        float bubbleAngle = boat.method_7547(partialTicks);
        if (!class_3532.method_15347(bubbleAngle, 0.0F)) {
            poseStack.method_22907(new Quaternionf().setAngleAxis(bubbleAngle * class_3532.field_29847, 1.0F, 0.0F, 1.0F));
        }

        BoatWood wood = boat.getWood();
        class_4595<class_1690> model = model(wood);
        poseStack.method_22905(-1.0F, -1.0F, 1.0F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
        model.method_2819(boat, partialTicks, 0.0F, -0.1F, 0.0F, 0.0F);
        class_4588 consumer = buffer.getBuffer(model.method_23500(wood.texture(chest)));
        model.method_60879(poseStack, consumer, packedLight, class_4608.field_21444);
        if (!boat.method_5869() && model instanceof class_7755 waterPatch) {
            waterPatch.method_22954().method_22698(poseStack, buffer.getBuffer(class_1921.method_23589()), packedLight, class_4608.field_21444);
        }
        poseStack.method_22909();
        super.method_3936(boat, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public @NotNull class_2960 getTextureLocation(WoodBoat boat) {
        return boat.getWood().texture(chest);
    }
}
