package net.satisfy.foundation.armor;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1792;

public final class ArmorSets {
    private static final List<ArmorSet> SETS = new CopyOnWriteArrayList<>();

    private ArmorSets() {
    }

    static void register(ArmorSet set) {
        SETS.add(set);
    }

    public static List<ArmorSet> all() {
        return List.copyOf(SETS);
    }

    public static Optional<ArmorSet> find(class_1792 item) {
        return SETS.stream().filter(set -> set.contains(item)).findFirst();
    }
}
