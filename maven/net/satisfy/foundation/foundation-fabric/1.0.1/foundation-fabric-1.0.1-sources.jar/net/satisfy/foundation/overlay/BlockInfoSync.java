package net.satisfy.foundation.overlay;

import dev.architectury.networking.NetworkManager;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.satisfy.foundation.Foundation;

import java.util.ArrayList;
import java.util.List;

/**
 * Pulls server side data for the overlay. Client asks for a pos,
 * all registered {@link Handler}s write into one tag and it gets sent back.
 * Only one pos is cached on the client, which is enough for the overlay.
 */
public final class BlockInfoSync {
    private static final double MAX_DISTANCE_SQR = 64.0;
    private static final int REQUEST_INTERVAL = 10;
    private static final class_2487 EMPTY = new class_2487();
    private static final List<Handler> HANDLERS = new ArrayList<>();

    private static class_2487 clientData = EMPTY;
    private static class_2338 clientPos = class_2338.field_10980;
    private static class_2338 lastRequest;

    private BlockInfoSync() {
    }

    /** Writes server data for a pos into the tag. Keep keys unique per mod. */
    @FunctionalInterface
    public interface Handler {
        void write(class_3218 level, class_2338 pos, class_3222 player, class_2487 tag);
    }

    public record Request(class_2338 pos) implements class_8710 {
        public static final class_9154<Request> TYPE = new class_9154<>(Foundation.identifier("block_info_request"));
        public static final class_9139<class_9129, Request> CODEC = class_9139.method_56434(class_2338.field_48404, Request::pos, Request::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public record Response(class_2338 pos, class_2487 data) implements class_8710 {
        public static final class_9154<Response> TYPE = new class_9154<>(Foundation.identifier("block_info"));
        public static final class_9139<class_9129, Response> CODEC = class_9139.method_56435(class_2338.field_48404, Response::pos, class_9135.field_48556, Response::data, Response::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    /** Register on both sides (common init), handlers only run on the server. */
    public static void registerHandler(Handler handler) {
        HANDLERS.add(handler);
    }

    public static void init() {
        NetworkManager.registerReceiver(NetworkManager.c2s(), Request.TYPE, Request.CODEC, (payload, context) -> context.queue(() -> {
            if (context.getPlayer() instanceof class_3222 player && player.method_24515().method_10262(payload.pos()) <= MAX_DISTANCE_SQR) {
                class_2487 tag = new class_2487();
                for (Handler handler : HANDLERS) {
                    handler.write(player.method_51469(), payload.pos(), player, tag);
                }
                NetworkManager.sendToPlayer(player, new Response(payload.pos(), tag));
            }
        }));
        if (Platform.getEnvironment() == Env.CLIENT) {
            NetworkManager.registerReceiver(NetworkManager.s2c(), Response.TYPE, Response.CODEC, (payload, context) -> context.queue(() -> {
                clientPos = payload.pos();
                clientData = payload.data();
            }));
        } else {
            NetworkManager.registerS2CPayloadType(Response.TYPE, Response.CODEC);
        }
    }

    /**
     * Client side: returns the last data for this pos and re-requests every 10 ticks.
     * Returns an empty tag until the first answer arrived.
     */
    public static class_2487 poll(class_1937 level, class_2338 pos) {
        if (level.method_8510() % REQUEST_INTERVAL == 0 || !pos.equals(lastRequest)) {
            lastRequest = pos.method_10062();
            NetworkManager.sendToServer(new Request(pos));
        }
        return pos.equals(clientPos) ? clientData : EMPTY;
    }
}
