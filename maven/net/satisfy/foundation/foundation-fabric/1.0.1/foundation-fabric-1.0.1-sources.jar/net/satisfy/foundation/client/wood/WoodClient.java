package net.satisfy.foundation.client.wood;

import dev.architectury.registry.client.level.entity.EntityModelLayerRegistry;
import dev.architectury.registry.client.rendering.BlockEntityRendererRegistry;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import net.minecraft.class_554;
import net.minecraft.class_7752;
import net.minecraft.class_7761;
import net.minecraft.class_837;
import net.satisfy.foundation.wood.BoatWood;

public final class WoodClient {
    private WoodClient() {
    }

    public static void registerBoatLayers(BoatWood... woods) {
        for (BoatWood wood : woods) {
            EntityModelLayerRegistry.register(WoodBoatRenderer.layer(wood, false), class_554::method_31985);
            EntityModelLayerRegistry.register(WoodBoatRenderer.layer(wood, true), class_7752::method_45708);
        }
    }

    public static void registerSignMaterials(class_4719... woodTypes) {
        for (class_4719 woodType : woodTypes) {
            class_2960 id = class_2960.method_60654(woodType.comp_1299());
            class_4722.field_21712.putIfAbsent(woodType, new class_4730(class_4722.field_21708, id.method_45138("entity/signs/")));
            class_4722.field_40515.putIfAbsent(woodType, new class_4730(class_4722.field_21708, id.method_45138("entity/signs/hanging/")));
        }
    }

    @SuppressWarnings("unchecked")
    public static void registerSignRenderers(class_2591<?> sign, class_2591<?> hangingSign) {
        BlockEntityRendererRegistry.register((class_2591<class_2625>) sign, class_837::new);
        BlockEntityRendererRegistry.register((class_2591<class_2625>) hangingSign, class_7761::new);
    }
}
