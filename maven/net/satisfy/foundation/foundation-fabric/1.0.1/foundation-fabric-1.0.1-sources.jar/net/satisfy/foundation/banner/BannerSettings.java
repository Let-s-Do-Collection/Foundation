package net.satisfy.foundation.banner;

import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.class_1291;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_6880;

/**
 * Everything that makes a mod's banner its own.
 *
 * @param effect effect given to every player within {@code radius} blocks while the banner stands
 */
public record BannerSettings(Supplier<class_2591<CompletionistBannerEntity>> type, Supplier<class_2248> wallBanner, class_2960 texture, String tooltipPrefix, class_6880<class_1291> effect, IntSupplier radius, IntSupplier amplifier) {
    public static final int DEFAULT_RADIUS = 8;

    public BannerSettings(Supplier<class_2591<CompletionistBannerEntity>> type, Supplier<class_2248> wallBanner, class_2960 texture, String tooltipPrefix, class_6880<class_1291> effect) {
        this(type, wallBanner, texture, tooltipPrefix, effect, DEFAULT_RADIUS);
    }

    public BannerSettings(Supplier<class_2591<CompletionistBannerEntity>> type, Supplier<class_2248> wallBanner, class_2960 texture, String tooltipPrefix, class_6880<class_1291> effect, int radius) {
        this(type, wallBanner, texture, tooltipPrefix, effect, () -> radius, () -> 0);
    }
}
