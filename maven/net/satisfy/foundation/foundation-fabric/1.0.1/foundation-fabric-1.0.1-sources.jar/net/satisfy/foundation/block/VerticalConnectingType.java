package net.satisfy.foundation.block;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum VerticalConnectingType implements class_3542 {
    TOP("top"),
    MIDDLE("middle"),
    BOTTOM("bottom"),
    NONE("none");

    private final String name;

    VerticalConnectingType(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }
}
