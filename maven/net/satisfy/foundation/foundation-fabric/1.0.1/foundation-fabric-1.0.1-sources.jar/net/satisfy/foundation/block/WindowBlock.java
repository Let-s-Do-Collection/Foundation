package net.satisfy.foundation.block;

import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2389;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import org.jetbrains.annotations.NotNull;

public class WindowBlock extends class_2389 {
    public static final class_2758 PART = class_2758.method_11867("part", 0, 3);

    public WindowBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664().method_11657(field_10905, false).method_11657(field_10907, false).method_11657(field_10904, false).method_11657(field_10903, false).method_11657(field_10900, false).method_11657(PART, 0));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(PART, field_10905, field_10907, field_10903, field_10904, field_10900);
    }

    @Override
    public @NotNull class_2680 method_9605(class_1750 context) {
        class_2680 state = super.method_9605(context);
        return state.method_11657(PART, part(state, context.method_8045(), context.method_8037()));
    }

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        class_2680 updated = super.method_9559(state, direction, neighborState, level, pos, neighborPos);
        return direction.method_10166().method_10178() ? updated.method_11657(PART, part(updated, level, pos)) : updated;
    }

    private int part(class_2680 state, class_1922 level, class_2338 pos) {
        boolean below = level.method_8320(pos.method_10074()).method_27852(state.method_26204());
        boolean above = level.method_8320(pos.method_10084()).method_27852(state.method_26204());
        if (below && above) {
            return 2;
        }
        if (above) {
            return 1;
        }
        return below ? 3 : 0;
    }
}
