package net.satisfy.foundation.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.NotNull;

/** Biome tinted water splash. */
public class WaterSplashParticle extends class_4003 {
    protected WaterSplashParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        super(level, x, y, z, 0.0, 0.0, 0.0);
        this.field_3852 *= 0.3F;
        this.field_3869 = this.field_3840.method_43057() * 0.2F + 0.1F;
        this.field_3850 *= 0.3F;
        if (ySpeed == 0.0 && (xSpeed != 0.0 || zSpeed != 0.0)) {
            this.field_3852 = xSpeed;
            this.field_3869 = 0.1;
            this.field_3850 = zSpeed;
        }
        this.method_3080(0.01F, 0.01F);
        this.field_3844 = 0.06F;
        this.field_3847 = (int) (8.0 / (this.field_3840.method_43057() * 0.8 + 0.2));
        WaterTint.apply(this, level, x, y, z);
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3847-- <= 0) {
            this.method_3085();
            return;
        }
        this.field_3869 -= this.field_3844;
        this.method_3069(this.field_3852, this.field_3869, this.field_3850);
        this.field_3852 *= 0.98F;
        this.field_3869 *= 0.98F;
        this.field_3850 *= 0.98F;
        if (this.field_3845) {
            if (this.field_3840.method_43057() < 0.5F) {
                this.method_3085();
            }
            this.field_3852 *= 0.7F;
            this.field_3850 *= 0.7F;
        }
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17828;
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            WaterSplashParticle particle = new WaterSplashParticle(level, x, y, z, xSpeed, ySpeed, zSpeed);
            particle.method_18140(this.sprites);
            return particle;
        }
    }
}
