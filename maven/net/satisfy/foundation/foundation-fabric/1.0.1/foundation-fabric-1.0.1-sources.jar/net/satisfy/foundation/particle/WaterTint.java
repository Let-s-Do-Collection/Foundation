package net.satisfy.foundation.particle;

import net.minecraft.class_1163;
import net.minecraft.class_2338;
import net.minecraft.class_638;
import net.minecraft.class_703;

/** Tints particles with the biome water color. */
final class WaterTint {
    private WaterTint() {
    }

    static void apply(class_703 particle, class_638 level, double x, double y, double z) {
        int color = class_1163.method_4961(level, class_2338.method_49637(x, y, z));
        particle.method_3084((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F);
    }
}
