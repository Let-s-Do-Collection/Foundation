package net.satisfy.foundation.util;

import dev.architectury.platform.Platform;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.Registrar;
import dev.architectury.registry.registries.RegistrySupplier;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.world.level.*;
import java.util.*;

/**
 * Registry helpers that pick the right way per loader
 * (DeferredRegister on NeoForge, Registrar on Fabric).
 */
public final class RegistryUtil {
    private RegistryUtil() {
    }

    /** Registers the block plus a plain BlockItem. */
    public static <T extends class_2248> RegistrySupplier<T> registerWithItem(DeferredRegister<class_2248> registerB, Registrar<class_2248> registrarB, DeferredRegister<class_1792> registerI, Registrar<class_1792> registrarI, class_2960 name, Supplier<T> block) {
        RegistrySupplier<T> toReturn = registerWithoutItem(registerB, registrarB, name, block);
        registerItem(registerI, registrarI, name, () -> new class_1747(toReturn.get(), new class_1792.class_1793()));
        return toReturn;
    }

    public static <T extends class_2248> RegistrySupplier<T> registerWithoutItem(DeferredRegister<class_2248> register, Registrar<class_2248> registrar, class_2960 path, Supplier<T> block) {
        return Platform.isNeoForge() ? register.register(path.method_12832(), block) : registrar.register(path, block);
    }

    public static <T extends class_1792> RegistrySupplier<T> registerItem(DeferredRegister<class_1792> register, Registrar<class_1792> registrar, class_2960 path, Supplier<T> itemSupplier) {
        return Platform.isNeoForge() ? register.register(path.method_12832(), itemSupplier) : registrar.register(path, itemSupplier);
    }
}
