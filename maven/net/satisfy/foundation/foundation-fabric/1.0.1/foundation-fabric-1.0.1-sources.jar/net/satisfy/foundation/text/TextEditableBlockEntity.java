package net.satisfy.foundation.text;

import net.minecraft.class_2561;

/** Implement on block entities that accept a {@link SetTextPacket}. */
public interface TextEditableBlockEntity {
    void setText(int line, class_2561 text);
    int getTextLineCount();
}