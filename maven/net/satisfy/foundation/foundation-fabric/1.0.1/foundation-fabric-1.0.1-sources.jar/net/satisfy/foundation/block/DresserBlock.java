package net.satisfy.foundation.block;

import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;

public class DresserBlock extends LineConnectingBlock implements class_2343, class_3737, ContainerSoundBlock {
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    private static final Map<LineConnectingType, class_265> NORTH_SHAPES = Map.of(
            LineConnectingType.NONE, class_259.method_17786(
                    class_259.method_1081(0.0625, 0, 0.0625, 0.25, 0.1875, 0.25), class_259.method_1081(0.75, 0, 0.0625, 0.9375, 0.1875, 0.25),
                    class_259.method_1081(0.0625, 0, 0.75, 0.25, 0.1875, 0.9375), class_259.method_1081(0.75, 0, 0.75, 0.9375, 0.1875, 0.9375),
                    class_259.method_1081(0, 0.8125, 0, 1, 1, 1), class_259.method_1081(0.0625, 0.1875, 0.0625, 0.9375, 0.8125, 0.9375)),
            LineConnectingType.RIGHT, class_259.method_17786(
                    class_259.method_1081(0, 0.8125, 0, 1, 1, 1), class_259.method_1081(0, 0.1875, 0.0625, 0.9375, 0.8125, 0.9375),
                    class_259.method_1081(0.75, 0, 0.0625, 0.9375, 0.1875, 0.25), class_259.method_1081(0.75, 0, 0.75, 0.9375, 0.1875, 0.9375)),
            LineConnectingType.LEFT, class_259.method_17786(
                    class_259.method_1081(0, 0.8125, 0, 1, 1, 1), class_259.method_1081(0.0625, 0.1875, 0.0625, 1, 0.8125, 0.9375),
                    class_259.method_1081(0.0625, 0, 0.75, 0.25, 0.1875, 0.9375), class_259.method_1081(0.0625, 0, 0.0625, 0.25, 0.1875, 0.25)),
            LineConnectingType.MIDDLE, class_259.method_1084(
                    class_259.method_1081(0, 0.1875, 0.0625, 1, 0.8125, 0.9375), class_259.method_1081(0, 0.8125, 0, 1, 1, 1)));
    private static final Map<class_2350, Map<LineConnectingType, class_265>> SHAPES = new EnumMap<>(class_2350.class);

    static {
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            Map<LineConnectingType, class_265> rotated = new EnumMap<>(LineConnectingType.class);
            NORTH_SHAPES.forEach((type, shape) -> rotated.put(type, ShapeUtil.rotateShape(class_2350.field_11043, direction, shape)));
            SHAPES.put(direction, rotated);
        }
    }

    private final Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType;
    @Nullable
    private final Supplier<class_3414> openSound;
    @Nullable
    private final Supplier<class_3414> closeSound;

    public DresserBlock(class_2251 properties, Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType) {
        this(properties, blockEntityType, null, null);
    }

    public DresserBlock(class_2251 properties, Supplier<? extends class_2591<? extends CabinetBlockEntity>> blockEntityType, @Nullable Supplier<class_3414> openSound, @Nullable Supplier<class_3414> closeSound) {
        super(properties);
        this.blockEntityType = blockEntityType;
        this.openSound = openSound;
        this.closeSound = closeSound;
        method_9590(method_9564().method_11657(WATERLOGGED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(WATERLOGGED);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2680 state = super.method_9605(context);
        return state == null ? null : state.method_11657(WATERLOGGED, context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910);
    }

    @Override
    public LineConnectingType getType(class_2680 state, class_2680 left, class_2680 right) {
        boolean leftConnects = isConnected(state, left);
        boolean rightConnects = isConnected(state, right);
        if (leftConnects && rightConnects) {
            return LineConnectingType.MIDDLE;
        }
        if (leftConnects) {
            return LineConnectingType.LEFT;
        }
        return rightConnects ? LineConnectingType.RIGHT : LineConnectingType.NONE;
    }

    private boolean isConnected(class_2680 self, class_2680 neighbour) {
        if (!neighbour.method_28498(FACING) || neighbour.method_11654(FACING) != self.method_11654(FACING)) {
            return false;
        }
        return neighbour.method_27852(this) || connectsTo(neighbour);
    }

    protected boolean connectsTo(class_2680 neighbour) {
        return false;
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level.field_9236) {
            return class_1269.field_5812;
        }
        if (level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
            player.method_17355(cabinet);
        }
        return class_1269.field_21466;
    }

    @Override
    public void playSound(class_1937 level, class_2338 pos, boolean open) {
        Supplier<class_3414> sound = open ? openSound : closeSound;
        if (sound != null) {
            level.method_8396(null, pos, sound.get(), class_3419.field_15245, 1.0F, 1.1F);
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
            cabinet.recheckOpen();
        }
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            if (level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
                class_1264.method_5451(level, pos, cabinet);
                level.method_8455(pos, this);
            }
            super.method_9536(state, level, pos, newState, moved);
        }
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        if (stack.method_57826(class_9334.field_49631) && level.method_8321(pos) instanceof CabinetBlockEntity cabinet) {
            cabinet.method_58684(class_9323.method_57827().method_57840(class_9334.field_49631, stack.method_7964()).method_57838());
        }
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        return class_1703.method_7608(level.method_8321(pos));
    }

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    protected @NotNull class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPES.get(state.method_11654(FACING)).get(state.method_11654(TYPE));
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return blockEntityType.get().method_11032(pos, state);
    }
}
