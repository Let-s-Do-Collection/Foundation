package net.satisfy.foundation.block;

import net.satisfy.foundation.util.ShapeUtil;
import net.satisfy.foundation.registry.FoundationParticles;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1746;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2480;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import net.minecraft.class_9307;
import net.minecraft.class_9334;
import net.minecraft.world.level.block.state.properties.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Two block sink with a tap. Fill it with a bucket or bottle (or just click with
 * empty hand), take water back out again. Drips a bit on the client.
 */
@SuppressWarnings({"unused", "deprecation"})
public class SinkBlock extends class_2248 implements class_2343 {
    public static final class_2746 FILLED = class_2746.method_11825("filled");
    public static final class_2754<class_2756> HALF = class_2754.method_11850("half", class_2756.class);
    public static final class_2753 FACING = class_2741.field_12481;
    public static final Map<class_2350, class_265> TOP_SHAPES = new HashMap<>();
    public static final Map<class_2350, class_265> BOTTOM_SHAPES = new HashMap<>();

    static {
        Supplier<class_265> topShapeSupplier = SinkBlock::makeTopShape;
        Supplier<class_265> bottomShapeSupplier = SinkBlock::makeBottomShape;

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            TOP_SHAPES.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, topShapeSupplier.get()));
            BOTTOM_SHAPES.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, bottomShapeSupplier.get()));
        }
    }

    public SinkBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(HALF, class_2756.field_12607).method_11657(FILLED, false).method_11657(FACING, class_2350.field_11043));
    }

    private static class_265 makeTopShape() {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1072(shape, class_259.method_1081(0.375, 0, 0.75, 0.625, 0.0625, 1), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.3125, 0.125, 0.75, 0.375, 0.3125, 0.9375), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.4375, 0.3125, 0.5, 0.5625, 0.5, 0.625), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.375, 0.25, 0.4375, 0.625, 0.3125, 0.6875), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.4375, 0.0625, 0.8125, 0.5625, 0.375, 0.9375), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.4375, 0.375, 0.625, 0.5625, 0.5, 0.9375), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.375, 0.1875, 0.8125, 0.4375, 0.25, 0.875), class_247.field_1366);
        return shape;
    }

    private static class_265 makeBottomShape() {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1072(shape, class_259.method_1081(0, 0, 0.125, 1, 0.75, 1), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0, 0.75, 0.1875, 0.1875, 1, 0.75), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0, 0.75, 0.75, 1, 1, 1), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0, 0.75, 0, 1, 1, 0.1875), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(0.8125, 0.75, 0.1875, 1, 1, 0.75), class_247.field_1366);
        return shape;
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 facing = state.method_11654(FACING);
        if (state.method_11654(HALF) == class_2756.field_12609) {
            return TOP_SHAPES.get(facing);
        } else {
            return BOTTOM_SHAPES.get(facing);
        }
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 itemStack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        if (itemStack.method_7960()) {
            return class_9062.field_47731;
        }
        SinkBlockEntity sink = sinkAt(world, pos, state);
        if (sink == null) {
            return class_9062.field_47731;
        }
        int water = sink.getWaterLevel();
        class_1799 result = class_1799.field_8037;
        int change = 0;
        if (itemStack.method_31574(class_1802.field_8705) && water < SinkBlockEntity.MAX_LEVEL) {
            result = new class_1799(class_1802.field_8550);
            change = SinkBlockEntity.MAX_LEVEL - water;
        } else if (itemStack.method_31574(class_1802.field_8550) && water == SinkBlockEntity.MAX_LEVEL) {
            result = new class_1799(class_1802.field_8705);
            change = -water;
        } else if (itemStack.method_31574(class_1802.field_8469) && water > 0) {
            result = class_1844.method_57400(class_1802.field_8574, class_1847.field_8991);
            change = -1;
        } else if (isWaterBottle(itemStack) && water < SinkBlockEntity.MAX_LEVEL) {
            result = new class_1799(class_1802.field_8469);
            change = 1;
        } else if (water > 0) {
            result = washed(itemStack);
            change = result.method_7960() ? 0 : -1;
        }
        if (change == 0) {
            return class_9062.field_47731;
        }
        if (!world.field_9236) {
            sink.setWaterLevel(water + change);
            world.method_8396(null, pos, change > 0 ? class_3417.field_14834 : class_3417.field_15126, class_3419.field_15245, 0.8F, 1.0F);
            if (!player.method_31549().field_7477) {
                itemStack.method_7934(1);
                if (!player.method_31548().method_7394(result)) {
                    player.method_7328(result, false);
                }
            }
        }
        return class_9062.method_55644(world.field_9236);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        SinkBlockEntity sink = sinkAt(world, pos, state);
        if (sink == null) {
            return class_1269.field_5811;
        }
        if (!world.field_9236) {
            if (player.method_5809() && sink.getWaterLevel() > 0) {
                player.method_5646();
                sink.setWaterLevel(sink.getWaterLevel() - 1);
                world.method_8396(null, pos, class_3417.field_15222, class_3419.field_15245, 0.8F, 1.2F);
            } else {
                sink.toggle();
            }
        }
        return class_1269.method_29236(world.field_9236);
    }

    private static boolean isWaterBottle(class_1799 stack) {
        class_1844 contents = stack.method_57824(class_9334.field_49651);
        return stack.method_31574(class_1802.field_8574) && contents != null && contents.method_57401(class_1847.field_8991);
    }

    private static class_1799 washed(class_1799 stack) {
        if (stack.method_31573(class_3489.field_48803) && stack.method_57826(class_9334.field_49644)) {
            class_1799 clean = stack.method_46651(1);
            clean.method_57381(class_9334.field_49644);
            return clean;
        }
        class_9307 layers = stack.method_57824(class_9334.field_49619);
        if (stack.method_7909() instanceof class_1746 && layers != null && !layers.comp_2428().isEmpty()) {
            class_1799 clean = stack.method_46651(1);
            clean.method_57379(class_9334.field_49619, layers.method_57571());
            return clean;
        }
        if (class_2248.method_9503(stack.method_7909()) instanceof class_2480 box && box.method_10528() != null) {
            return stack.method_56701(class_1802.field_8545, 1);
        }
        return class_1799.field_8037;
    }

    public static @Nullable SinkBlockEntity sinkAt(class_1937 world, class_2338 pos, class_2680 state) {
        class_2338 base = state.method_11654(HALF) == class_2756.field_12609 ? pos.method_10074() : pos;
        return world.method_8321(base) instanceof SinkBlockEntity sink ? sink : null;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return state.method_11654(HALF) == class_2756.field_12607 ? new SinkBlockEntity(pos, state) : null;
    }

    @Override
    public <T extends class_2586> @Nullable class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236 || state.method_11654(HALF) != class_2756.field_12607) {
            return null;
        }
        return (level, pos, blockState, blockEntity) -> {
            if (blockEntity instanceof SinkBlockEntity sink) {
                SinkBlockEntity.serverTick(level, pos, blockState, sink);
            }
        };
    }

    @Override
    protected @NotNull class_2464 method_9604(class_2680 state) {
        return state.method_11654(HALF) == class_2756.field_12609 ? class_2464.field_11455 : class_2464.field_11458;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(HALF, FILLED, FACING);
    }


    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2338 blockPos = context.method_8037();
        return context.method_8045().method_8320(blockPos.method_10084()).method_26166(context) ? this.method_9564().method_11657(HALF, class_2756.field_12607).method_11657(FACING, context.method_8042().method_10153()) : null;
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        world.method_8652(pos.method_10084(), state.method_11657(HALF, class_2756.field_12609), 3);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        if (state.method_11654(HALF) == class_2756.field_12609) {
            class_2338 blockPos = pos.method_10074();
            class_2680 blockState = world.method_8320(blockPos);
            return blockState.method_27852(this) && blockState.method_11654(HALF) == class_2756.field_12607;
        } else {
            return super.method_9558(state, world, pos);
        }
    }

    /** Places both halves at once, handy for worldgen/structures. */
    public static void placeAt(class_1936 levelAccessor, class_2680 blockState, class_2338 blockPos, int i) {
        class_2338 blockPos2 = blockPos.method_10084();
        levelAccessor.method_8652(blockPos, copyWaterloggedFrom(levelAccessor, blockPos, blockState.method_11657(HALF, class_2756.field_12607)), i);
        levelAccessor.method_8652(blockPos2, copyWaterloggedFrom(levelAccessor, blockPos2, blockState.method_11657(HALF, class_2756.field_12609)), i);
    }


    private static class_2680 copyWaterloggedFrom(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return blockState.method_28498(class_2741.field_12508) ? blockState.method_11657(class_2741.field_12508, levelReader.method_22351(blockPos)) : blockState;
    }

    protected static void preventCreativeDropFromBottomPart(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2756 doubleBlockHalf = blockState.method_11654(HALF);
        if (doubleBlockHalf == class_2756.field_12609) {
            class_2338 blockPos2 = blockPos.method_10074();
            class_2680 blockState2 = level.method_8320(blockPos2);
            if (blockState2.method_27852(blockState.method_26204()) && blockState2.method_11654(HALF) == class_2756.field_12607) {
                class_2680 blockState3 = blockState2.method_26227().method_39360(class_3612.field_15910) ? class_2246.field_10382.method_9564() : class_2246.field_10124.method_9564();
                level.method_8652(blockPos2, blockState3, 35);
                level.method_8444(player, 2001, blockPos2, class_2248.method_9507(blockState2));
            }
        }

    }

    @Override
    public @NotNull class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        class_2756 half = state.method_11654(HALF);
        class_2338 blockPos = half == class_2756.field_12607 ? pos.method_10084() : pos.method_10074();
        class_2680 blockState = world.method_8320(blockPos);
        if (blockState.method_26204() == this && blockState.method_11654(HALF) != half) {
            world.method_8652(blockPos, class_2246.field_10124.method_9564(), 35);
            world.method_8444(player, 2001, blockPos, class_2248.method_9507(blockState));
            if (!world.field_9236 && !player.method_7337()) {
                method_9511(state, world, pos, null, player, player.method_6047());
                method_9511(blockState, world, blockPos, null, player, player.method_6047());
            }
        }
        return super.method_9576(world, pos, state, player);
    }

    @Override
    public void method_9556(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState, @Nullable class_2586 blockEntity, class_1799 itemStack) {
        super.method_9556(level, player, blockPos, class_2246.field_10124.method_9564(), blockEntity, itemStack);
        if (blockState.method_11654(HALF) == class_2756.field_12607) {
            class_2338 blockPos2 = blockPos.method_10084();
            class_2680 blockState2 = level.method_8320(blockPos2);

            if (blockState2.method_27852(this) && blockState2.method_11654(HALF) == class_2756.field_12609) {
                level.method_22352(blockPos2, true);
            }
        } else {
            class_2338 blockPos1 = blockPos.method_10074();
            class_2680 blockState1 = level.method_8320(blockPos1);

            if (blockState1.method_27852(this) && blockState1.method_11654(HALF) == class_2756.field_12607) {
                level.method_22352(blockPos1, true);
            }
        }
    }

    @Override
    public long method_9535(class_2680 blockState, class_2338 blockPos) {
        return class_3532.method_15371(blockPos.method_10263(), blockPos.method_10087(blockState.method_11654(HALF) == class_2756.field_12607 ? 0 : 1).method_10264(), blockPos.method_10260());
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 randomSource) {
        if (state.method_11654(HALF) != class_2756.field_12609 || !(world.method_8321(pos.method_10074()) instanceof SinkBlockEntity sink)) {
            return;
        }
        class_243 spout = spout(pos, state.method_11654(FACING));
        if (sink.isOpen()) {
            world.method_8406(class_2398.field_18306, spout.field_1352, spout.field_1351, spout.field_1350, 0.0, 0.0, 0.0);
            world.method_8406(FoundationParticles.WATER_DRIP.get(), spout.field_1352, spout.field_1351, spout.field_1350, 0.0, 0.0, 0.0);
            if (randomSource.method_43048(3) == 0) {
                double surface = pos.method_10264() - 1 + (12.0 + Math.max(1, sink.getWaterLevel())) / 16.0;
                world.method_8406(FoundationParticles.WATER_SPLASH.get(), spout.field_1352, surface, spout.field_1350, 0.0, 0.0, 0.0);
            }
            if (randomSource.method_43048(20) == 0) {
                world.method_8486(spout.field_1352, spout.field_1351, spout.field_1350, class_3417.field_15237, class_3419.field_15245, 0.3F, 1.4F, false);
            }
        } else if (randomSource.method_43057() < 0.05F) {
            world.method_8406(FoundationParticles.WATER_DRIP.get(), spout.field_1352, spout.field_1351, spout.field_1350, 0.0, 0.0, 0.0);
        }
    }

    public static class_243 spout(class_2338 upper, class_2350 facing) {
        double x = 8.0 / 16.0, z = 9.0 / 16.0;
        for (int turn = 0; turn < (int) (facing.method_10144() / 90.0F + 2) % 4; turn++) {
            double rotated = 1.0 - z;
            z = x;
            x = rotated;
        }
        return new class_243(upper.method_10263() + x, upper.method_10264() + 0.22, upper.method_10260() + z);
    }
}