package net.satisfy.foundation.armor;

import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DyeableArmorItem extends class_1738 {
    private final class_2960 texture;
    private final class_2960 overlayTexture;
    private final int defaultColor;
    private final class_2960 normalizedTexture;
    private final class_2960 normalizedOverlayTexture;

    public DyeableArmorItem(class_6880<class_1741> armorMaterial, class_8051 type, int color, class_1793 properties, class_2960 texture) {
        super(armorMaterial, type, properties);
        this.defaultColor = color;
        this.texture = texture;
        this.overlayTexture = null;
        this.normalizedTexture = normalize(texture);
        this.normalizedOverlayTexture = null;
    }

    public DyeableArmorItem(class_6880<class_1741> armorMaterial, class_8051 type, int color, class_1793 properties, class_2960 texture, class_2960 overlayTexture) {
        super(armorMaterial, type, properties);
        this.defaultColor = color;
        this.texture = texture;
        this.overlayTexture = overlayTexture;
        this.normalizedTexture = normalize(texture);
        this.normalizedOverlayTexture = normalize(overlayTexture);
    }

    public DyeableArmorItem(class_1741 armorMaterial, class_8051 type, int color, class_1793 properties, class_2960 texture) {
        this(class_7923.field_48976.method_47983(armorMaterial), type, color, properties, texture);
    }

    public DyeableArmorItem(class_1741 armorMaterial, class_8051 type, int color, class_1793 properties, class_2960 texture, class_2960 overlayTexture) {
        this(class_7923.field_48976.method_47983(armorMaterial), type, color, properties, texture, overlayTexture);
    }

    public int getDefaultColor() {
        return defaultColor;
    }

    public int getColor(class_1799 stack) {
        class_9282 dyed = stack.method_57824(class_9334.field_49644);
        if (dyed != null) return dyed.comp_2384();
        class_2487 tag = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461().method_10562("display");
        if (tag.method_10573("color", 99)) return tag.method_10550("color");
        return defaultColor;
    }

    public class_2960 getTexture() {
        return normalizedTexture;
    }

    @Nullable
    public class_2960 getOverlayTexture() {
        return normalizedOverlayTexture;
    }

    @Override
    public @NotNull class_1304 method_7685() {
        return this.field_41933.method_48399();
    }

    private static class_2960 normalize(class_2960 loc) {
        String path = loc.method_12832();
        if (!path.startsWith("textures/")) path = "textures/" + path;
        if (!path.endsWith(".png")) path = path + ".png";
        return class_2960.method_60655(loc.method_12836(), path);
    }
}
