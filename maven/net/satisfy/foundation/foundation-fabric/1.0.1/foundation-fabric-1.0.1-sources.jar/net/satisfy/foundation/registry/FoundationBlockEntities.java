package net.satisfy.foundation.registry;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7924;
import net.satisfy.foundation.Foundation;
import net.satisfy.foundation.block.SinkBlock;
import net.satisfy.foundation.block.SinkBlockEntity;
import net.satisfy.foundation.block.StackBlockEntity;
import net.satisfy.foundation.block.StackableBlock;
import net.satisfy.foundation.block.StackableEatableBlock;
import net.satisfy.foundation.food.FoodBlock;

import java.util.Set;

public final class FoundationBlockEntities {
    private static final DeferredRegister<class_2591<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(Foundation.MOD_ID, class_7924.field_41255);

    public static final RegistrySupplier<class_2591<SinkBlockEntity>> SINK = BLOCK_ENTITY_TYPES.register("sink", () -> new class_2591<>(SinkBlockEntity::new, Set.of(), null) {
        @Override
        public boolean method_20526(class_2680 state) {
            return state.method_26204() instanceof SinkBlock;
        }
    });

    public static final RegistrySupplier<class_2591<StackBlockEntity>> STACK = BLOCK_ENTITY_TYPES.register("stack", () -> new class_2591<>(StackBlockEntity::new, Set.of(), null) {
        @Override
        public boolean method_20526(class_2680 state) {
            return state.method_26204() instanceof StackableBlock || state.method_26204() instanceof StackableEatableBlock || state.method_26204() instanceof FoodBlock;
        }
    });

    private FoundationBlockEntities() {
    }

    public static void init() {
        BLOCK_ENTITY_TYPES.register();
    }
}
