package net.satisfy.foundation.text;

import dev.architectury.networking.NetworkManager;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.satisfy.foundation.Foundation;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Client -> server packet for editing text on a block entity (signs, boards...).
 * Lines are capped at 50 chars.
 */
public record SetTextPacket(class_2338 pos, List<String> texts) implements class_8710 {

    public static final class_8710.class_9154<SetTextPacket> TYPE =
            new class_9154<>(Foundation.identifier("set_text"));

    private static final double MAX_EDIT_DISTANCE_SQR = 64.0;

    public static final class_9139<class_9129, SetTextPacket> STREAM_CODEC =
            class_9139.method_56437(SetTextPacket::toNetwork, SetTextPacket::fromNetwork);

    public static void init() {
        NetworkManager.registerReceiver(NetworkManager.c2s(), TYPE, STREAM_CODEC, (packet, context) -> context.queue(() -> handle(packet, (class_3222) context.getPlayer())));
    }

    public static void sendToServer(SetTextPacket packet) {
        NetworkManager.sendToServer(packet);
    }

    public static void toNetwork(class_9129 buf, SetTextPacket msg) {
        buf.method_10807(msg.pos);
        buf.method_53002(msg.texts.size());
        for (String text : msg.texts) {
            buf.method_10814(text);
        }
    }

    public static SetTextPacket fromNetwork(class_9129 buf) {
        class_2338 pos = buf.method_10811();
        int size = buf.readInt();
        List<String> texts = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            texts.add(buf.method_10800(50));
        }
        return new SetTextPacket(pos, texts);
    }

    /** Writes the lines, extra lines above {@link TextEditableBlockEntity#getTextLineCount()} get ignored. */
    public static void handle(SetTextPacket msg, class_3222 player) {
        class_1937 level = player.method_37908();
        if (level.method_8477(msg.pos) && player.method_5707(msg.pos.method_46558()) <= MAX_EDIT_DISTANCE_SQR) {
            class_2586 entity = level.method_8321(msg.pos);
            if (entity instanceof TextEditableBlockEntity editable) {
                int maxLines = editable.getTextLineCount();
                for (int i = 0; i < Math.min(msg.texts.size(), maxLines); i++) {
                    editable.setText(i, class_2561.method_43470(msg.texts.get(i)));
                }
            }
        }
    }

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}