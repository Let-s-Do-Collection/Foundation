package net.satisfy.foundation.menu;

import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class ExtendedSlot extends class_1735 {
    private final Predicate<class_1799> filter;

    public ExtendedSlot(class_1263 container, int index, int x, int y) {
        this(container, index, x, y, stack -> true);
    }

    public ExtendedSlot(class_1263 container, int index, int x, int y, Predicate<class_1799> filter) {
        super(container, index, x, y);
        this.filter = filter;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return filter.test(stack);
    }
}
