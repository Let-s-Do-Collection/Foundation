package net.satisfy.foundation.recipe.book;

import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_3956;
import net.minecraft.class_8786;

/**
 * Implement on a station menu to get the recipe book.
 * Ingredient {@code i} of a recipe goes into menu slot {@code recipeBookInputSlots(type)[i]}.
 * <p>
 * One recipe type: override {@link #recipeBookType()} and {@link #recipeBookInputSlots()}.
 * Several types (one tab each): override {@link #recipeBookTypes()} and {@link #recipeBookInputSlots(class_3956)}.
 */
public interface StationRecipeBookMenu {

    /** Recipes of this type are listed in the book. */
    default class_3956<?> recipeBookType() {
        throw new UnsupportedOperationException("Override recipeBookType() or recipeBookTypes()");
    }

    /** Menu slot indices (not container indices) for the ingredients, in ingredient order. */
    default int[] recipeBookInputSlots() {
        throw new UnsupportedOperationException("Override recipeBookInputSlots() or recipeBookInputSlots(RecipeType)");
    }

    /** All listed types, the book shows a tab per type when there is more than one. */
    default List<class_3956<?>> recipeBookTypes() {
        return List.of(recipeBookType());
    }

    default int[] recipeBookInputSlots(class_3956<?> type) {
        return recipeBookInputSlots();
    }

    /** If true, only recipes unlocked through {@link net.satisfy.foundation.recipe.RecipeUnlockManager} show up. */
    default boolean recipeBookRequiresUnlock() {
        return false;
    }

    /** Tooltip of the tab, null for none. */
    default @Nullable class_2561 recipeBookTabName(class_3956<?> type) {
        return null;
    }

    /**
     * Requirements outside the input slots (fluid, fuel...). When false the recipe shows as not craftable,
     * the ingredients can still be placed. Called on the client.
     */
    default boolean recipeBookExtrasMet(class_8786<?> recipe) {
        return true;
    }

    /** Extra tooltip lines below the ingredients, e.g. needed fluid. Called on the client. */
    default void appendRecipeBookTooltip(class_8786<?> recipe, List<class_2561> tooltip) {
    }

    /** Extra ghosts for a clicked recipe, menu slot index -> ingredient (juice, bottle...). Only shown, never placed. */
    default Map<Integer, class_1856> recipeBookExtraGhosts(class_8786<?> recipe) {
        return Map.of();
    }

    /**
     * Items outside the recipe ingredients that the book places too (bottle, bowl...), menu slot index -> ingredient.
     * They count for "craftable" like normal ingredients. Called on both sides.
     */
    default Map<Integer, class_1856> recipeBookExtraInputs(class_8786<?> recipe) {
        return Map.of();
    }

    /** Input slots of the recipe followed by the slots of {@link #recipeBookExtraInputs}. */
    default int[] recipeBookPlacementSlots(class_8786<?> recipe) {
        int[] inputs = recipeBookInputSlots(recipe.comp_1933().method_17716());
        Map<Integer, class_1856> extras = recipeBookExtraInputs(recipe);
        if (extras.isEmpty()) {
            return inputs;
        }
        int[] slots = Arrays.copyOf(inputs, recipe.comp_1933().method_8117().size() + extras.size());
        int i = recipe.comp_1933().method_8117().size();
        for (int slot : extras.keySet()) {
            slots[i++] = slot;
        }
        return slots;
    }

    /** Ingredients of the recipe followed by {@link #recipeBookExtraInputs}, matching {@link #recipeBookPlacementSlots}. */
    default class_2371<class_1856> recipeBookPlacementIngredients(class_8786<?> recipe) {
        Map<Integer, class_1856> extras = recipeBookExtraInputs(recipe);
        if (extras.isEmpty()) {
            return recipe.comp_1933().method_8117();
        }
        class_2371<class_1856> ingredients = class_2371.method_10211();
        ingredients.addAll(recipe.comp_1933().method_8117());
        ingredients.addAll(extras.values());
        return ingredients;
    }

    /** Menu slot index where the result of this type ends up, the ghost shows the result there. -1 for none. */
    default int recipeBookResultSlot(class_3956<?> type) {
        return -1;
    }
}
