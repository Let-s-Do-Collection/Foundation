package net.satisfy.foundation.client.armor;

import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5151;
import net.minecraft.class_5601;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.satisfy.foundation.armor.DyeableArmorItem;
import net.satisfy.foundation.armor.TexturedArmorItem;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public final class ArmorModels {
    private static final Map<class_1792, Entry> ENTRIES = new HashMap<>();
    private static final Map<class_5601, class_572<?>> BAKED = new HashMap<>();

    private ArmorModels() {
    }

    public static void register(class_5601 layer, Function<class_630, ? extends class_572<?>> factory, class_1935... items) {
        Entry entry = new Entry(layer, factory);
        for (class_1935 item : items) {
            ENTRIES.put(item.method_8389(), entry);
        }
    }

    public static boolean has(class_1792 item) {
        return ENTRIES.containsKey(item);
    }

    public static boolean isHidden(class_1799 stack) {
        class_9279 data = stack.method_57824(class_9334.field_49628);
        return data != null && data.method_57450("Visible") && !data.method_57461().method_10577("Visible");
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static @Nullable class_572<?> getModel(class_1799 stack, class_1304 slot, class_572<?> original) {
        Entry entry = ENTRIES.get(stack.method_7909());
        if (entry == null || isHidden(stack) || !(stack.method_7909() instanceof class_5151 equipable) || equipable.method_7685() != slot) {
            return null;
        }
        class_572<?> model = BAKED.computeIfAbsent(entry.layer, layer -> entry.factory.apply(class_310.method_1551().method_31974().method_32072(layer)));
        ((class_572) original).method_2818((class_572) model);
        return model;
    }

    public static @Nullable class_2960 getTexture(class_1792 item) {
        if (item instanceof DyeableArmorItem dyeable) {
            return dyeable.getTexture();
        }
        if (item instanceof TexturedArmorItem textured) {
            class_2960 texture = textured.getTexture();
            String path = texture.method_12832();
            if (!path.startsWith("textures/")) path = "textures/" + path;
            if (!path.endsWith(".png")) path = path + ".png";
            return texture.method_45136(path);
        }
        return null;
    }

    public static int getColor(class_1799 stack) {
        return stack.method_7909() instanceof DyeableArmorItem dyeable ? 0xFF000000 | dyeable.getColor(stack) : 0xFFFFFFFF;
    }

    public static void render(class_4587 poseStack, class_4597 buffers, class_1799 stack, class_1304 slot, int light, class_572<?> original) {
        class_572<?> model = getModel(stack, slot, original);
        class_2960 texture = getTexture(stack.method_7909());
        if (model == null || texture == null) {
            return;
        }
        model.method_2828(poseStack, buffers.getBuffer(model.method_23500(texture)), light, class_4608.field_21444, getColor(stack));
        if (stack.method_7909() instanceof DyeableArmorItem dyeable && dyeable.getOverlayTexture() != null) {
            model.method_2828(poseStack, buffers.getBuffer(model.method_23500(dyeable.getOverlayTexture())), light, class_4608.field_21444, 0xFFFFFFFF);
        }
    }

    private record Entry(class_5601 layer, Function<class_630, ? extends class_572<?>> factory) {
    }
}
