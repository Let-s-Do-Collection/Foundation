package net.satisfy.foundation.block;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

/** Connection state of a {@link LineConnectingBlock}. */
public enum LineConnectingType implements class_3542 {
    NONE("none"),
    MIDDLE("middle"),
    LEFT("left"),
    RIGHT("right");

    private final String name;

    LineConnectingType(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return this.name;
    }
}
