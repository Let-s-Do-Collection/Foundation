package net.satisfy.foundation.client.render;

import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import org.jetbrains.annotations.Nullable;

public final class FluidBoxRenderer {
    private static final class_1921 FLUID = class_1921.method_23580(class_1059.field_5275);
    private static final int DEFAULT_WATER_COLOR = 0x3F76E4;

    private FluidBoxRenderer() {
    }

    public static void renderWaterBox(float xMin, float yMin, float zMin, float xMax, float yMax, float zMax, class_4597 buffer, class_4587 poseStack, int light, boolean renderBottom, @Nullable class_1937 level, class_2338 pos) {
        int waterColor = level != null ? level.method_23753(pos).comp_349().method_8687() : DEFAULT_WATER_COLOR;
        renderBox(xMin, yMin, zMin, xMax, yMax, zMax, buffer, poseStack, light, renderBottom, (224 << 24) | waterColor);
    }

    public static void renderBox(float xMin, float yMin, float zMin, float xMax, float yMax, float zMax, class_4597 buffer, class_4587 poseStack, int light, boolean renderBottom, int color) {
        class_4588 builder = buffer.getBuffer(FLUID);
        class_1058 texture = class_310.method_1551().method_1541().method_3349(class_2246.field_10382.method_9564()).method_4711();
        int blockLight = (light >> 4) & 0xF;
        int fixedLight = (light & 0xF00000) | (blockLight << 4);

        for (class_2350 side : class_2350.values()) {
            if (side == class_2350.field_11033 && !renderBottom) {
                continue;
            }
            boolean positive = side.method_10171() == class_2350.class_2352.field_11056;
            if (side.method_10166() == class_2350.class_2351.field_11048) {
                renderFace(side, zMin, yMin, zMax, yMax, positive ? xMax : xMin, builder, poseStack, fixedLight, color, texture);
            } else if (side.method_10166() == class_2350.class_2351.field_11051) {
                renderFace(side, xMin, yMin, xMax, yMax, positive ? zMax : zMin, builder, poseStack, fixedLight, color, texture);
            } else {
                renderFace(side, xMin, zMin, xMax, zMax, positive ? yMax : yMin, builder, poseStack, fixedLight, color, texture);
            }
        }
    }

    private static void renderFace(class_2350 dir, float left, float down, float right, float up, float depth, class_4588 builder, class_4587 poseStack, int light, int color, class_1058 texture) {
        boolean positive = dir.method_10171() == class_2350.class_2352.field_11056;
        float u1 = texture.method_4594();
        float u2 = texture.method_4577();
        float v1 = texture.method_4593();
        float v2 = texture.method_4575();

        if (dir.method_10166() == class_2350.class_2351.field_11048) {
            putVertex(builder, poseStack, depth, up, positive ? right : left, color, u1, v1, dir, light);
            putVertex(builder, poseStack, depth, down, positive ? right : left, color, u1, v2, dir, light);
            putVertex(builder, poseStack, depth, down, positive ? left : right, color, u2, v2, dir, light);
            putVertex(builder, poseStack, depth, up, positive ? left : right, color, u2, v1, dir, light);
        } else if (dir.method_10166() == class_2350.class_2351.field_11051) {
            putVertex(builder, poseStack, positive ? left : right, up, depth, color, u1, v1, dir, light);
            putVertex(builder, poseStack, positive ? left : right, down, depth, color, u1, v2, dir, light);
            putVertex(builder, poseStack, positive ? right : left, down, depth, color, u2, v2, dir, light);
            putVertex(builder, poseStack, positive ? right : left, up, depth, color, u2, v1, dir, light);
        } else {
            putVertex(builder, poseStack, left, depth, positive ? down : up, color, u1, v1, dir, light);
            putVertex(builder, poseStack, left, depth, positive ? up : down, color, u1, v2, dir, light);
            putVertex(builder, poseStack, right, depth, positive ? up : down, color, u2, v2, dir, light);
            putVertex(builder, poseStack, right, depth, positive ? down : up, color, u2, v1, dir, light);
        }
    }

    private static void putVertex(class_4588 builder, class_4587 poseStack, float x, float y, float z, int color, float u, float v, class_2350 face, int light) {
        class_2382 normal = face.method_10163();
        int a = color >> 24 & 0xFF;

        int r = (int) ((color >> 16 & 0xFF) * 0.7F);
        int g = (int) ((color >> 8 & 0xFF) * 0.7F);
        int b = (int) ((color & 0xFF) * 0.9F);
        builder.method_22918(poseStack.method_23760().method_23761(), x, y, z)
                .method_1336(r, g, b, a)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_22914(normal.method_10263(), normal.method_10264(), normal.method_10260());
    }
}
