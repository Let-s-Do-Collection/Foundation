package net.satisfy.foundation.armor;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiPredicate;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;

public final class Wearing {
    private static final List<BiPredicate<class_1309, class_1792>> SLOT_PROVIDERS = new CopyOnWriteArrayList<>();

    private Wearing() {
    }

    public static void registerSlotProvider(BiPredicate<class_1309, class_1792> provider) {
        SLOT_PROVIDERS.add(provider);
    }

    public static boolean isWearing(class_1309 entity, class_1792 item) {
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_46643() && entity.method_6118(slot).method_31574(item)) return true;
        }
        for (BiPredicate<class_1309, class_1792> provider : SLOT_PROVIDERS) {
            if (provider.test(entity, item)) return true;
        }
        return false;
    }

    public static boolean isWearingAny(class_1309 entity, List<class_1792> items) {
        for (class_1792 item : items) {
            if (isWearing(entity, item)) return true;
        }
        return false;
    }
}
