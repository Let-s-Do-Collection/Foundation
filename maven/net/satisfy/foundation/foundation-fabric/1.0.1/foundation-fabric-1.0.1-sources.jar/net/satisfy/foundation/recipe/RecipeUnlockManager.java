package net.satisfy.foundation.recipe;

import java.util.List;
import java.util.Set;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.class_8786;

/** Persists unlocked recipes per player via {@link RecipeUnlockSavedData}. */
public class RecipeUnlockManager {

    /** Heads up: currently stores the recipe TYPE key, not the recipe id. */
    public static void unlockRecipes(class_3222 player, List<class_1860<?>> recipes) {
        Set<class_2960> unlocked = loadUnlockedRecipes(player);
        for (class_1860<?> recipe : recipes) {
            unlocked.add(class_7923.field_41188.method_10221(recipe.method_17716()));
        }
        saveUnlockedRecipes(player, unlocked);
    }

    /** Unlocks single recipes by id. */
    public static void unlockRecipeIds(class_3222 player, List<class_2960> recipeIds) {
        Set<class_2960> unlocked = loadUnlockedRecipes(player);
        unlocked.addAll(recipeIds);
        saveUnlockedRecipes(player, unlocked);
    }

    /** @return true if the player did not unlock this recipe yet */
    public static boolean isRecipeLocked(class_3222 player, class_2960 recipeId) {
        return !loadUnlockedRecipes(player).contains(recipeId);
    }

    /** Unlocked if either the recipe id or its whole recipe type is in the set. */
    public static boolean isUnlocked(Set<class_2960> unlocked, class_8786<?> recipe) {
        return unlocked.contains(recipe.comp_1932()) || unlocked.contains(class_7923.field_41188.method_10221(recipe.comp_1933().method_17716()));
    }

    public static boolean isUnlocked(class_3222 player, class_8786<?> recipe) {
        return isUnlocked(loadUnlockedRecipes(player), recipe);
    }

    public static void saveUnlockedRecipes(class_3222 player, Set<class_2960> recipes) {
        class_3218 level = (class_3218) player.method_5770();
        RecipeUnlockSavedData data = level.method_17983()
                        .method_17924(RecipeUnlockSavedData.factory(), RecipeUnlockSavedData.DATA_NAME);
        data.setPlayerRecipes(player.method_5667(), recipes);
        RecipeUnlockSync.send(player, recipes);
    }

    public static Set<class_2960> loadUnlockedRecipes(class_3222 player) {
        class_3218 level = (class_3218) player.method_5770();
        RecipeUnlockSavedData data = level.method_17983()
                .method_17924(RecipeUnlockSavedData.factory(), RecipeUnlockSavedData.DATA_NAME);
        return data.getPlayerRecipes(player.method_5667());
    }
}
