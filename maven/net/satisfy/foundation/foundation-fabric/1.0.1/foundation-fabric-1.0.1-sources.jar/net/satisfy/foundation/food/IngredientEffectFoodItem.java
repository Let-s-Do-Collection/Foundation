package net.satisfy.foundation.food;

import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

/**
 * Food that keeps the effects of whatever went into it. Can have multiple stages
 * (think: pie gets smaller each time you eat), the next stage is put back into
 * the inventory. Stage is stored as custom model data.
 */
public class IngredientEffectFoodItem extends class_1792 implements IngredientEffectCarrier {

    private final int foodStages;

    public IngredientEffectFoodItem(class_1793 settings, int foodStages) {
        super(settings);
        this.foodStages = foodStages;
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.field_9236) {
            List<Pair<class_1293, Float>> effects = IngredientEffects.getEffects(stack);
            for (Pair<class_1293, Float> effect : effects) {
                if (effect.getFirst() != null && world.field_9229.method_43057() < effect.getSecond()) {
                    user.method_6092(new class_1293(effect.getFirst()));
                }
            }
        }
        int stage = IngredientEffects.getStage(stack);
        int slot = -1;
        class_1661 inv = null;
        if (user instanceof class_1657 player && !player.method_7337()) {
            inv = player.method_31548();
            slot = inv.method_7371(stack);
        }
        class_1799 eaten = user.method_60492(world, stack);
        if (inv != null && stage < this.foodStages) {
            class_1799 next = IngredientEffects.setStage(new class_1799(this), stage + 1);
            if (slot >= 0 && slot < inv.field_7547.size()) {
                if (inv.method_5438(slot).method_7960()) {
                    inv.method_7367(slot, next);
                    return eaten;
                }
            }
            int space = inv.method_7390(next);
            if (space >= 0 && space < inv.field_7547.size()) {
                inv.method_7367(space, next);
            }
        }
        return eaten;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        IngredientEffects.getTooltip(itemStack, tooltipContext, list);
    }
}
