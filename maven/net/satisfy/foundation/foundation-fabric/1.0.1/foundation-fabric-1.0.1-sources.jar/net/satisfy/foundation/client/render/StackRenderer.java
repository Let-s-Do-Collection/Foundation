package net.satisfy.foundation.client.render;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_776;
import net.minecraft.class_827;
import net.satisfy.foundation.block.StackBlockEntity;
import net.satisfy.foundation.block.StackableBlock;

public class StackRenderer implements class_827<StackBlockEntity> {
    private final class_776 blockRenderer;

    public StackRenderer(class_5614.class_5615 context) {
        this.blockRenderer = context.method_32141();
    }

    @Override
    public void render(StackBlockEntity entity, float partialTick, class_4587 poseStack, class_4597 buffers, int light, int overlay) {
        class_2680 state = entity.method_11010();
        if (!state.method_28498(StackableBlock.ANIMATED)) {
            return;
        }
        poseStack.method_22903();
        WobbleAnimation.apply(poseStack, entity.method_10997(), entity.getWobbleStart(), partialTick, WobbleAnimation.seed(entity.method_11016().method_10063()));
        blockRenderer.method_3353(state.method_11657(StackableBlock.ANIMATED, false), poseStack, buffers, light, overlay);
        poseStack.method_22909();
    }
}
