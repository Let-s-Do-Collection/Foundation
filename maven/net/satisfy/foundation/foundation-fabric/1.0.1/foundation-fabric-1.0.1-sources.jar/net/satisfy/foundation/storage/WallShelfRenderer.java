package net.satisfy.foundation.storage;

import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.satisfy.foundation.render.ClientUtil;

public class WallShelfRenderer implements StorageTypeRenderer {
    @Override
    public void render(StorageBlockEntity entity, class_4587 poseStack, class_4597 buffers, class_2371<class_1799> items) {
        poseStack.method_22904(-0.4, 0.5, 0.25);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(90));
        poseStack.method_22905(0.5F, 0.5F, 0.5F);
        for (int i = 0; i < items.size(); i++) {
            class_1799 stack = items.get(i);
            if (!stack.method_7960()) {
                poseStack.method_22903();
                poseStack.method_46416(0.0F, 0.0F, 0.2F * i);
                poseStack.method_22907(class_7833.field_40715.rotationDegrees(22.5F));
                ClientUtil.renderItem(stack, poseStack, buffers, entity);
                poseStack.method_22909();
            }
        }
    }
}
