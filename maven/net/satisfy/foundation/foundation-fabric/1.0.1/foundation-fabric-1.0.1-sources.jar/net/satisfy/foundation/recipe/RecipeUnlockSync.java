package net.satisfy.foundation.recipe;

import dev.architectury.event.events.common.PlayerEvent;
import dev.architectury.networking.NetworkManager;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.satisfy.foundation.Foundation;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Mirrors the unlocked recipes of a player to the client, so the station recipe book can hide locked ones.
 * Sent on join and every time {@link RecipeUnlockManager} saves.
 */
public final class RecipeUnlockSync {
    private static Set<class_2960> clientUnlocked = Set.of();

    private RecipeUnlockSync() {
    }

    public record Payload(List<class_2960> unlocked) implements class_8710 {
        public static final class_9154<Payload> TYPE = new class_9154<>(Foundation.identifier("recipe_unlocks"));
        public static final class_9139<class_9129, Payload> CODEC = class_9139.method_56434(
                class_2960.field_48267.method_56433(class_9135.method_56363()), Payload::unlocked, Payload::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public static void init() {
        if (Platform.getEnvironment() == Env.CLIENT) {
            NetworkManager.registerReceiver(NetworkManager.s2c(), Payload.TYPE, Payload.CODEC,
                    (payload, context) -> context.queue(() -> clientUnlocked = new HashSet<>(payload.unlocked())));
        } else {
            NetworkManager.registerS2CPayloadType(Payload.TYPE, Payload.CODEC);
        }
        PlayerEvent.PLAYER_JOIN.register(player -> send(player, RecipeUnlockManager.loadUnlockedRecipes(player)));
    }

    public static void send(class_3222 player, Set<class_2960> unlocked) {
        NetworkManager.sendToPlayer(player, new Payload(List.copyOf(unlocked)));
    }

    /** Client side copy, empty until the first sync arrived. */
    public static Set<class_2960> clientUnlocked() {
        return clientUnlocked;
    }
}
