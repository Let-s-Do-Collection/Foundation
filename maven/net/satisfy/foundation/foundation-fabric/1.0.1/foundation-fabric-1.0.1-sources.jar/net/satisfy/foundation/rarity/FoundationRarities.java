package net.satisfy.foundation.rarity;

import dev.architectury.event.events.client.ClientTooltipEvent;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;

/**
 * Item to {@link FoundationRarity} lookup. Any mod using Foundation can register its items here,
 * the tooltip title is then recolored on the client.
 */
public final class FoundationRarities {
    private static final Map<class_1792, FoundationRarity> RARITIES = new HashMap<>();
    private static boolean initialized;

    private FoundationRarities() {
    }

    public static void register(class_1935 item, FoundationRarity rarity) {
        RARITIES.put(item.method_8389(), rarity);
    }

    @Nullable
    public static FoundationRarity get(class_1799 stack) {
        return RARITIES.get(stack.method_7909());
    }

    /** Client tooltip hook, replaces the first line (the item name) with the rarity colored one. */
    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        ClientTooltipEvent.ITEM.register((stack, lines, context, flag) -> {
            FoundationRarity rarity = get(stack);
            if (rarity != null && !lines.isEmpty()) {
                class_2561 name = lines.getFirst();
                lines.set(0, rarity.apply(name));
            }
        });
    }
}
