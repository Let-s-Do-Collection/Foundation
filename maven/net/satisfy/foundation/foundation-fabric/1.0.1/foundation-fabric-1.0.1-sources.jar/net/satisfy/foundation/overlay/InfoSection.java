package net.satisfy.foundation.overlay;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * One block of content in the {@link BlockInfoOverlay}: title plus lines,
 * item rows, an icon grid or an image. Use the static factories, then the
 * {@code with...} methods to add stuff.
 */
public record InfoSection(class_2561 title, List<class_2561> lines, List<class_1799> icons, int columns, List<Row> rows, @Nullable class_2960 image, int imageSize, @Nullable class_2960 placeholder, boolean decorations) {
    public static final int ROW_COLUMNS = 6;
    public static final int GRID_COLUMNS = 3;
    private static final int ICON_SIZE = 16;
    private static final int ICON_STEP = 19;
    private static final int SPRITE_SIZE = 12;
    private static final int TITLE_HEIGHT = 13;
    private static final int TEXT_HEIGHT = 8;
    private static final int LINE_HEIGHT = 10;
    private static final int COLOR_TITLE = 0xFFE8C97A;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_SLOT = 0x28000000;

    /** Icon (item or sprite) with some text next to it. */
    public record Row(class_1799 icon, class_2561 text, @Nullable class_2960 sprite) {
        public static Row item(class_1799 icon, class_2561 text) {
            return new Row(icon, text, null);
        }

        public static Row sprite(class_2960 sprite, class_2561 text) {
            return new Row(class_1799.field_8037, text, sprite);
        }
    }

    /** Just a title, nothing else. */
    public static InfoSection title(class_2561 title) {
        return new InfoSection(title, List.of(), List.of(), ROW_COLUMNS, List.of(), null, 0, null, false);
    }

    /** Grid of item icons, e.g. an inventory. */
    public static InfoSection icons(class_2561 title, List<class_1799> icons, int columns) {
        return new InfoSection(title, List.of(), icons, columns, List.of(), null, 0, null, false);
    }

    /** Title with a square image below. */
    public static InfoSection image(class_2561 title, class_2960 image, int size) {
        return new InfoSection(title, List.of(), List.of(), ROW_COLUMNS, List.of(), image, size, null, false);
    }

    public static InfoSection lines(class_2561 title, List<class_2561> lines) {
        return new InfoSection(title, lines, List.of(), ROW_COLUMNS, List.of(), null, 0, null, false);
    }

    public static InfoSection rows(class_2561 title, List<Row> rows) {
        return new InfoSection(title, List.of(), List.of(), ROW_COLUMNS, rows, null, 0, null, false);
    }

    public InfoSection withLines(List<class_2561> lines) {
        return new InfoSection(this.title, lines, this.icons, this.columns, this.rows, this.image, this.imageSize, this.placeholder, this.decorations);
    }

    public InfoSection withRows(List<Row> rows) {
        return new InfoSection(this.title, this.lines, this.icons, this.columns, rows, this.image, this.imageSize, this.placeholder, this.decorations);
    }

    public InfoSection withPlaceholder(class_2960 placeholder) {
        return new InfoSection(this.title, this.lines, this.icons, this.columns, this.rows, this.image, this.imageSize, placeholder, this.decorations);
    }

    public InfoSection withDecorations() {
        return new InfoSection(this.title, this.lines, this.icons, this.columns, this.rows, this.image, this.imageSize, this.placeholder, true);
    }

    int iconRows() {
        return (this.icons.size() + this.columns - 1) / this.columns;
    }

    private int rowWidth(class_327 font) {
        return this.rows.stream().mapToInt(row -> ICON_STEP + 2 + font.method_27525(row.text())).max().orElse(0);
    }

    int width(class_327 font) {
        int iconWidth = Math.min(this.icons.size(), this.columns) * ICON_STEP - (this.icons.isEmpty() ? 0 : ICON_STEP - ICON_SIZE - 2);
        int lineWidth = this.lines.stream().mapToInt(font::method_27525).max().orElse(0);
        return Math.max(Math.max(font.method_27525(this.title), iconWidth), Math.max(Math.max(lineWidth, this.rowWidth(font)), this.imageSize));
    }

    int height() {
        if (this.icons.isEmpty() && this.image == null && this.lines.isEmpty() && this.rows.isEmpty()) {
            return TEXT_HEIGHT;
        }
        return TITLE_HEIGHT + this.rows.size() * ICON_STEP + this.lines.size() * LINE_HEIGHT + this.iconRows() * ICON_STEP + (this.image != null ? this.imageSize + 2 : 0);
    }

    void draw(class_332 graphics, class_327 font, int y, int width) {
        graphics.method_27535(font, this.title, (width - font.method_27525(this.title)) / 2, y, COLOR_TITLE);
        int cursor = y + TITLE_HEIGHT;
        int entryX = (width - this.rowWidth(font)) / 2;
        for (Row row : this.rows) {
            if (row.sprite() != null) {
                int offset = (ICON_SIZE - SPRITE_SIZE) / 2;
                graphics.method_25290(row.sprite(), entryX + offset, cursor + offset, 0, 0, SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE);
            } else {
                graphics.method_25294(entryX - 1, cursor - 1, entryX + ICON_SIZE + 1, cursor + ICON_SIZE + 1, COLOR_SLOT);
                graphics.method_51427(row.icon(), entryX, cursor);
            }
            graphics.method_27535(font, row.text(), entryX + ICON_STEP + 2, cursor + (ICON_SIZE - font.field_2000) / 2 + 1, COLOR_TEXT);
            cursor += ICON_STEP;
        }
        for (class_2561 line : this.lines) {
            graphics.method_27535(font, line, (width - font.method_27525(line)) / 2, cursor, COLOR_TEXT);
            cursor += LINE_HEIGHT;
        }
        for (int row = 0; row < this.iconRows(); row++) {
            int start = row * this.columns;
            int inRow = Math.min(this.columns, this.icons.size() - start);
            int rowX = (width - (inRow * ICON_STEP - (ICON_STEP - ICON_SIZE))) / 2;
            for (int i = 0; i < inRow; i++) {
                int iconX = rowX + i * ICON_STEP;
                int iconY = cursor + row * ICON_STEP;
                class_1799 stack = this.icons.get(start + i);
                graphics.method_25294(iconX - 1, iconY - 1, iconX + ICON_SIZE + 1, iconY + ICON_SIZE + 1, COLOR_SLOT);
                if (stack.method_7960() && this.placeholder != null) {
                    graphics.method_25290(this.placeholder, iconX, iconY, 0, 0, ICON_SIZE, ICON_SIZE, ICON_SIZE, ICON_SIZE);
                } else {
                    graphics.method_51427(stack, iconX, iconY);
                    if (this.decorations) {
                        graphics.method_51431(font, stack, iconX, iconY);
                    }
                }
            }
        }
        cursor += this.iconRows() * ICON_STEP;
        if (this.image != null) {
            graphics.method_25290(this.image, (width - this.imageSize) / 2, cursor, 0, 0, this.imageSize, this.imageSize, this.imageSize, this.imageSize);
        }
    }
}
