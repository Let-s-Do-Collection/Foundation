package net.satisfy.foundation.wood;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class WoodBoat extends class_1690 {
    private static final class_2940<String> WOOD = class_2945.method_12791(WoodBoat.class, class_2943.field_13326);

    public WoodBoat(class_1299<? extends class_1690> type, class_1937 level) {
        super(type, level);
        this.field_23807 = true;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(WOOD, "");
    }

    public BoatWood getWood() {
        class_2960 id = class_2960.method_12829(field_6011.method_12789(WOOD));
        BoatWood wood = id == null ? null : BoatWood.get(id);
        if (wood != null) {
            return wood;
        }
        List<BoatWood> own = BoatWood.byNamespace(class_7923.field_41177.method_10221(method_5864()).method_12836());
        return own.isEmpty() ? BoatWood.all().getFirst() : own.getFirst();
    }

    public void setWood(BoatWood wood) {
        field_6011.method_12778(WOOD, wood.id().toString());
    }

    @Override
    protected void method_5749(class_2487 tag) {
        super.method_5749(tag);
        if (tag.method_10573("Type", 8)) {
            String name = tag.method_10558("Type");
            String namespace = class_7923.field_41177.method_10221(method_5864()).method_12836();
            class_2960 id = name.contains(":") ? class_2960.method_12829(name) : class_2960.method_43902(namespace, name);
            BoatWood wood = id == null ? null : BoatWood.get(id);
            if (wood != null) {
                setWood(wood);
            }
        }
    }

    @Override
    protected void method_5652(class_2487 tag) {
        super.method_5652(tag);
        tag.method_10582("Type", getWood().id().toString());
    }

    @Override
    public @NotNull class_1792 method_7557() {
        return getWood().item(false);
    }
}
