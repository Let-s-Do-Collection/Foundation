package net.satisfy.foundation.block;

import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2621;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3917;
import net.minecraft.class_5561;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

public class CabinetBlockEntity extends class_2621 {
    private static final int ROWS = 4;
    private static final int SIZE = ROWS * 9;

    private class_2371<class_1799> inventory = class_2371.method_10213(SIZE, class_1799.field_8037);
    private final class_5561 openersCounter = new class_5561() {
        @Override
        protected void method_31681(class_1937 level, class_2338 pos, class_2680 state) {
            setOpen(level, pos, state, true);
        }

        @Override
        protected void method_31683(class_1937 level, class_2338 pos, class_2680 state) {
            setOpen(level, pos, state, false);
        }

        @Override
        protected void method_31682(class_1937 level, class_2338 pos, class_2680 state, int oldCount, int newCount) {
        }

        @Override
        protected boolean method_31679(class_1657 player) {
            return player.field_7512 instanceof class_1707 menu && menu.method_7629() == CabinetBlockEntity.this;
        }
    };

    public CabinetBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    private static void setOpen(class_1937 level, class_2338 pos, class_2680 state, boolean open) {
        if (state.method_28498(class_2741.field_12537)) {
            level.method_8652(pos, state.method_11657(class_2741.field_12537, open), 3);
        }
        if (state.method_26204() instanceof ContainerSoundBlock block) {
            block.playSound(level, pos, open);
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        if (!method_54872(tag)) {
            class_1262.method_5426(tag, inventory, provider);
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        inventory = class_2371.method_10213(method_5439(), class_1799.field_8037);
        if (!method_54871(tag)) {
            class_1262.method_5429(tag, inventory, provider);
        }
    }

    @Override
    public int method_5439() {
        return SIZE;
    }

    @Override
    protected @NotNull class_2371<class_1799> method_11282() {
        return inventory;
    }

    @Override
    protected void method_11281(class_2371<class_1799> items) {
        inventory = items;
    }

    @Override
    protected @NotNull class_2561 method_17823() {
        return class_2561.method_43471(method_11010().method_26204().method_9539());
    }

    @Override
    protected @NotNull class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return new class_1707(class_3917.field_18666, syncId, playerInventory, this, ROWS);
    }

    @Override
    public void method_5435(class_1657 player) {
        if (!field_11865 && !player.method_7325() && field_11863 != null) {
            openersCounter.method_31684(player, field_11863, method_11016(), method_11010());
        }
    }

    @Override
    public void method_5432(class_1657 player) {
        if (!field_11865 && !player.method_7325() && field_11863 != null) {
            openersCounter.method_31685(player, field_11863, method_11016(), method_11010());
        }
    }

    public void recheckOpen() {
        if (!field_11865 && field_11863 != null) {
            openersCounter.method_31686(field_11863, method_11016(), method_11010());
        }
    }
}
