package net.satisfy.foundation.entity.ai;

import net.minecraft.class_1309;
import org.jetbrains.annotations.Nullable;

public interface AttackAnimationMob {
    @Nullable
    class_1309 getAttackTarget();

    void setAttacking(boolean attacking);

    void performAttack(class_1309 target);
}
