package net.satisfy.foundation.block;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Block that connects to same blocks left and right (relative to its facing),
 * tracked in the {@link #TYPE} property. Used for benches, counters and so on.
 */
public class LineConnectingBlock extends class_2248 {
    public static final class_2753 FACING;
    public static final class_2754<LineConnectingType> TYPE;

    public LineConnectingBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(TYPE, LineConnectingType.NONE));
    }

    @Override
    protected class_1269 method_55766(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        return class_1269.field_5811;
    }

    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8042().method_10153();
        class_2680 blockState = this.method_9564().method_11657(FACING, facing);
        class_1937 world = context.method_8045();
        class_2338 clickedPos = context.method_8037();

        return switch (facing) {
            case field_11034 -> blockState.method_11657(TYPE, this.getType(blockState, world.method_8320(clickedPos.method_10072()), world.method_8320(clickedPos.method_10095())));
            case field_11035 -> blockState.method_11657(TYPE, this.getType(blockState, world.method_8320(clickedPos.method_10067()), world.method_8320(clickedPos.method_10078())));
            case field_11039 -> blockState.method_11657(TYPE, this.getType(blockState, world.method_8320(clickedPos.method_10095()), world.method_8320(clickedPos.method_10072())));
            default -> blockState.method_11657(TYPE, this.getType(blockState, world.method_8320(clickedPos.method_10078()), world.method_8320(clickedPos.method_10067())));
        };
    }

    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        if (!world.field_9236) {
            class_2350 facing = state.method_11654(FACING);
            LineConnectingType type = switch (facing) {
                case field_11034 -> this.getType(state, world.method_8320(pos.method_10072()), world.method_8320(pos.method_10095()));
                case field_11035 -> this.getType(state, world.method_8320(pos.method_10067()), world.method_8320(pos.method_10078()));
                case field_11039 -> this.getType(state, world.method_8320(pos.method_10095()), world.method_8320(pos.method_10072()));
                default -> this.getType(state, world.method_8320(pos.method_10078()), world.method_8320(pos.method_10067()));
            };

            if (state.method_11654(TYPE) != type) {
                state = state.method_11657(TYPE, type);
                world.method_8652(pos, state, 3);
            }
        }
    }

    /**
     * Figures out the connection type from the two side neighbours.
     * Only counts as connected if same block AND same facing.
     */
    public LineConnectingType getType(class_2680 state, class_2680 left, class_2680 right) {
        boolean shapeLeftSame = left.method_26204() == state.method_26204() && left.method_11654(FACING) == state.method_11654(FACING);
        boolean shapeRightSame = right.method_26204() == state.method_26204() && right.method_11654(FACING) == state.method_11654(FACING);
        if (shapeLeftSame && shapeRightSame) {
            return LineConnectingType.MIDDLE;
        } else if (shapeLeftSame) {
            return LineConnectingType.LEFT;
        } else {
            return shapeRightSame ? LineConnectingType.RIGHT : LineConnectingType.NONE;
        }
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, TYPE);
    }

    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    static {
        FACING = class_2741.field_12481;
        TYPE = class_2754.method_11850("type", LineConnectingType.class);
    }
}