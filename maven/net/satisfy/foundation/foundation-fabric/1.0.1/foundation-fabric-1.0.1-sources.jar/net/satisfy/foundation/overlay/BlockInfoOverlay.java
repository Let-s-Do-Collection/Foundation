package net.satisfy.foundation.overlay;

import java.util.Map;
import java.util.HashMap;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.architectury.event.events.client.ClientGuiEvent;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_9779;

/**
 * Little info panel floating next to blocks in the world (think Jade, but simple).
 * Mods register {@link BlockInfoProvider}s, the first one returning something wins.
 * Tries to render above the block, falls back to the side if there is no room.
 */
public final class BlockInfoOverlay {
    private static final int SEPARATOR_HEIGHT = 9;
    private static final int MIN_WIDTH = 56;
    private static final int COLOR_SEPARATOR = 0x40FFFFFF;
    private static final int PANEL_GAP = 6;
    private static final int SCREEN_MARGIN = 4;
    private static final double ABOVE_OFFSET = 0.45;
    private static final double SIDE_OFFSET = 0.7;
    private static final float[] ABOVE_SCALES = {1.0F, 0.8F, 0.65F};
    private static final float SIDE_SCALE = 0.8F;
    private static final long NOTICE_DURATION = 2000L;
    private static final long NOTICE_FADE = 600L;
    private static final int NOTICE_BACKGROUND = 0xF02A1C0C;
    private static final int NOTICE_BORDER_TOP = 0xF0F2C94C;
    private static final int NOTICE_BORDER_BOTTOM = 0xF0A0641E;
    private static final int TOOLTIP_BACKGROUND = 0xF0100010;
    private static final int TOOLTIP_BORDER_TOP = 0x505000FF;
    private static final int TOOLTIP_BORDER_BOTTOM = 0x5028007F;

    private static final List<BlockInfoProvider> PROVIDERS = new ArrayList<>();
    private static final Map<class_2338, PanelState> PANEL_STATES = new HashMap<>();
    private static final float STICKY_MARGIN = 24.0F;
    private static final float SMOOTHING_MILLIS = 60.0F;
    private static final long STATE_TIMEOUT = 500L;
    private static final int MAX_PANEL_STATES = 32;

    private record PanelState(float x, float y, float scale, float targetScale, boolean above, long lastSeen) {
    }
    private static final List<Supplier<Collection<class_2338>>> TRACKERS = new ArrayList<>();
    private static boolean initialized;
    private static class_2338 noticePos;
    private static class_2561 noticeMessage;
    private static List<class_2561> noticeLines = List.of();
    private static long noticeStart;

    private BlockInfoOverlay() {
    }

    /** Registers the hud render hook, safe to call multiple times. */
    public static void init() {
        if (!initialized) {
            initialized = true;
            ClientGuiEvent.RENDER_HUD.register(BlockInfoOverlay::render);
        }
    }

    /** Adds a provider. Order matters, first match wins. */
    public static void registerProvider(BlockInfoProvider provider) {
        PROVIDERS.add(provider);
    }

    /** Shows a short golden notice at a block for ~2 seconds, fades out at the end. */
    public static void showNotice(class_2338 pos, class_2561 message) {
        showNotice(pos, message, List.of());
    }

    public static void showNotice(class_2338 pos, class_2561 title, List<class_2561> lines) {
        noticePos = pos.method_10062();
        noticeMessage = title;
        noticeLines = List.copyOf(lines);
        noticeStart = System.currentTimeMillis();
    }

    /** Positions returned here always get a panel, even when not looked at. */
    public static void registerTracker(Supplier<Collection<class_2338>> tracker) {
        TRACKERS.add(tracker);
    }

    private static void render(class_332 graphics, class_9779 deltaTracker) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1690.field_1842) {
            return;
        }
        class_1937 level = minecraft.field_1687;
        graphics.method_51452();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        class_2338 notice = drawNotice(graphics, minecraft);
        class_2338 targeted = null;
        if (minecraft.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332) {
            targeted = hit.method_17777();
            if (!targeted.equals(notice)) {
                drawFirst(graphics, minecraft, level, targeted, hit);
            }
        }
        for (Supplier<Collection<class_2338>> tracker : TRACKERS) {
            for (class_2338 pos : tracker.get()) {
                if (!pos.equals(targeted) && !pos.equals(notice)) {
                    drawFirst(graphics, minecraft, level, pos, null);
                }
            }
        }
    }

    private static class_2338 drawNotice(class_332 graphics, class_310 minecraft) {
        if (noticePos == null) {
            return null;
        }
        long elapsed = System.currentTimeMillis() - noticeStart;
        if (elapsed >= NOTICE_DURATION) {
            noticePos = null;
            noticeMessage = null;
            return null;
        }
        float alpha = class_3532.method_15363((NOTICE_DURATION - elapsed) / (float) NOTICE_FADE, 0.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
        drawPanel(graphics, minecraft, noticePos, minecraft.field_1687.method_8320(noticePos), null, List.of(noticeLines.isEmpty() ? InfoSection.title(noticeMessage) : InfoSection.lines(noticeMessage, noticeLines)), false, true);
        graphics.method_51452();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        return noticePos;
    }

    private static void drawFirst(class_332 graphics, class_310 minecraft, class_1937 level, class_2338 pos, class_3965 hit) {
        class_2680 state = level.method_8320(pos);
        for (BlockInfoProvider provider : PROVIDERS) {
            List<InfoSection> sections = provider.describe(level, pos, state, hit);
            if (!sections.isEmpty()) {
                drawPanel(graphics, minecraft, pos, state, provider, sections, true, false);
                return;
            }
        }
    }

    private static void drawPanel(class_332 graphics, class_310 minecraft, class_2338 pos, class_2680 state, BlockInfoProvider provider, List<InfoSection> sections, boolean clamp, boolean notice) {
        class_265 shape = state.method_26218(minecraft.field_1687, pos);
        double top = shape.method_1110() ? 1.0 : shape.method_1105(class_2350.class_2351.field_11052);
        class_243 center = class_243.method_24955(pos).method_1031(0.0, top / 2.0, 0.0);
        Optional<float[]> above = project(minecraft, graphics, class_243.method_24955(pos).method_1031(0.0, top + ABOVE_OFFSET, 0.0));
        Optional<float[]> middle = project(minecraft, graphics, center);
        if (above.isEmpty() || middle.isEmpty()) {
            return;
        }
        class_327 font = minecraft.field_1772;
        int width = Math.max(MIN_WIDTH, sections.stream().mapToInt(section -> section.width(font)).max().orElse(0));
        int height = 0;
        for (int i = 0; i < sections.size(); i++) {
            height += sections.get(i).height() + (i > 0 ? SEPARATOR_HEIGHT : 0);
        }
        PanelState previous = PANEL_STATES.get(pos);
        long now = System.currentTimeMillis();
        boolean fresh = previous == null || now - previous.lastSeen > STATE_TIMEOUT;
        float scale = SIDE_SCALE;
        float x;
        float y = -1.0F;
        boolean placedAbove = false;
        for (float candidate : ABOVE_SCALES) {
            float panelTop = above.get()[1] - height * candidate - PANEL_GAP;
            boolean sticky = !fresh && previous.above && previous.targetScale == candidate;
            if (panelTop >= SCREEN_MARGIN - (sticky ? STICKY_MARGIN : 0.0F)) {
                scale = candidate;
                y = panelTop;
                placedAbove = true;
                break;
            }
        }
        if (placedAbove && !fresh && !previous.above) {
            float panelTop = above.get()[1] - height * scale - PANEL_GAP;
            if (panelTop < SCREEN_MARGIN + STICKY_MARGIN) {
                placedAbove = false;
            }
        }
        if (placedAbove) {
            x = above.get()[0] - width * scale / 2.0F;
        } else {
            scale = SIDE_SCALE;
            Optional<float[]> edge = project(minecraft, graphics, center.method_1019(new class_243(minecraft.field_1773.method_19418().method_35689()).method_1021(-SIDE_OFFSET)));
            x = (edge.isPresent() ? edge.get()[0] : middle.get()[0] + width * scale) + PANEL_GAP;
            y = middle.get()[1] - height * scale / 2.0F;
        }
        float targetScale = scale;
        if (!fresh) {
            float blend = 1.0F - (float) Math.exp(-(now - previous.lastSeen) / SMOOTHING_MILLIS);
            x = class_3532.method_16439(blend, previous.x, x);
            y = class_3532.method_16439(blend, previous.y, y);
            scale = class_3532.method_16439(blend, previous.scale, scale);
        }
        PANEL_STATES.put(pos.method_10062(), new PanelState(x, y, scale, targetScale, placedAbove, now));
        if (PANEL_STATES.size() > MAX_PANEL_STATES) {
            PANEL_STATES.entrySet().removeIf(entry -> now - entry.getValue().lastSeen > STATE_TIMEOUT);
        }
        if (clamp) {
            x = Math.clamp(x, SCREEN_MARGIN, graphics.method_51421() - width * scale - SCREEN_MARGIN);
            y = Math.clamp(y, SCREEN_MARGIN, graphics.method_51443() - height * scale - SCREEN_MARGIN);
        }
        graphics.method_51452();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(x, y, 400.0F);
        graphics.method_51448().method_22905(scale, scale, 1.0F);
        if (provider != null) {
            provider.beforeBackground(minecraft.field_1687, pos, state);
        }
        RenderSystem.disableDepthTest();
        if (notice) {
            drawBackground(graphics, width, height, NOTICE_BACKGROUND, NOTICE_BORDER_TOP, NOTICE_BORDER_BOTTOM);
        } else {
            drawBackground(graphics, width, height, TOOLTIP_BACKGROUND, TOOLTIP_BORDER_TOP, TOOLTIP_BORDER_BOTTOM);
        }
        graphics.method_51452();
        RenderSystem.enableDepthTest();
        int cursor = 0;
        for (int i = 0; i < sections.size(); i++) {
            if (i > 0) {
                graphics.method_25294(4, cursor + SEPARATOR_HEIGHT / 2, width - 4, cursor + SEPARATOR_HEIGHT / 2 + 1, COLOR_SEPARATOR);
                cursor += SEPARATOR_HEIGHT;
            }
            sections.get(i).draw(graphics, font, cursor, width);
            cursor += sections.get(i).height();
        }
        graphics.method_51448().method_22909();
        graphics.method_51452();
    }

    private static void drawBackground(class_332 graphics, int width, int height, int background, int borderTop, int borderBottom) {
        graphics.method_25294(-3, -4, width + 3, -3, background);
        graphics.method_25294(-3, height + 3, width + 3, height + 4, background);
        graphics.method_25294(-3, -3, width + 3, height + 3, background);
        graphics.method_25294(-4, -3, -3, height + 3, background);
        graphics.method_25294(width + 3, -3, width + 4, height + 3, background);
        graphics.method_25296(-3, -2, -2, height + 2, borderTop, borderBottom);
        graphics.method_25296(width + 2, -2, width + 3, height + 2, borderTop, borderBottom);
        graphics.method_25294(-3, -3, width + 3, -2, borderTop);
        graphics.method_25294(-3, height + 2, width + 3, height + 3, borderBottom);
    }

    private static Optional<float[]> project(class_310 minecraft, class_332 graphics, class_243 point) {
        class_4184 camera = minecraft.field_1773.method_19418();
        if (!camera.method_19332() || minecraft.field_1724 == null) {
            return Optional.empty();
        }
        class_243 offset = point.method_1020(camera.method_19326());
        Vector3f look = camera.method_19335();
        Vector3f up = camera.method_19336();
        Vector3f left = camera.method_35689();
        double depth = offset.field_1352 * look.x() + offset.field_1351 * look.y() + offset.field_1350 * look.z();
        if (depth <= 0.05) {
            return Optional.empty();
        }
        double side = (offset.field_1352 * left.x() + offset.field_1351 * left.y() + offset.field_1350 * left.z()) / depth;
        double vertical = (offset.field_1352 * up.x() + offset.field_1351 * up.y() + offset.field_1350 * up.z()) / depth;
        double fov = minecraft.field_1690.method_41808().method_41753() * minecraft.field_1724.method_3118();
        double scale = (graphics.method_51443() / 2.0) / Math.tan(Math.toRadians(fov) / 2.0);
        return Optional.of(new float[]{(float) (graphics.method_51421() / 2.0 - side * scale), (float) (graphics.method_51443() / 2.0 - vertical * scale)});
    }
}
