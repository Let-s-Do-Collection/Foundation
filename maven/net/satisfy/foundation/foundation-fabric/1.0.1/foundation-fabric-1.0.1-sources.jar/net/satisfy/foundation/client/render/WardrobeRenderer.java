package net.satisfy.foundation.client.render;

import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1531;
import net.minecraft.class_1799;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_572;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_970;
import net.satisfy.foundation.block.WardrobeBlock;
import net.satisfy.foundation.block.WardrobeBlockEntity;
import org.jetbrains.annotations.NotNull;

public class WardrobeRenderer implements class_827<WardrobeBlockEntity>, class_3883<class_1531, class_572<class_1531>> {
    public record Placement(float x, float y, float z, float yaw, float scale) {
    }

    public static final Placement CHEST = new Placement(-0.2F, 1.2F, 0.0F, 90.0F, 1.7F);
    public static final Placement LEGS = new Placement(0.2F, 1.6F, 0.0F, 90.0F, 1.7F);
    public static final Placement FEET = new Placement(0.2F, 1.4F, 0.0F, 45.0F, 1.7F);

    private final class_572<class_1531> baseModel;
    private final class_970<class_1531, class_572<class_1531>, class_572<class_1531>> armorLayer;
    private class_1531 dummy;

    public WardrobeRenderer(class_5614.class_5615 context) {
        this.baseModel = new class_572<>(context.method_32140(class_5602.field_27577));
        this.armorLayer = new class_970<>(this,
                new class_572<>(context.method_32140(class_5602.field_27579)),
                new class_572<>(context.method_32140(class_5602.field_27580)),
                class_310.method_1551().method_1554());
    }

    @Override
    public void render(WardrobeBlockEntity wardrobe, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, int packedOverlay) {
        if (wardrobe.method_10997() == null || wardrobe.method_11010().method_11654(WardrobeBlock.HALF) == class_2756.field_12609) {
            return;
        }
        if (dummy == null || dummy.method_37908() != wardrobe.method_10997()) {
            dummy = new class_1531(class_1299.field_6131, wardrobe.method_10997());
            dummy.method_6907(true);
            dummy.method_5648(true);
        }

        poseStack.method_22903();
        poseStack.method_22904(0.5, 1.6, 0.5);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-wardrobe.method_11010().method_11654(WardrobeBlock.field_11177).method_10144() + 180.0F));
        renderPiece(poseStack, buffer, packedLight, partialTicks, wardrobe.getItem(WardrobeBlockEntity.SLOT_CHEST), class_1304.field_6174, CHEST);
        renderPiece(poseStack, buffer, packedLight, partialTicks, wardrobe.getItem(WardrobeBlockEntity.SLOT_LEGS), class_1304.field_6172, LEGS);
        renderPiece(poseStack, buffer, packedLight, partialTicks, wardrobe.getItem(WardrobeBlockEntity.SLOT_FEET), class_1304.field_6166, FEET);
        poseStack.method_22909();
    }

    private void renderPiece(class_4587 poseStack, class_4597 buffer, int packedLight, float partialTicks, class_1799 stack, class_1304 slot, Placement placement) {
        if (stack.method_7960()) {
            return;
        }
        dummy.method_5673(slot, stack);
        poseStack.method_22903();
        poseStack.method_46416(placement.x, placement.y, placement.z);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(placement.yaw));
        poseStack.method_22905(placement.scale, -placement.scale, -placement.scale);
        armorLayer.method_17157(poseStack, buffer, packedLight, dummy, 0, 0, partialTicks, 0, 0, 0);
        poseStack.method_22909();
        dummy.method_5673(slot, class_1799.field_8037);
    }

    @Override
    public @NotNull class_572<class_1531> method_4038() {
        return baseModel;
    }

    @Override
    public @NotNull class_2960 getTextureLocation(class_1531 entity) {
        return class_2960.method_60656("textures/entity/armorstand/wood.png");
    }
}
