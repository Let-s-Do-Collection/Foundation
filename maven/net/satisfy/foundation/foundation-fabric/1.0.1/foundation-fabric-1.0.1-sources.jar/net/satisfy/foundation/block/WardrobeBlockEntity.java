package net.satisfy.foundation.block;

import net.minecraft.class_1262;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3829;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

public class WardrobeBlockEntity extends class_2586 implements class_3829 {
    public static final int SLOT_HEAD = 0;
    public static final int SLOT_CHEST = 1;
    public static final int SLOT_LEGS = 2;
    public static final int SLOT_FEET = 3;

    private final class_2371<class_1799> inventory = class_2371.method_10213(4, class_1799.field_8037);

    public WardrobeBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public static int slotFor(class_1304 slot) {
        return switch (slot) {
            case field_6169 -> SLOT_HEAD;
            case field_6174 -> SLOT_CHEST;
            case field_6172 -> SLOT_LEGS;
            case field_6166 -> SLOT_FEET;
            default -> -1;
        };
    }

    public class_1799 getItem(int slot) {
        return inventory.get(slot);
    }

    public void setStack(int slot, class_1799 stack) {
        inventory.set(slot, stack.method_7972());
        method_5431();
    }

    public class_2371<class_1799> getInventory() {
        return inventory;
    }

    @Override
    public void method_5431() {
        super.method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        inventory.clear();
        class_1262.method_5429(tag, inventory, provider);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        class_1262.method_5427(tag, inventory, true, provider);
    }

    @Override
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 provider) {
        return method_38244(provider);
    }

    @Override
    public void method_5448() {
        inventory.clear();
    }
}
