package net.satisfy.foundation.block;

import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5819;

/**
 * Generic berry bush, basically the vanilla sweet berry bush without the damage.
 * Optional blossom item can be picked at {@link #BLOOMING_AGE}.
 * Override {@link #growthChance()} or {@link #bonusYield(class_1937, class_2338)} if you need something else.
 */
public class BerryBushBlock extends class_2261 implements class_2256 {
    public static final int BLOOMING_AGE = 2;
    public static final int MAX_AGE = 3;
    public static final class_2758 AGE = class_2741.field_12497;
    private static final class_265 SAPLING_SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 8.0, 13.0);
    private static final class_265 GROWN_SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);

    private final Supplier<? extends class_1935> berry;
    private final Supplier<? extends class_1935> blossom;

    /** Bush without blossoms. */
    public BerryBushBlock(class_2251 properties, Supplier<? extends class_1935> berry) {
        this(properties, berry, null);
    }

    /** @param blossom item you get when harvesting at blooming age, can be null */
    public BerryBushBlock(class_2251 properties, Supplier<? extends class_1935> berry, Supplier<? extends class_1935> blossom) {
        super(properties);
        this.berry = berry;
        this.blossom = blossom;
        this.method_9590(this.field_10647.method_11664().method_11657(AGE, 0));
    }

    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        throw new UnsupportedOperationException();
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AGE);
    }

    @Override
    public class_1799 method_9574(class_4538 level, class_2338 pos, class_2680 state) {
        return new class_1799(berry.get());
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return state.method_11654(AGE) == 0 ? SAPLING_SHAPE : GROWN_SHAPE;
    }

    @Override
    protected boolean method_9542(class_2680 state) {
        return state.method_11654(AGE) < MAX_AGE;
    }

    @Override
    protected void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (level.method_22335(pos.method_10084(), 0) >= 9 && random.method_43048(growthChance()) == 0) {
            grow(state, level, pos);
        }
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        int age = state.method_11654(AGE);
        boolean pickBlossom = blossom != null && age == BLOOMING_AGE;
        if (age < MAX_AGE && !pickBlossom) {
            return class_1269.field_5811;
        }
        if (!level.field_9236) {
            int count = 1 + level.field_9229.method_43048(2) + bonusYield(level, pos);
            method_9577(level, pos, new class_1799(pickBlossom ? blossom.get() : berry.get(), count));
            level.method_8396(null, pos, class_3417.field_17617, class_3419.field_15245, 1.0F, 0.8F + level.field_9229.method_43057() * 0.4F);
            class_2680 harvested = state.method_11657(AGE, 1);
            level.method_8652(pos, harvested, class_2248.field_31028);
            level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, harvested));
        }
        return class_1269.method_29236(level.field_9236);
    }

    /** 1 in X chance per random tick to grow. Default 5. */
    protected int growthChance() {
        return 5;
    }

    /** Extra berries on harvest, 0 by default. Nice for fertilizer stuff. */
    protected int bonusYield(class_1937 level, class_2338 pos) {
        return 0;
    }

    private void grow(class_2680 state, class_3218 level, class_2338 pos) {
        class_2680 grown = state.method_11657(AGE, Math.min(MAX_AGE, state.method_11654(AGE) + 1));
        level.method_8652(pos, grown, class_2248.field_31028);
        level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43287(grown));
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return state.method_11654(AGE) < MAX_AGE;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        grow(state, level, pos);
    }
}
