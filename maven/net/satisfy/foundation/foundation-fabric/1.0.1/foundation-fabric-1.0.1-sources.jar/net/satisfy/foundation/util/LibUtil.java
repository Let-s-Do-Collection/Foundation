package net.satisfy.foundation.util;

import io.netty.buffer.Unpooled;
import org.jetbrains.annotations.Nullable;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3532;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_5328;
import net.minecraft.class_5712;
import net.minecraft.class_8110;
import net.minecraft.class_8111;
import net.minecraft.world.level.*;
import java.util.*;

/** Grab bag of small helpers, stuff that did not fit anywhere else. */
public final class LibUtil {
    private LibUtil() {
    }

    private static final String BLOCK_POS_KEY = "block_pos";

    private static final String BLOCK_POSES_KEY = "block_poses";

    /** Players that have this chunk loaded. */
    public static Collection<class_3222> tracking(class_3218 world, class_1923 pos) {
        Objects.requireNonNull(world, "The world cannot be null");
        Objects.requireNonNull(pos, "The chunk pos cannot be null");
        return world.method_14178().field_17254.method_17210(pos, false);
    }

    public static Collection<class_3222> tracking(class_3218 world, class_2338 pos) {
        Objects.requireNonNull(pos, "BlockPos cannot be null");
        return tracking(world, new class_1923(pos));
    }

    /** 50 -> 0.5f */
    public static float getInPercent(int i) {
        return (float)i / 100.0F;
    }

    /** After eating/drinking: gives {@code returnItem} back (bowl, bottle...) and awards stats. */
    public static class_1799 convertStackAfterFinishUsing(class_1309 entity, class_1799 used, class_1792 returnItem, class_1792 usedItem) {
        if (entity instanceof class_3222 serverPlayer) {
            class_174.field_1198.method_8821(serverPlayer, used);
            serverPlayer.method_7259(class_3468.field_15372.method_14956(usedItem));
        }

        if (used.method_7960()) {
            return new class_1799(returnItem);
        } else {
            if (entity instanceof class_1657) {
                class_1657 player = (class_1657)entity;
                if (!((class_1657)entity).method_31549().field_7477) {
                    class_1799 itemStack2 = new class_1799(returnItem);
                    if (!player.method_31548().method_7394(itemStack2)) {
                        player.method_7328(itemStack2, false);
                    }
                }
            }

            return used;
        }
    }

    /** Fills a bucket from a block and swaps the block state. */
    public static class_1269 fillBucket(class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_1799 itemStack, class_1799 returnItem, class_2680 blockState, class_3414 soundEvent) {
        if (!level.field_9236) {
            class_1792 item = itemStack.method_7909();
            player.method_6122(interactionHand, class_5328.method_30012(itemStack, player, returnItem));
            player.method_7259(class_3468.field_15372.method_14956(item));
            level.method_8501(blockPos, blockState);
            level.method_8396((class_1657)null, blockPos, soundEvent, class_3419.field_15245, 1.0F, 1.0F);
            level.method_33596((class_1297)null, class_5712.field_28167, blockPos);
        }

        return class_1269.method_29236(level.field_9236);
    }

    /** Empties a bucket into a block and swaps the block state. */
    public static class_1269 emptyBucket(class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_1799 itemStack, class_1799 returnItem, class_2680 blockState, class_3414 soundEvent) {
        if (!level.field_9236) {
            class_1792 item = itemStack.method_7909();
            player.method_6122(interactionHand, class_5328.method_30012(itemStack, player, returnItem));
            player.method_7259(class_3468.field_15372.method_14956(item));
            level.method_8501(blockPos, blockState);
            level.method_8396((class_1657)null, blockPos, soundEvent, class_3419.field_15245, 1.0F, 1.0F);
            level.method_33596((class_1297)null, class_5712.field_28166, blockPos);
        }

        return class_1269.method_29236(level.field_9236);
    }

    /** New log block with oak log properties. */
    public static class_2465 logBlock() {
        return new class_2465(class_4970.class_2251.method_9630(class_2246.field_10431));
    }

    public static boolean isDamageType(class_1282 source, List<class_5321<class_8110>> damageTypes) {
        Iterator var2 = damageTypes.iterator();

        class_5321 key;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            key = (class_5321)var2.next();
        } while(!source.method_49708(key));

        return true;
    }

    /** @return true for any kind of fire damage */
    public static boolean isFire(class_1282 source) {
        return isDamageType(source, List.of(class_8111.field_42337, class_8111.field_42335, class_8111.field_42325, class_8111.field_42324, class_8111.field_42326));
    }

    public static boolean isIndexInRange(int index, int startInclusive, int endInclusive) {
        return index >= startInclusive && index <= endInclusive;
    }

    public static class_2540 create() {
        return new class_2540(Unpooled.buffer());
    }

    /** Drops the item out of the given face of the block, respecting the collision shape. */
    public static void popResourceFromFace(class_1937 level, class_2338 blockPos, class_2350 side, class_1799 itemStack) {
        class_2680 blockState = level.method_8320(blockPos);
        double itemWidth = (double) class_1299.field_6052.method_17685();
        double itemHeight = (double)class_1299.field_6052.method_17686();
        class_265 shape = blockState.method_26220(level, blockPos);
        double posX = (double)blockPos.method_10263() + 0.5;
        double posY = (double)blockPos.method_10264() + 0.5;
        double posZ = (double)blockPos.method_10260() + 0.5;
        double offsetX = 0.0;
        double offsetY = 0.0;
        double offsetZ = 0.0;
        switch (side) {
            case field_11033:
                posY = (double)blockPos.method_10264() - shape.method_1091(class_2350.class_2351.field_11052);
                offsetY = -itemHeight * 2.0;
                break;
            case field_11036:
                posY = (double)blockPos.method_10264() + shape.method_1105(class_2350.class_2351.field_11052);
                break;
            case field_11043:
                posZ = (double)blockPos.method_10260() + shape.method_1091(class_2350.class_2351.field_11051);
                offsetZ = -itemWidth;
                break;
            case field_11035:
                posZ = (double)blockPos.method_10260() + shape.method_1105(class_2350.class_2351.field_11051);
                offsetZ = itemWidth;
                break;
            case field_11039:
                posX = (double)blockPos.method_10263() + shape.method_1091(class_2350.class_2351.field_11048);
                offsetX = -itemWidth;
                break;
            case field_11034:
                posX = (double)blockPos.method_10263() + shape.method_1105(class_2350.class_2351.field_11048);
                offsetX = itemWidth;
        }

        int i = side.method_10148();
        int j = side.method_10164();
        int k = side.method_10165();
        double deltaX = i == 0 ? class_3532.method_15366(level.field_9229, -0.1, 0.1) : (double)i * 0.1;
        double deltaY = j == 0 ? class_3532.method_15366(level.field_9229, 0.0, 0.1) : (double)j * 0.1 + 0.1;
        double deltaZ = k == 0 ? class_3532.method_15366(level.field_9229, -0.1, 0.1) : (double)k * 0.1;
        popResource(level, new class_1542(level, posX + offsetX, posY + offsetY, posZ + offsetZ, itemStack, deltaX, deltaY, deltaZ), itemStack);
    }

    private static void popResource(class_1937 level, class_1542 itemEntity, class_1799 itemStack) {
        if (!level.field_9236 && !itemStack.method_7960() && level.method_8450().method_8355(class_1928.field_19392)) {
            itemEntity.method_6988();
            level.method_8649(itemEntity);
        }

    }

    /** Stores a pos as int array under {@code block_pos}. */
    public static void putBlockPos(class_2487 compoundTag, class_2338 blockPos) {
        if (blockPos != null) {
            int[] positions = new int[]{blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()};
            compoundTag.method_10539("block_pos", positions);
        }
    }

    /** Stores multiple positions flat into one int array. */
    public static void putBlockPoses(class_2487 compoundTag, Collection<class_2338> blockPoses) {
        if (blockPoses != null && !blockPoses.isEmpty()) {
            int[] positions = new int[blockPoses.size() * 3];
            int pos = 0;

            for(Iterator var4 = blockPoses.iterator(); var4.hasNext(); ++pos) {
                class_2338 blockPos = (class_2338)var4.next();
                positions[pos * 3] = blockPos.method_10263();
                positions[pos * 3 + 1] = blockPos.method_10264();
                positions[pos * 3 + 2] = blockPos.method_10260();
            }

            compoundTag.method_10539("block_poses", positions);
        }
    }

    public static @Nullable class_2338 readBlockPos(class_2487 compoundTag) {
        if (!compoundTag.method_10545("block_pos")) {
            return null;
        } else {
            int[] positions = compoundTag.method_10561("block_pos");
            return new class_2338(positions[0], positions[1], positions[2]);
        }
    }

    public static Set<class_2338> readBlockPoses(class_2487 compoundTag) {
        Set<class_2338> blockSet = new HashSet<>();
        if (!compoundTag.method_10545("block_poses")) {
            return blockSet;
        } else {
            int[] positions = compoundTag.method_10561("block_poses");

            for(int pos = 0; pos < positions.length / 3; ++pos) {
                blockSet.add(new class_2338(positions[pos * 3], positions[pos * 3 + 1], positions[pos * 3 + 2]));
            }

            return blockSet;
        }
    }
}
