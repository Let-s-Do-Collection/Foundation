package net.satisfy.foundation.client;

import dev.architectury.registry.client.rendering.ColorHandlerRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_7923;
import net.satisfy.foundation.block.SofaBlock;
import net.satisfy.foundation.block.TableBlock;

import java.util.ArrayList;
import java.util.List;

public final class FurnitureColors {
    private FurnitureColors() {
    }

    public static void init() {
        List<class_2248> tables = new ArrayList<>();
        List<class_2248> sofas = new ArrayList<>();
        for (class_2248 block : class_7923.field_41175) {
            if (block instanceof TableBlock) tables.add(block);
            if (block instanceof SofaBlock) sofas.add(block);
        }
        if (!tables.isEmpty()) {
            ColorHandlerRegistry.registerBlockColors((state, level, pos, tintIndex) -> {
                return state.method_11654(TableBlock.TABLECLOTH).tint();
            }, tables.toArray(new class_2248[0]));
        }
        if (!sofas.isEmpty()) {
            ColorHandlerRegistry.registerBlockColors((state, level, pos, tintIndex) -> state.method_11654(SofaBlock.COLOR).tint(), sofas.toArray(new class_2248[0]));
        }
    }
}
