package net.satisfy.foundation.block;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Leaves that grow fruit over time (apples, cherries ...). Only some leaves can carry fruit,
 * rolled on placement. Ripe fruit (age 3) is picked with an empty hand, bone meal speeds it up.
 * <p>
 * Subclasses name the two boolean properties themselves (keeps existing blockstates/worlds intact)
 * and say which item drops and how fast it grows. Leaf distance stays vanilla: neighbour updates
 * only schedule a tick, they never change the state right away.
 */
public abstract class FruitLeavesBlock extends class_2397 implements class_2256 {
    public static final class_2758 AGE = class_2758.method_11867("age", 0, 3);

    public FruitLeavesBlock(class_2251 properties) {
        this(properties, false);
    }

    public FruitLeavesBlock(class_2251 properties, boolean persistentByDefault) {
        super(properties);
        method_9590(field_10647.method_11664()
                .method_11657(field_11200, persistentByDefault)
                .method_11657(field_11199, 7)
                .method_11657(canGrowFruitProperty(), false)
                .method_11657(hasFruitProperty(), false)
                .method_11657(AGE, 0)
                .method_11657(field_38227, false));
    }

    /** Whether these leaves can carry fruit at all. Must be a static constant of the subclass. */
    protected abstract class_2746 canGrowFruitProperty();

    /** Whether fruit is currently hanging. Must be a static constant of the subclass. */
    protected abstract class_2746 hasFruitProperty();

    protected abstract class_1792 fruitItem();

    /** Chance per random tick to advance one growth step. */
    protected abstract double growthChance();

    @Override
    public @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (state.method_11654(hasFruitProperty()) && state.method_11654(AGE) == 3) {
            if (!level.method_8608()) {
                int dropCount = level.method_8409().method_43056() ? level.method_8409().method_43051(1, 4) : 1;
                method_36992(level, pos, hit.method_17780(), new class_1799(fruitItem(), dropCount));
                level.method_8396(null, pos, class_3417.field_14770, class_3419.field_15245, 1F, 1F);
                level.method_8652(pos, state.method_11657(hasFruitProperty(), false).method_11657(AGE, 1), 2);
            }
            return class_1269.field_5812;
        }
        return super.method_55766(state, level, pos, player, hit);
    }

    @Override
    public boolean method_9542(class_2680 state) {
        boolean canGrow = state.method_11654(canGrowFruitProperty());
        boolean has = state.method_11654(hasFruitProperty());
        int age = state.method_11654(AGE);
        return (canGrow && !has && age < 2) || (has && age == 2) || super.method_9542(state);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        boolean canGrow = context.method_8045().field_9229.method_43057() < 0.3f;
        return method_10300(method_9564()
                .method_11657(field_11200, true)
                .method_11657(canGrowFruitProperty(), canGrow)
                .method_11657(AGE, 0)
                .method_11657(hasFruitProperty(), false)
                .method_11657(field_38227, false), context.method_8045(), context.method_8037());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(canGrowFruitProperty(), hasFruitProperty(), AGE);
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        super.method_9514(state, level, pos, random);
        if (random.method_43058() < growthChance()) {
            grow(level, pos, state);
        }
    }

    /** Advances the fruit one step if possible. Returns false when nothing changed. */
    protected boolean grow(class_1937 level, class_2338 pos, class_2680 state) {
        if (!canGrowHere(level, pos)) return false;
        boolean has = state.method_11654(hasFruitProperty());
        int age = state.method_11654(AGE);
        class_2680 newState;
        if (!has && age < 2 && state.method_11654(canGrowFruitProperty())) {
            newState = age == 0 ? state.method_11657(AGE, 1) : state.method_11657(AGE, 2).method_11657(hasFruitProperty(), true);
        } else if (has && age == 2) {
            newState = state.method_11657(AGE, 3);
        } else {
            return false;
        }
        level.method_8652(pos, newState, 2);
        level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43287(newState));
        return true;
    }

    protected boolean canGrowHere(class_4538 level, class_2338 pos) {
        return level.method_22335(pos, 0) > 9;
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        int age = state.method_11654(AGE);
        boolean has = state.method_11654(hasFruitProperty());
        return (age < 2 && !has) || (age == 2 && has);
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        grow(level, pos, state.method_11657(canGrowFruitProperty(), true));
    }

    @Override
    public int method_9505(class_2680 state, class_1922 level, class_2338 pos) {
        return 1;
    }

    private static class_2680 method_10300(class_2680 state, class_1936 level, class_2338 pos) {
        int minDistance = 7;
        for (class_2350 direction : class_2350.values()) {
            class_2680 neighbor = level.method_8320(pos.method_10093(direction));
            int distance = neighbor.method_26204() instanceof class_2397 ? neighbor.method_11654(field_11199) : (neighbor.method_26164(class_3481.field_15475) ? 0 : 7);
            minDistance = Math.min(minDistance, distance + 1);
            if (minDistance == 1) break;
        }
        return state.method_11657(field_11199, minDistance);
    }
}
