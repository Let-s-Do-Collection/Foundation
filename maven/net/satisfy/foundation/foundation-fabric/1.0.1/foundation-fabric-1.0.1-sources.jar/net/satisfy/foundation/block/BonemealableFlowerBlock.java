package net.satisfy.foundation.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2256;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;

/** Flower that drops a copy of itself when bonemealed (60% chance). Like vanilla tall flowers. */
public class BonemealableFlowerBlock extends class_2261 implements class_2256 {

    public static final MapCodec<BonemealableFlowerBlock> CODEC =
            method_54094(BonemealableFlowerBlock::new);

    private static final float RETURN_CHANCE = 0.6F;

    public BonemealableFlowerBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected @NotNull MapCodec<? extends class_2261> method_53969() {
        return field_46280;
    }

    @Override
    public boolean method_9651(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return true;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        return true;
    }

    @Override
    public void method_9652(class_3218 serverLevel, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        if (randomSource.method_43057() < RETURN_CHANCE) {
            method_9577(serverLevel, blockPos, new class_1799(this));
        }
    }
}