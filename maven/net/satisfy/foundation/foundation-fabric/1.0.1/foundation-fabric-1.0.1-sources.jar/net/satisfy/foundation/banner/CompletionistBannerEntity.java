package net.satisfy.foundation.banner;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/** Block entity of the banner, only does the effect ticking. */
public class CompletionistBannerEntity extends class_2586 {
    private static final int EFFECT_INTERVAL = 20;
    private static final int EFFECT_DURATION = 60;

    public CompletionistBannerEntity(class_2338 blockPos, class_2680 state) {
        super(((CompletionistBannerBlock) state.method_26204()).getSettings().type().get(), blockPos, state);
    }

    /** Every second: the banner's effect for all players within its radius. Server only. */
    public static void tick(class_1937 level, class_2338 pos, class_2680 state) {
        if (!(state.method_26204() instanceof CompletionistBannerBlock banner)) {
            return;
        }
        BannerSettings settings = banner.getSettings();
        if (!level.field_9236 && level.method_8510() % EFFECT_INTERVAL == 0) {
            int radius = settings.radius().getAsInt();
            if (radius <= 0) {
                return;
            }
            class_238 effectRadius = new class_238(pos).method_1014(radius);
            List<class_1657> players = level.method_18467(class_1657.class, effectRadius);
            for (class_1657 player : players) {
                player.method_6092(new class_1293(settings.effect(), EFFECT_DURATION, settings.amplifier().getAsInt(), true, false));
            }
        }
    }
}
