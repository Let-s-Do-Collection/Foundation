package net.satisfy.foundation.block;

import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;

public class WardrobeBlock extends class_2383 implements class_2343 {
    public static final MapCodec<WardrobeBlock> CODEC = method_54094(properties -> new WardrobeBlock(properties, () -> null));
    public static final class_2746 OPEN = class_2741.field_12537;
    public static final class_2754<class_2756> HALF = class_2741.field_12533;
    private static final class_265 LOWER_SHAPE = class_259.method_17786(
            class_2248.method_9541(0.0D, 0.0D, 0.0D, 4.0D, 2.0D, 4.0D),
            class_2248.method_9541(12.0D, 0.0D, 0.0D, 16.0D, 2.0D, 4.0D),
            class_2248.method_9541(0.0D, 0.0D, 12.0D, 4.0D, 2.0D, 16.0D),
            class_2248.method_9541(12.0D, 0.0D, 12.0D, 16.0D, 2.0D, 16.0D),
            class_2248.method_9541(0.0D, 2.0D, 0.0D, 16.0D, 16.0D, 16.0D));

    private final Supplier<? extends class_2591<? extends WardrobeBlockEntity>> blockEntityType;

    public WardrobeBlock(class_2251 properties, Supplier<? extends class_2591<? extends WardrobeBlockEntity>> blockEntityType) {
        super(properties);
        this.blockEntityType = blockEntityType;
        method_9590(field_10647.method_11664().method_11657(field_11177, class_2350.field_11043).method_11657(OPEN, false).method_11657(HALF, class_2756.field_12607));
    }

    @Override
    protected @NotNull MapCodec<? extends WardrobeBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, OPEN, HALF);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2338 pos = context.method_8037();
        class_1937 level = context.method_8045();
        if (pos.method_10264() < level.method_31600() - 1 && level.method_8320(pos.method_10084()).method_26166(context)) {
            return method_9564().method_11657(field_11177, context.method_8042().method_10153());
        }
        return null;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        level.method_8652(pos.method_10084(), state.method_11657(HALF, class_2756.field_12609), 3);
    }

    @Override
    public @NotNull class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (!level.field_9236) {
            class_2756 half = state.method_11654(HALF);
            class_2338 basePos = half == class_2756.field_12607 ? pos : pos.method_10074();
            if (level.method_8321(basePos) instanceof WardrobeBlockEntity wardrobe) {
                for (int slot = 0; slot < wardrobe.getInventory().size(); slot++) {
                    class_1799 stored = wardrobe.getItem(slot);
                    if (!stored.method_7960()) {
                        class_2248.method_9577(level, basePos, stored.method_7972());
                        wardrobe.setStack(slot, class_1799.field_8037);
                    }
                }
            }

            class_2338 otherPos = half == class_2756.field_12607 ? pos.method_10084() : pos.method_10074();
            class_2680 other = level.method_8320(otherPos);
            if (other.method_27852(this) && other.method_11654(HALF) != half) {
                level.method_8652(otherPos, class_2246.field_10124.method_9564(), 35);
                level.method_8444(player, 2001, otherPos, class_2248.method_9507(other));
            }
        }
        return super.method_9576(level, pos, state, player);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level.field_9236) {
            return class_1269.field_5812;
        }
        class_2338 basePos = basePos(state, pos);
        if (!(level.method_8321(basePos) instanceof WardrobeBlockEntity wardrobe)) {
            return class_1269.field_5811;
        }
        if (player.method_5715()) {
            for (int slot = 0; slot < wardrobe.getInventory().size(); slot++) {
                class_1799 stored = wardrobe.getItem(slot);
                if (!stored.method_7960()) {
                    player.method_7270(stored.method_7972());
                    wardrobe.setStack(slot, class_1799.field_8037);
                    return class_1269.field_21466;
                }
            }
            return class_1269.field_5811;
        }
        toggleOpen(level, basePos);
        return class_1269.field_21466;
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!(stack.method_7909() instanceof class_1738 armor)) {
            return class_9062.field_47731;
        }
        int slot = WardrobeBlockEntity.slotFor(armor.method_7685());
        if (slot < 0) {
            return class_9062.field_47731;
        }
        if (level.field_9236) {
            return class_9062.field_47728;
        }
        if (!(level.method_8321(basePos(state, pos)) instanceof WardrobeBlockEntity wardrobe)) {
            return class_9062.field_47731;
        }
        class_1799 existing = wardrobe.getItem(slot);
        wardrobe.setStack(slot, stack.method_46651(1));
        stack.method_7934(1);
        if (!existing.method_7960()) {
            player.method_7270(existing);
        }
        return class_9062.field_47729;
    }

    private static class_2338 basePos(class_2680 state, class_2338 pos) {
        return state.method_11654(HALF) == class_2756.field_12609 ? pos.method_10074() : pos;
    }

    private void toggleOpen(class_1937 level, class_2338 basePos) {
        class_2680 state = level.method_8320(basePos);
        if (!state.method_27852(this)) {
            return;
        }
        boolean open = !state.method_11654(OPEN);
        level.method_8652(basePos, state.method_11657(OPEN, open), 3);
        class_2680 upper = level.method_8320(basePos.method_10084());
        if (upper.method_27852(this)) {
            level.method_8652(basePos.method_10084(), upper.method_11657(OPEN, open), 3);
        }
        level.method_8396(null, basePos, open ? class_3417.field_14664 : class_3417.field_14541, class_3419.field_15245, 1.0F, 1.0F);
    }

    @Override
    protected @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    @Override
    protected @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected boolean method_9526(class_2680 state) {
        return true;
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return state.method_11654(HALF) == class_2756.field_12609 ? class_259.method_1077() : LOWER_SHAPE;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return state.method_11654(HALF) == class_2756.field_12607 ? blockEntityType.get().method_11032(pos, state) : null;
    }
}
