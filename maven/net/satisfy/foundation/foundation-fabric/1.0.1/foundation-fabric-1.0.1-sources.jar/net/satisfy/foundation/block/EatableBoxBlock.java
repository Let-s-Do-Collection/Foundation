package net.satisfy.foundation.block;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_247;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_9062;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@SuppressWarnings("deprecation")
public class EatableBoxBlock extends FacingBlock {
    public static final class_2758 CUTS = class_2758.method_11867("cuts", 0, 5);

    public EatableBoxBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(CUTS, 0));
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 blockHitResult) {
        class_1799 itemStack = player.method_5998(hand);
        if (world.field_9236) {
            if (tryEat(world, pos, state, player).method_55643()) {
                return class_9062.field_47728;
            }
            if (itemStack.method_7960()) {
                return class_9062.field_47729;
            }
        }
        return tryEat(world, pos, state, player);
    }

    private class_9062 tryEat(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        world.method_8396(null, pos, class_3417.field_18060, class_3419.field_15248, 0.5f, world.method_8409().method_43057() * 0.1f + 0.9f);
        player.method_7344().method_7585(1, 0.4f);
        int cuts = state.method_11654(CUTS);
        world.method_33596(player, class_5712.field_28735, pos);
        if (cuts < 5) {
            world.method_8652(pos, state.method_11657(CUTS, cuts + 1), class_2248.field_31036);
        } else {
            world.method_22352(pos, false);
            class_1799 bowlStack = new class_1799(class_1802.field_8106);
            class_1542 itemEntity = new class_1542(world, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, bowlStack);
            world.method_8649(itemEntity);
        }
        return class_9062.field_47728;
    }


    @Override
    public @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (direction == class_2350.field_11033 && !state.method_26184(world, pos)) {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        return world.method_8320(pos.method_10074()).method_51367();
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(CUTS);

    }

    private static final Supplier<class_265> voxelShapeSupplier = () -> {
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1082(shape, class_259.method_1081(0.1875, 0, 0.25, 0.8125, 0.125, 0.74375), class_247.field_1366);
        shape = class_259.method_1082(shape, class_259.method_1081(0.75, 0.125, 0.25, 0.8125, 0.1875, 0.74375), class_247.field_1366);
        shape = class_259.method_1082(shape, class_259.method_1081(0.1875, 0.125, 0.25, 0.25, 0.1875, 0.74375), class_247.field_1366);
        shape = class_259.method_1082(shape, class_259.method_1081(0.25, 0.125, 0.25, 0.75, 0.1875, 0.30625), class_247.field_1366);
        shape = class_259.method_1082(shape, class_259.method_1081(0.25, 0.125, 0.68125, 0.75, 0.1875, 0.74375), class_247.field_1366);
        return shape;
    };

    public static final Map<class_2350, class_265> SHAPE = class_156.method_654(new HashMap<>(), map -> {
        for (class_2350 direction : class_2350.class_2353.field_11062.method_29716().toList()) {
            map.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, voxelShapeSupplier.get()));
        }
    });

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE.get(state.method_11654(field_11177));
    }

    @Override
    public void method_9568(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        tooltip.add(class_2561.method_43471("tooltip.foundation.canbeplaced").method_27695(class_124.field_1056, class_124.field_1080));
    }
}