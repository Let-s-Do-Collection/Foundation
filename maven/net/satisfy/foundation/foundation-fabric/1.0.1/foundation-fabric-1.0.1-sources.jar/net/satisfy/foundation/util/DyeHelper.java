package net.satisfy.foundation.util;

import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5253;
import net.minecraft.class_9062;
import net.minecraft.class_9381;
import net.satisfy.foundation.registry.FoundationParticles;

/** Dyeing blocks with a nice splash effect. */
public final class DyeHelper {
    private static final int SPLASH_PARTICLES = 16;

    private DyeHelper() {
    }

    /** Sets the color property, passes if the block already has that color. */
    public static class_9062 dye(class_1799 stack, class_1767 color, class_2680 state, class_2754<class_1767> property, class_1937 level, class_2338 pos, class_1657 player) {
        if (state.method_11654(property) == color) {
            return class_9062.field_47731;
        }
        return apply(stack, color, state.method_11657(property, color), level, pos, player);
    }

    /** Places the dyed state, uses one dye and spawns splash particles. */
    public static class_9062 apply(class_1799 stack, class_1767 color, class_2680 dyed, class_1937 level, class_2338 pos, class_1657 player) {
        if (level instanceof class_3218 serverLevel) {
            level.method_8652(pos, dyed, class_2248.field_31036);
            stack.method_57008(1, player);
            level.method_8396(null, pos, class_3417.field_28391, class_3419.field_15245, 1.0F, 1.0F);
            class_9381 splash = class_9381.method_58256(FoundationParticles.DYE_SPLASH.get(), class_5253.class_5254.method_57174(color.method_7787()));
            serverLevel.method_14199(splash, pos.method_10263() + 0.5, pos.method_10264() + 0.4, pos.method_10260() + 0.5, SPLASH_PARTICLES, 0.3, 0.1, 0.3, 0.08);
        }
        return class_9062.method_55644(level.field_9236);
    }
}
