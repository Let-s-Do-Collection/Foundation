package net.satisfy.foundation.seat;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2945;
import net.minecraft.class_3231;

/**
 * Invisible entity the player rides while sitting. Gets discarded on dismount
 * and puts the player back where they came from.
 */
public class ChairEntity extends class_1297 {
    public ChairEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {

    }

    public class_243 method_24829(class_1309 passenger) {
        if (passenger instanceof class_1657 p) {
            class_2338 pos = SeatUtil.getPreviousPlayerPosition(p, this);
            if (pos != null) {
                this.method_31472();
                return new class_243((double)pos.method_10263() + 0.5, (double)pos.method_10264(), (double)pos.method_10260() + 0.5);
            }
        }

        this.method_31472();
        return super.method_24829(passenger);
    }

    public void method_5650(class_5529 reason) {
        super.method_5650(reason);
        SeatUtil.removeChairEntity(this.method_37908(), this.method_24515());
    }

    protected void method_5749(class_2487 nbt) {
    }

    protected void method_5652(class_2487 nbt) {
    }

    @Override
    public class_2596<class_2602> method_18002(class_3231 server) {
        return new class_2604(this, server);
    }
}