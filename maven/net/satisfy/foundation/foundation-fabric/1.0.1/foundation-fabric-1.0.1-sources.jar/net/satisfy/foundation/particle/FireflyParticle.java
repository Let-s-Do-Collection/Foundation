package net.satisfy.foundation.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.NotNull;

/** Glowing firefly, wanders around and pulses. Always full bright. */
public class FireflyParticle extends class_4003 {
    private static final int FULL_BRIGHT = 15728880;
    private static final double WANDER = 0.003;
    private static final double MAX_SPEED = 0.02;

    private final class_4002 sprites;
    private final float pulseOffset;

    protected FireflyParticle(class_638 level, double x, double y, double z, class_4002 sprites) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.field_3847 = 100 + this.field_3840.method_43048(80);
        this.field_3844 = 0.0F;
        this.field_3862 = false;
        this.field_17867 = 0.04F + this.field_3840.method_43057() * 0.02F;
        this.pulseOffset = this.field_3840.method_43057() * class_3532.field_29846;
        this.field_3852 = (this.field_3840.method_43058() - 0.5) * MAX_SPEED;
        this.field_3869 = (this.field_3840.method_43058() - 0.5) * MAX_SPEED * 0.5;
        this.field_3850 = (this.field_3840.method_43058() - 0.5) * MAX_SPEED;
        this.field_3841 = 0.0F;
        this.method_18142(sprites);
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        this.field_3852 = class_3532.method_15350(this.field_3852 + (this.field_3840.method_43058() - 0.5) * WANDER, -MAX_SPEED, MAX_SPEED);
        this.field_3869 = class_3532.method_15350(this.field_3869 + (this.field_3840.method_43058() - 0.5) * WANDER * 0.5, -MAX_SPEED * 0.5, MAX_SPEED * 0.5);
        this.field_3850 = class_3532.method_15350(this.field_3850 + (this.field_3840.method_43058() - 0.5) * WANDER, -MAX_SPEED, MAX_SPEED);
        this.method_3069(this.field_3852, this.field_3869, this.field_3850);
        float fade = Math.min(1.0F, Math.min(this.field_3866, this.field_3847 - this.field_3866) / 20.0F);
        float pulse = 0.55F + 0.45F * class_3532.method_15374(this.field_3866 * 0.15F + this.pulseOffset);
        this.field_3841 = fade * pulse;
        this.method_18142(this.sprites);
    }

    @Override
    protected int method_3068(float partialTick) {
        return FULL_BRIGHT;
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17829;
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new FireflyParticle(level, x, y, z, this.sprites);
        }
    }
}
