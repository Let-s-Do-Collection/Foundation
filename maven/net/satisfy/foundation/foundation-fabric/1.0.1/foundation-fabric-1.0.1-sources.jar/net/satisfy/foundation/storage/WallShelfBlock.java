package net.satisfy.foundation.storage;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.satisfy.foundation.util.ShapeUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class WallShelfBlock extends StorageBlock {
    public static final int SIZE = 9;
    public static final class_265 DEFAULT_SHAPE = class_259.method_1084(class_259.method_1081(0, 0.25, 0.5, 1, 0.3125, 1), class_259.method_1081(0, 0.125, 0.875, 1, 0.25, 1));

    private final Supplier<? extends class_2591<?>> blockEntityType;
    private final class_2960 type;
    private final Predicate<class_1799> canInsert;
    private final Map<class_2350, class_265> shapes = new EnumMap<>(class_2350.class);

    public WallShelfBlock(class_2251 properties, Supplier<? extends class_2591<?>> blockEntityType, class_2960 type, Predicate<class_1799> canInsert) {
        this(properties, blockEntityType, type, canInsert, DEFAULT_SHAPE);
    }

    public WallShelfBlock(class_2251 properties, Supplier<? extends class_2591<?>> blockEntityType, class_2960 type, Predicate<class_1799> canInsert, class_265 northShape) {
        super(properties);
        this.blockEntityType = blockEntityType;
        this.type = type;
        this.canInsert = canInsert;
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            shapes.put(direction, ShapeUtil.rotateShape(class_2350.field_11043, direction, northShape));
        }
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2350 side = context.method_8038();
        class_2350 facing = side.method_10166().method_10179() ? side : context.method_8042().method_10153();
        class_2680 state = method_9564().method_11657(field_11177, facing);
        return state.method_26184(context.method_8045(), context.method_8037()) ? state : null;
    }

    @Override
    public class_2591<?> blockEntityType() {
        return blockEntityType.get();
    }

    @Override
    public int size() {
        return SIZE;
    }

    @Override
    public class_2960 type() {
        return type;
    }

    @Override
    public class_2350[] unAllowedDirections() {
        return new class_2350[]{class_2350.field_11033};
    }

    @Override
    public boolean canInsertStack(class_1799 stack) {
        return canInsert.test(stack);
    }

    @Override
    public int getSection(Float x, Float y) {
        return SIZE - 1 - class_3532.method_15340((int) (x * SIZE), 0, SIZE - 1);
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return shapes.get(state.method_11654(field_11177));
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2350 facing = state.method_11654(field_11177);
        class_2338 wall = pos.method_10093(facing.method_10153());
        return class_2248.method_9501(level.method_8320(wall).method_26218(level, wall), facing);
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (!state.method_26184(level, pos)) {
            level.method_22352(pos, true);
        }
    }

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (!state.method_26184(level, pos)) {
            level.method_39279(pos, this, 1);
        }
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }
}
