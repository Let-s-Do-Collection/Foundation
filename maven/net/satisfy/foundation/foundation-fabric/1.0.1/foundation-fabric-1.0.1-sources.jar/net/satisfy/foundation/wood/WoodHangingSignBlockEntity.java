package net.satisfy.foundation.wood;

import net.minecraft.class_2338;
import net.minecraft.class_2478;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7717;
import org.jetbrains.annotations.NotNull;

public class WoodHangingSignBlockEntity extends class_7717 {
    private final class_2591<?> type;

    public WoodHangingSignBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(pos, state);
        this.type = type;
    }

    @Override
    public @NotNull class_2591<?> method_11017() {
        return type;
    }

    @Override
    public boolean method_61176(class_2680 state) {
        return state.method_26204() instanceof class_2478;
    }
}
