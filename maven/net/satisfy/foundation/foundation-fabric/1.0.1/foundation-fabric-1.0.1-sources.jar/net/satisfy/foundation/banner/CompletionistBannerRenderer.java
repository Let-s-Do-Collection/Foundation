package net.satisfy.foundation.banner;

import net.minecraft.class_1088;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.client.model.geom.builders.*;
import net.satisfy.foundation.Foundation;

/**
 * Renders the banner model incl. the little wave animation of the flag.
 * Works for standing, wall and inventory rendering.
 */
public class CompletionistBannerRenderer implements class_827<CompletionistBannerEntity> {
    public static final class_5601 LAYER_LOCATION = new class_5601(Foundation.identifier("completionist_banner"), "main");

    public static final String FLAG = "flag";
    private static final String POLE = "pole";
    private static final String BAR = "bar";
    private final class_630 flag;
    private final class_630 pole;
    private final class_630 bar;

    public CompletionistBannerRenderer(class_5614.class_5615 context) {
        class_630 modelPart = context.method_32140(LAYER_LOCATION);
        this.flag = modelPart.method_32086(FLAG);
        this.pole = modelPart.method_32086(POLE);
        this.bar = modelPart.method_32086(BAR);
    }

    /** Model layer, register it together with {@link #LAYER_LOCATION}. */
    public static class_5607 createBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 partDefinition = meshDefinition.method_32111();
        partDefinition.method_32117(FLAG, class_5606.method_32108().method_32101(0, 0).method_32098(-10.0F, 0.0F, -1.0F, 20.0F, 40.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -44.0F, -1.0F, -0.0349F, 0.0F, 0.0F));
        partDefinition.method_32117(POLE, class_5606.method_32108().method_32101(44, 0).method_32097(-1.0f, -30.0f, -1.0f, 2.0f, 42.0f, 2.0f), class_5603.field_27701);
        partDefinition.method_32117(BAR, class_5606.method_32108().method_32101(0, 42).method_32097(-10.0f, -32.0f, -1.0f, 20.0f, 2.0f, 2.0f), class_5603.field_27701);
        return class_5607.method_32110(meshDefinition, 64, 64);
    }

    public static void renderBanner(class_4587 poseStack, class_4597 multiBufferSource, int i, int j, class_630 modelPart, CompletionistBannerEntity banner) {
        class_2960 location = ((CompletionistBannerBlock) banner.method_11010().method_26204()).getRenderTexture();
        class_4588 vc = multiBufferSource.getBuffer(class_1921.method_23578(location));
        modelPart.method_22698(poseStack, vc, i, j);
    }

    @Override
    public void render(CompletionistBannerEntity banner, float f, class_4587 poseStack, class_4597 multiBufferSource, int i, int j) {
        long time;
        float scale = 0.66f;
        boolean inInventory = banner.method_10997() == null;

        poseStack.method_22903();
        if (inInventory) {
            time = 0L;
            poseStack.method_22904(0.5, 0.5, 0.5);
            this.pole.field_3665 = true;
        } else {
            time = banner.method_10997().method_8510();
            class_2680 blockState = banner.method_11010();
            float rotation;
            if (!(blockState.method_26204() instanceof CompletionistWallBannerBlock)) {
                poseStack.method_22904(0.5, 0.5, 0.5);
                rotation = (float) (-blockState.method_11654(CompletionistBannerBlock.ROTATION) * 360) / 16.0f;
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
                this.pole.field_3665 = true;
            } else {
                poseStack.method_22904(0.5, -0.1666666716337204, 0.5);
                rotation = -blockState.method_11654(CompletionistWallBannerBlock.FACING).method_10144() + 180.0f;
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
                poseStack.method_22904(0.0, -0.3125, -0.4375);
                this.pole.field_3665 = false;
            }
        }
        poseStack.method_22903();
        poseStack.method_22905(scale, -scale, -scale);
        class_4588 vertexConsumer = class_1088.field_20847.method_24145(multiBufferSource, class_1921::method_23572);
        this.pole.method_22698(poseStack, vertexConsumer, i, j);
        this.bar.method_22698(poseStack, vertexConsumer, i, j);
        class_2338 blockPos = banner.method_11016();
        float k = ((float) Math.floorMod(blockPos.method_10263() * 7L + blockPos.method_10264() * 9L + blockPos.method_10260() * 13L + time, 100L) + f) / 100.0f;
        this.flag.field_3654 = (-0.0125f + 0.01f * class_3532.method_15362((float) Math.PI * 2 * k)) * (float) Math.PI;
        this.flag.field_3656 = -32.0f;
        renderBanner(poseStack, multiBufferSource, i, j, this.flag, banner);
        poseStack.method_22909();
        poseStack.method_22909();
    }
}