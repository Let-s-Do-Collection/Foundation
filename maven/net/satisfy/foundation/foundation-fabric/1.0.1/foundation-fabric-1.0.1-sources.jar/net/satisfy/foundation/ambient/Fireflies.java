package net.satisfy.foundation.ambient;

import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_5819;
import net.satisfy.foundation.registry.FoundationParticles;

/**
 * Small helper around the firefly particle.
 * Nights only, needs some sky light and no rain.
 */
public final class Fireflies {
    private static final long DAY_LENGTH = 24000L;
    private static final long NIGHT_START = 12500L;
    private static final long NIGHT_END = 23500L;
    private static final int MIN_SKY_LIGHT = 10;

    private Fireflies() {
    }

    /** @return true if fireflies should be around at this pos right now */
    public static boolean isActive(class_1937 level, class_2338 pos) {
        long time = level.method_8532() % DAY_LENGTH;
        return time > NIGHT_START && time < NIGHT_END && level.method_8314(class_1944.field_9284, pos) >= MIN_SKY_LIGHT && !level.method_8419();
    }

    /**
     * Spawns one firefly roughly around the block.
     *
     * @param spread horizontal spread in blocks
     * @param height y offset from the block bottom
     */
    public static void spawn(class_1937 level, class_2338 pos, class_5819 random, double spread, double height) {
        level.method_8406(FoundationParticles.FIREFLY.get(),
                pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * spread * 2,
                pos.method_10264() + height + random.method_43058() * 0.6,
                pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * spread * 2,
                0.0, 0.0, 0.0);
    }
}
