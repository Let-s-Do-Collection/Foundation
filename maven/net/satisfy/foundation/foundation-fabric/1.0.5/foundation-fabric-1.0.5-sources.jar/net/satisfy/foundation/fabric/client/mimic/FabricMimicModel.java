package net.satisfy.foundation.fabric.client.mimic;

import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_7923;
import net.satisfy.foundation.block.mimic.MimicBlockEntity;
import net.satisfy.foundation.client.mimic.MimicModels;
import net.satisfy.foundation.client.mimic.MimicQuads;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

public class FabricMimicModel extends ForwardingBakedModel {
    private static final class_2350[] SIDES = {class_2350.field_11033, class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, null};

    public FabricMimicModel(class_1087 wrapped) {
        this.wrapped = wrapped;
    }

    public static void register() {
        ModelLoadingPlugin.register(context -> context.modifyModelAfterBake().register((model, modelContext) -> {
            class_1091 id = modelContext.topLevelId();
            if (model == null || id == null || class_1091.field_52277.equals(id.comp_2876())) {
                return model;
            }
            return MimicModels.isMimicModel(class_7923.field_41175.method_10223(id.comp_2875())) ? new FabricMimicModel(model) : model;
        }));
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(class_1920 level, class_2680 state, class_2338 pos, Supplier<class_5819> random, RenderContext context) {
        class_2680 mimic = level.method_8321(pos) instanceof MimicBlockEntity entity ? entity.getMimicState() : null;
        MimicModels.QuadRule rule = MimicModels.retextureRule(state.method_26204());
        class_1058 sprite = rule != null && MimicQuads.isApplied(state) ? MimicQuads.sprite(mimic) : null;
        boolean held = MimicModels.isHeld(state.method_26204());
        RenderMaterial material = context.getEmitter().material();
        for (class_2350 side : SIDES) {
            List<class_777> quads = wrapped.method_4707(state, side, random.get());
            emit(context, material, side, sprite != null ? MimicQuads.retexture(quads, state, sprite, rule) : quads);
            if (held) {
                emit(context, material, side, MimicQuads.held(mimic, side, random.get()));
            }
        }
    }

    private static void emit(RenderContext context, RenderMaterial material, @Nullable class_2350 side, List<class_777> quads) {
        for (class_777 quad : quads) {
            QuadEmitter emitter = context.getEmitter();
            emitter.fromVanilla(quad, material, side);
            emitter.emit();
        }
    }
}
