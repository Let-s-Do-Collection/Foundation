package net.satisfy.foundation.overlay;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent;
import dev.architectury.registry.ReloadListenerRegistry;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_4013;
import net.minecraft.class_8824;
import net.satisfy.foundation.Foundation;
import org.jetbrains.annotations.Nullable;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

public final class TutorialLoader implements class_4013 {
    private static final String DIRECTORY = "tutorials";
    private static boolean registered;

    private TutorialLoader() {
    }

    public static void init() {
        if (!registered) {
            registered = true;
            ReloadListenerRegistry.register(class_3264.field_14188, new TutorialLoader(), Foundation.identifier("tutorials"));
            ClientCommandRegistrationEvent.EVENT.register((dispatcher, context) -> dispatcher.register(ClientCommandRegistrationEvent.literal("foundation_tutorials")
                    .then(ClientCommandRegistrationEvent.literal("reset").executes(command -> {
                        Tutorials.reset();
                        command.getSource().arch$sendSuccess(() -> class_2561.method_43471("hud.foundation.tutorial.reset"), false);
                        return 1;
                    }))));
        }
    }

    @Override
    public void method_14491(class_3300 manager) {
        List<Tutorials.Step> steps = new ArrayList<>();
        for (Map.Entry<class_2960, class_3298> entry : manager.method_14488(DIRECTORY, path -> path.method_12832().endsWith(".json")).entrySet()) {
            class_2960 file = entry.getKey();
            String path = file.method_12832().substring(DIRECTORY.length() + 1, file.method_12832().length() - ".json".length());
            class_2960 id = class_2960.method_60655(file.method_12836(), path);
            try (Reader reader = entry.getValue().method_43039()) {
                steps.add(parse(id, JsonParser.parseReader(reader).getAsJsonObject()));
            } catch (Exception exception) {
                Foundation.LOGGER.warn("Could not load tutorial {}: {}", id, exception.getMessage());
            }
        }
        Tutorials.replaceJsonSteps(steps);
    }

    private static Tutorials.Step parse(class_2960 id, JsonObject json) {
        class_2561 title = text(json.get("title"));
        List<class_2561> hints = new ArrayList<>();
        if (json.has("hints")) {
            json.getAsJsonArray("hints").forEach(element -> hints.add(text(element)));
        }
        class_2960 after = json.has("after") ? class_2960.method_60654(json.get("after").getAsString()) : null;
        Predicate<class_310> start = json.has("start") ? startCondition(json.getAsJsonObject("start")) : TutorialConditions.always();
        int goal = 1;
        ToIntFunction<class_310> tracker = null;
        if (json.has("goal")) {
            JsonObject goalJson = json.getAsJsonObject("goal");
            goal = Math.max(1, goalJson.has("count") ? goalJson.get("count").getAsInt() : 1);
            tracker = goalTracker(goalJson, goal);
        }
        class_2561 doneTitle = json.has("done_title") ? text(json.get("done_title")) : null;
        return new Tutorials.Step(id, title, List.copyOf(hints), goal, after, start, tracker, doneTitle, true);
    }

    private static class_2561 text(@Nullable JsonElement element) {
        if (element == null) {
            return class_2561.method_43473();
        }
        return class_8824.field_46597.parse(JsonOps.INSTANCE, element).getOrThrow();
    }

    private static String value(JsonObject json, String key) {
        if (!json.has(key)) {
            throw new IllegalArgumentException("missing \"" + key + "\"");
        }
        return json.get(key).getAsString();
    }

    private static Predicate<class_310> startCondition(JsonObject json) {
        String type = value(json, "type");
        return switch (type) {
            case "always" -> TutorialConditions.always();
            case "looking_at" -> TutorialConditions.lookingAt(TutorialConditions.blockTest(value(json, "block")));
            case "holding" -> TutorialConditions.holding(TutorialConditions.itemTest(value(json, "item")));
            case "in_biome" -> TutorialConditions.biomeTest(value(json, "biome"));
            case "has_item" -> {
                ToIntFunction<class_310> count = TutorialConditions.itemCount(TutorialConditions.itemTest(value(json, "item")));
                int needed = json.has("count") ? json.get("count").getAsInt() : 1;
                yield minecraft -> count.applyAsInt(minecraft) >= needed;
            }
            default -> throw new IllegalArgumentException("unknown start type \"" + type + "\"");
        };
    }

    @Nullable
    private static ToIntFunction<class_310> goalTracker(JsonObject json, int goal) {
        String type = value(json, "type");
        return switch (type) {
            case "manual" -> null;
            case "has_item" -> TutorialConditions.itemCount(TutorialConditions.itemTest(value(json, "item")));
            case "looking_at", "holding", "in_biome" -> {
                Predicate<class_310> test = startCondition(json);
                yield minecraft -> test.test(minecraft) ? goal : 0;
            }
            default -> throw new IllegalArgumentException("unknown goal type \"" + type + "\"");
        };
    }
}
