package net.satisfy.foundation.overlay;

import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class TutorialConditions {
    private TutorialConditions() {
    }

    public static Predicate<class_310> always() {
        return minecraft -> true;
    }

    public static Predicate<class_310> lookingAt(class_2248 block) {
        return lookingAt(state -> state.method_27852(block));
    }

    public static Predicate<class_310> lookingAt(class_6862<class_2248> tag) {
        return lookingAt(state -> state.method_26164(tag));
    }

    public static Predicate<class_310> lookingAt(Predicate<class_2680> test) {
        return minecraft -> minecraft.field_1687 != null && minecraft.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332
                && test.test(minecraft.field_1687.method_8320(hit.method_17777()));
    }

    public static Predicate<class_310> holding(class_1792 item) {
        return holding(stack -> stack.method_31574(item));
    }

    public static Predicate<class_310> holding(class_6862<class_1792> tag) {
        return holding(stack -> stack.method_31573(tag));
    }

    public static Predicate<class_310> holding(Predicate<class_1799> test) {
        return minecraft -> minecraft.field_1724 != null && (test.test(minecraft.field_1724.method_6047()) || test.test(minecraft.field_1724.method_6079()));
    }

    public static Predicate<class_310> inBiome(class_5321<class_1959> biome) {
        return inBiome(holder -> holder.method_40225(biome));
    }

    public static Predicate<class_310> inBiome(class_6862<class_1959> tag) {
        return inBiome(holder -> holder.method_40220(tag));
    }

    private static Predicate<class_310> inBiome(Predicate<class_6880<class_1959>> test) {
        return minecraft -> minecraft.field_1687 != null && minecraft.field_1724 != null && test.test(minecraft.field_1687.method_23753(minecraft.field_1724.method_24515()));
    }

    public static ToIntFunction<class_310> itemCount(class_1792 item) {
        return itemCount(stack -> stack.method_31574(item));
    }

    public static ToIntFunction<class_310> itemCount(class_6862<class_1792> tag) {
        return itemCount(stack -> stack.method_31573(tag));
    }

    public static ToIntFunction<class_310> itemCount(Predicate<class_1799> test) {
        return minecraft -> {
            if (minecraft.field_1724 == null) {
                return 0;
            }
            class_1661 inventory = minecraft.field_1724.method_31548();
            int count = 0;
            for (int i = 0; i < inventory.method_5439(); i++) {
                class_1799 stack = inventory.method_5438(i);
                if (!stack.method_7960() && test.test(stack)) {
                    count += stack.method_7947();
                }
            }
            return count;
        };
    }

    static Predicate<class_1799> itemTest(String value) {
        if (value.startsWith("#")) {
            class_6862<class_1792> tag = class_6862.method_40092(class_7924.field_41197, class_2960.method_60654(value.substring(1)));
            return stack -> stack.method_31573(tag);
        }
        class_2960 id = class_2960.method_60654(value);
        if (!class_7923.field_41178.method_10250(id)) {
            throw new IllegalArgumentException("unknown item \"" + value + "\"");
        }
        class_1792 item = class_7923.field_41178.method_10223(id);
        return stack -> stack.method_31574(item);
    }

    static Predicate<class_2680> blockTest(String value) {
        if (value.startsWith("#")) {
            class_6862<class_2248> tag = class_6862.method_40092(class_7924.field_41254, class_2960.method_60654(value.substring(1)));
            return state -> state.method_26164(tag);
        }
        class_2960 id = class_2960.method_60654(value);
        if (!class_7923.field_41175.method_10250(id)) {
            throw new IllegalArgumentException("unknown block \"" + value + "\"");
        }
        class_2248 block = class_7923.field_41175.method_10223(id);
        return state -> state.method_27852(block);
    }

    static Predicate<class_310> biomeTest(String value) {
        if (value.startsWith("#")) {
            return inBiome(class_6862.method_40092(class_7924.field_41236, class_2960.method_60654(value.substring(1))));
        }
        return inBiome(class_5321.method_29179(class_7924.field_41236, class_2960.method_60654(value)));
    }
}
