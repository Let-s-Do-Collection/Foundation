package net.satisfy.foundation.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.NotNull;

/** Fly buzzing in a wobbly circle around its spawn point. Positive x speed = base lifetime in ticks, otherwise 60. */
public class FlyParticle extends class_4003 {
    private static final int DEFAULT_LIFETIME = 60;

    private final double centerX;
    private final double centerY;
    private final double centerZ;
    private final float radius;
    private final float speed;
    private final float phase;

    protected FlyParticle(class_638 level, double x, double y, double z, int baseLifetime, class_4002 sprites) {
        super(level, x, y, z);
        this.centerX = x;
        this.centerY = y;
        this.centerZ = z;
        this.field_3847 = baseLifetime + this.field_3840.method_43048(60);
        this.field_3844 = 0.0F;
        this.field_3862 = false;
        this.field_17867 = 0.035F + this.field_3840.method_43057() * 0.015F;
        this.radius = 0.15F + this.field_3840.method_43057() * 0.2F;
        this.speed = (0.25F + this.field_3840.method_43057() * 0.2F) * (this.field_3840.method_43056() ? 1.0F : -1.0F);
        this.phase = this.field_3840.method_43057() * class_3532.field_29846;
        this.method_18140(sprites);
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        float angle = this.phase + this.field_3866 * this.speed;
        double jitter = (this.field_3840.method_43058() - 0.5) * 0.05;
        this.method_3063(
                this.centerX + class_3532.method_15362(angle) * this.radius + jitter,
                this.centerY + class_3532.method_15374(this.field_3866 * 0.21F + this.phase) * 0.12 + jitter,
                this.centerZ + class_3532.method_15374(angle) * this.radius + jitter);
        this.field_3841 = Math.min(1.0F, Math.min(this.field_3866, this.field_3847 - this.field_3866) / 8.0F);
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17829;
    }

    public record Provider(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            int baseLifetime = xSpeed > 0 ? (int) xSpeed : DEFAULT_LIFETIME;
            return new FlyParticle(level, x, y, z, baseLifetime, this.sprites);
        }
    }
}
