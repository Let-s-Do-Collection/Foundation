package net.satisfy.foundation.registry;

import com.mojang.serialization.MapCodec;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9381;
import net.satisfy.foundation.Foundation;
import org.jetbrains.annotations.NotNull;

/** All particle types the lib ships. {@code DYE_SPLASH}, {@code COLORED_DRIP}, {@code FEATHER} and the {@code COLORED_SOUP_*} bubbles take a color. */
public final class FoundationParticles {
    public static final DeferredRegister<class_2396<?>> PARTICLE_TYPES = DeferredRegister.create(Foundation.MOD_ID, class_7924.field_41210);

    public static final RegistrySupplier<class_2400> SOUP_BUBBLE = PARTICLE_TYPES.register("soup_bubble", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2400> SOUP_STEAM = PARTICLE_TYPES.register("soup_steam", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2400> SOUP_COOKING_BUBBLE = PARTICLE_TYPES.register("soup_cooking_bubble", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2396<class_9381>> COLORED_SOUP_BUBBLE = PARTICLE_TYPES.register("colored_soup_bubble", FoundationParticles::colored);
    public static final RegistrySupplier<class_2396<class_9381>> COLORED_SOUP_COOKING_BUBBLE = PARTICLE_TYPES.register("colored_soup_cooking_bubble", FoundationParticles::colored);
    public static final RegistrySupplier<class_2396<class_9381>> COLORED_STEAM = PARTICLE_TYPES.register("colored_steam", FoundationParticles::colored);
    public static final RegistrySupplier<class_2396<class_9381>> DYE_SPLASH = PARTICLE_TYPES.register("dye_splash", FoundationParticles::colored);
    public static final RegistrySupplier<class_2396<class_9381>> FEATHER = PARTICLE_TYPES.register("feather", FoundationParticles::colored);
    public static final RegistrySupplier<class_2396<class_9381>> COLORED_DRIP = PARTICLE_TYPES.register("colored_drip", FoundationParticles::colored);
    public static final RegistrySupplier<class_2400> WATER_DRIP = PARTICLE_TYPES.register("water_drip", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2400> WATER_SPLASH = PARTICLE_TYPES.register("water_splash", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2400> FIREFLY = PARTICLE_TYPES.register("firefly", () -> new class_2400(false) {});
    /** Buzzing fly circling its spawn point. A positive x speed sets the base lifetime in ticks. */
    public static final RegistrySupplier<class_2400> FLY = PARTICLE_TYPES.register("fly", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2400> LEAF = PARTICLE_TYPES.register("leaf", () -> new class_2400(false) {});
    public static final RegistrySupplier<class_2400> NEEDLE = PARTICLE_TYPES.register("needle", () -> new class_2400(false) {});

    private static class_2396<class_9381> colored() {
        return new class_2396<>(false) {
            @Override
            public @NotNull MapCodec<class_9381> method_29138() {
                return class_9381.method_58254(this);
            }

            @Override
            public @NotNull class_9139<? super class_9129, class_9381> method_56179() {
                return class_9381.method_58261(this);
            }
        };
    }

    private FoundationParticles() {
    }

    public static void init() {
        PARTICLE_TYPES.register();
    }
}
