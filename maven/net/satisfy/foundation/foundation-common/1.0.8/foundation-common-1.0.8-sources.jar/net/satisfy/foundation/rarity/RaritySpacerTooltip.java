package net.satisfy.foundation.rarity;

import net.minecraft.class_327;
import net.minecraft.class_5684;

public final class RaritySpacerTooltip implements class_5684 {
    private static final int HEIGHT = 6;

    @Override
    public int method_32661() {
        return HEIGHT;
    }

    @Override
    public int method_32664(class_327 font) {
        return 0;
    }
}
