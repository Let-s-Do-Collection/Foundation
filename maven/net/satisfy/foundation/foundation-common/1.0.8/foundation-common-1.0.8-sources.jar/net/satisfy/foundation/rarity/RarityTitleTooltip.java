package net.satisfy.foundation.rarity;

import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5684;
import org.joml.Matrix4f;

public final class RarityTitleTooltip implements class_5684 {
    private static final int HEIGHT = 20;
    private static final int ICON_SIZE = 16;
    private static final int GAP = 4;
    private static final int ICON_Y = 1;
    private static final int TEXT_Y = 5;
    private final class_1799 stack;
    private final class_5684 title;

    public RarityTitleTooltip(class_1799 stack, class_5684 title) {
        this.stack = stack;
        this.title = title;
    }

    @Override
    public int method_32661() {
        return HEIGHT;
    }

    @Override
    public int method_32664(class_327 font) {
        return ICON_SIZE + GAP + this.title.method_32664(font);
    }

    @Override
    public void method_32665(class_327 font, int x, int y, Matrix4f matrix, class_4597.class_4598 bufferSource) {
        this.title.method_32665(font, x + ICON_SIZE + GAP, y + TEXT_Y, matrix, bufferSource);
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 graphics) {
        graphics.method_51427(this.stack, x, y + ICON_Y);
    }
}
