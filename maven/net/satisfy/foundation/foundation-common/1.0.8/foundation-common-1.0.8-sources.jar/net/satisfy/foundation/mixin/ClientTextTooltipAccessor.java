package net.satisfy.foundation.mixin;

import net.minecraft.class_5481;
import net.minecraft.class_5683;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5683.class)
public interface ClientTextTooltipAccessor {
    @Accessor("text")
    class_5481 foundation$getText();
}
