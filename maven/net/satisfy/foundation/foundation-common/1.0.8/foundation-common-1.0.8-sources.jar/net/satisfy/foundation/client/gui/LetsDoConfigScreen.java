package net.satisfy.foundation.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.architectury.platform.Mod;
import dev.architectury.platform.Platform;
import net.minecraft.class_1011;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_332;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8662;
import net.satisfy.foundation.Foundation;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class LetsDoConfigScreen extends class_437 {
    private static final int BUTTON_SIZE = 20;
    private static final int ICON_SIZE = 16;
    private static final int ICON_GAP = 4;
    private static final int WIDE_BUTTON_WIDTH = 200;
    private static final int LOGO_BOX_WIDTH = 220;
    private static final int LOGO_BOX_HEIGHT = 80;
    private static final int GAP = 12;

    private static final List<Link> LINKS = List.of(
            new Link("website", "https://www.lets-do.ch"),
            new Link("github", "https://github.com/Let-s-Do-Collection"),
            new Link("discord", "https://discord.com/invite/Vqu6wYZwdZ"),
            new Link("kofi", "https://ko-fi.com/letsdo"),
            new Link("patreon", "https://www.patreon.com/cw/u78595058")
    );

    private final @Nullable class_437 parent;
    private final Function<class_437, class_437> configScreen;
    private final class_2561 version;
    private final class_2960 logo;
    private int logoTextureWidth;
    private int logoTextureHeight;
    private int logoX;
    private int logoY;
    private int logoWidth;
    private int logoHeight;
    private int versionY;

    public LetsDoConfigScreen(@Nullable class_437 parent, String modId, Function<class_437, class_437> configScreen) {
        super(class_2561.method_43470(Platform.getOptionalMod(modId).map(Mod::getName).orElse(modId)));
        this.parent = parent;
        this.configScreen = configScreen;
        this.version = class_2561.method_43470(Platform.getOptionalMod(modId).map(mod -> "v" + mod.getVersion()).orElse(""))
                .method_27692(class_124.field_1080);
        this.logo = class_2960.method_60655(modId, "textures/gui/logo.png");
        readLogoSize();
    }

    private void readLogoSize() {
        Optional<class_3298> resource = class_310.method_1551().method_1478().method_14486(logo);
        if (resource.isEmpty()) {
            return;
        }
        try (InputStream stream = resource.get().method_14482(); class_1011 image = class_1011.method_4309(stream)) {
            logoTextureWidth = image.method_4307();
            logoTextureHeight = image.method_4323();
        } catch (IOException e) {
            Foundation.LOGGER.warn("Could not read logo {}", logo, e);
        }
    }

    private boolean hasLogo() {
        return logoTextureWidth > 0 && logoTextureHeight > 0;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;

        int restHeight = GAP + BUTTON_SIZE + GAP + BUTTON_SIZE + GAP + field_22793.field_2000 + GAP + BUTTON_SIZE;
        int boxWidth = Math.min(LOGO_BOX_WIDTH, field_22789 - 40);
        int boxHeight = Math.max(field_22793.field_2000, Math.min(LOGO_BOX_HEIGHT, field_22790 - 20 - restHeight));
        if (hasLogo()) {
            float scale = Math.min((float) boxWidth / logoTextureWidth, (float) boxHeight / logoTextureHeight);
            logoWidth = Math.round(logoTextureWidth * scale);
            logoHeight = Math.round(logoTextureHeight * scale);
        } else {
            logoWidth = boxWidth;
            logoHeight = field_22793.field_2000;
        }

        int y = Math.max(10, (field_22790 - boxHeight - restHeight) / 2);
        logoX = centerX - logoWidth / 2;
        logoY = y + (boxHeight - logoHeight) / 2;
        y += boxHeight + GAP;

        method_37063(class_4185.method_46430(class_2561.method_43471("gui.foundation.config.configure"), button -> field_22787.method_1507(configScreen.apply(this)))
                .method_46434(centerX - WIDE_BUTTON_WIDTH / 2, y, WIDE_BUTTON_WIDTH, BUTTON_SIZE)
                .method_46431());
        y += BUTTON_SIZE + GAP;

        int rowWidth = LINKS.size() * BUTTON_SIZE + (LINKS.size() - 1) * ICON_GAP;
        int x = centerX - rowWidth / 2;
        for (Link link : LINKS) {
            class_2561 label = class_2561.method_43471("gui.foundation.config.link." + link.id());
            class_8662 button = class_8662.method_52723(label, b -> class_407.method_49623(this, link.url()), true)
                    .method_52727(class_2960.method_60655(Foundation.MOD_ID, "links/" + link.id()), ICON_SIZE, ICON_SIZE)
                    .method_52726(BUTTON_SIZE, BUTTON_SIZE)
                    .method_52724();
            button.method_46421(x);
            button.method_46419(y);
            button.method_47400(class_7919.method_47407(label));
            method_37063(button);
            x += BUTTON_SIZE + ICON_GAP;
        }
        y += BUTTON_SIZE + GAP;

        versionY = y;
        y += field_22793.field_2000 + GAP;

        method_37063(class_4185.method_46430(class_5244.field_24334, button -> method_25419())
                .method_46434(centerX - WIDE_BUTTON_WIDTH / 2, y, WIDE_BUTTON_WIDTH, BUTTON_SIZE)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        if (hasLogo()) {
            RenderSystem.enableBlend();
            graphics.method_25293(logo, logoX, logoY, logoWidth, logoHeight, 0, 0, logoTextureWidth, logoTextureHeight, logoTextureWidth, logoTextureHeight);
            RenderSystem.disableBlend();
        } else {
            graphics.method_27534(field_22793, field_22785, field_22789 / 2, logoY, 0xFFFFFF);
        }
        graphics.method_27534(field_22793, version, field_22789 / 2, versionY, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    private record Link(String id, String url) {
    }
}
