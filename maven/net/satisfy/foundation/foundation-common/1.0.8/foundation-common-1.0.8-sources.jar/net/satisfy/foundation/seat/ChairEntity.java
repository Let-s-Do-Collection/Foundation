package net.satisfy.foundation.seat;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2769;
import net.minecraft.class_2945;
import net.minecraft.class_3231;

/**
 * Invisible entity the player rides while sitting. Gets discarded on dismount
 * and puts the player back where they came from.
 */
public class ChairEntity extends class_1297 {
    private class_2338 seatPos;
    private boolean seatPosInit;

    public ChairEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {

    }

    public void setSeatPos(class_2338 pos) {
        this.seatPos = pos.method_10062();
        this.seatPosInit = true;
    }

    public class_243 method_24829(class_1309 passenger) {
        if (passenger instanceof class_1657 p) {
            class_2338 pos = SeatUtil.getPreviousPlayerPosition(p, this);
            if (pos != null) {
                this.method_31472();
                return new class_243((double)pos.method_10263() + 0.5, (double)pos.method_10264(), (double)pos.method_10260() + 0.5);
            }
        }

        this.method_31472();
        return super.method_24829(passenger);
    }

    public void method_5650(class_5529 reason) {
        super.method_5650(reason);
        SeatUtil.removeChairEntity(this.method_37908(), this.seatPos != null ? this.seatPos : this.method_24515());
    }

    protected void method_5749(class_2487 nbt) {
        if (nbt.method_10545("spx")) {
            this.seatPos = new class_2338(nbt.method_10550("spx"), nbt.method_10550("spy"), nbt.method_10550("spz"));
            this.seatPosInit = true;
        }
    }

    protected void method_5652(class_2487 nbt) {
        class_2338 p = this.seatPos != null ? this.seatPos : this.method_24515();
        nbt.method_10569("spx", p.method_10263());
        nbt.method_10569("spy", p.method_10264());
        nbt.method_10569("spz", p.method_10260());
    }

    @Override
    protected void method_5865(class_1297 passenger, class_4738 move) {
        move.accept(passenger, method_23317(), method_23318(), method_23321());
    }

    @Override
    public boolean method_5787() {
        return false;
    }

    private float computeYawFromBlock() {
        class_2338 p = this.seatPos != null ? this.seatPos : this.method_24515();
        class_2680 s = method_37908().method_8320(p);
        float yaw = method_36454();
        if (s.method_28498(class_2741.field_12481)) {
            yaw = s.method_11654(class_2741.field_12481).method_10144();
        } else if (s.method_28498(class_2741.field_12525)) {
            yaw = s.method_11654(class_2741.field_12525).method_10144();
        } else {
            for (class_2769<?> prop : s.method_28501()) {
                if (prop.method_11899().equals("facing") && prop instanceof class_2753 dir) {
                    yaw = s.method_11654(dir).method_10144();
                    break;
                }
            }
        }
        if (s.method_28498(class_2741.field_12483) && s.method_11654(class_2741.field_12483).toString().equals("head")) {
            yaw += 180.0F;
        } else {
            for (class_2769<?> prop : s.method_28501()) {
                if (prop.method_11899().equals("part")) {
                    if (s.method_11654(prop).toString().equals("head")) {
                        yaw += 180.0F;
                        break;
                    }
                }
            }
        }
        return yaw;
    }

    @Override
    public void method_5644(class_1297 passenger) {
        if (passenger instanceof class_1309 l) {
            float yaw = method_36454();
            l.method_5636(yaw);
            l.field_6220 = yaw;
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!seatPosInit) {
            this.seatPos = this.method_24515();
            this.seatPosInit = true;
        }
        float target = computeYawFromBlock();
        if (method_36454() != target) {
            method_36456(target);
            field_5982 = target;
        }
        for (class_1297 e : method_5685()) {
            if (e instanceof class_1657 p) {
                if (!method_37908().field_9236) p.method_18799(class_243.field_1353);
                float yaw = method_36454();
                p.method_5636(yaw);
                p.field_6220 = yaw;
            }
        }
    }

    @Override
    public class_2596<class_2602> method_18002(class_3231 server) {
        return new class_2604(this, server);
    }
}