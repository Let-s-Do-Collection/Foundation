package net.satisfy.foundation.rarity;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1047;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5683;
import net.minecraft.class_5684;
import net.satisfy.foundation.mixin.ClientTextTooltipAccessor;
import net.satisfy.foundation.platform.PlatformHelper;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2i;

import java.util.ArrayList;
import java.util.List;

public final class RarityTooltipFrame {
    private static final long TIMEOUT = 100L;
    private static final int PADDING = 12;
    @Nullable
    private static FoundationRarity rarity;
    private static class_1799 stack = class_1799.field_8037;
    private static long markedAt;

    private RarityTooltipFrame() {
    }

    public static void mark(@Nullable FoundationRarity next, class_1799 hovered) {
        rarity = next;
        stack = hovered;
        markedAt = System.currentTimeMillis();
    }

    public static List<class_5684> decorate(List<class_5684> components) {
        if (rarity == null || components.isEmpty() || stack.method_7960() || !(components.getFirst() instanceof class_5683) || sprite() == null) {
            return components;
        }
        class_327 font = class_310.method_1551().field_1772;
        String footer = text(components.getLast());
        List<class_5684> lines = new ArrayList<>();
        lines.add(new RarityTitleTooltip(stack, components.getFirst()));
        for (int i = 1; i < components.size(); i++) {
            class_5684 component = components.get(i);
            if (i < components.size() - 1 && !footer.isEmpty() && footer.equals(text(component))) {
                continue;
            }
            if (component instanceof class_5683 && component.method_32664(font) == 0) {
                if (lines.size() > 1 && !(lines.getLast() instanceof RaritySpacerTooltip)) {
                    lines.add(new RaritySpacerTooltip());
                }
                continue;
            }
            lines.add(component);
        }
        if (lines.getLast() instanceof RaritySpacerTooltip) {
            lines.removeLast();
        }
        return lines;
    }

    private static String text(class_5684 component) {
        if (!(component instanceof ClientTextTooltipAccessor accessor)) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        accessor.foundation$getText().accept((index, style, codePoint) -> {
            builder.appendCodePoint(codePoint);
            return true;
        });
        return builder.toString().strip();
    }

    public static void keepOnScreen(int screenWidth, int screenHeight, Vector2i pos, int width, int height) {
        if (sprite() == null) {
            return;
        }
        if (pos.x + width + PADDING > screenWidth) {
            pos.x = Math.max(screenWidth - width - PADDING, PADDING);
        }
        if (pos.y + height + PADDING > screenHeight) {
            pos.y = screenHeight - height - PADDING;
        }
        pos.x = Math.max(pos.x, PADDING);
        pos.y = Math.max(pos.y, PADDING);
    }

    public static boolean render(class_332 graphics, int x, int y, int width, int height, int z) {
        class_2960 location = sprite();
        rarity = null;
        if (location == null) {
            return false;
        }
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0.0F, 0.0F, z);
        RenderSystem.enableBlend();
        graphics.method_52706(location, x - PADDING, y - PADDING, width + PADDING * 2, height + PADDING * 2);
        RenderSystem.disableBlend();
        graphics.method_51448().method_22909();
        return true;
    }

    @Nullable
    private static class_2960 sprite() {
        FoundationRarity current = rarity;
        if (current == null || System.currentTimeMillis() - markedAt >= TIMEOUT || !PlatformHelper.enableImprovedTooltips()) {
            return null;
        }
        class_2960 location = current.tooltipSprite();
        if (class_310.method_1551().method_52699().method_18667(location).method_45851().method_45816().equals(class_1047.method_4539())) {
            return null;
        }
        return location;
    }
}
