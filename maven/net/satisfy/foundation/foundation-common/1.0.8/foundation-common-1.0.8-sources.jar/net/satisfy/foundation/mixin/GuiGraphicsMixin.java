package net.satisfy.foundation.mixin;

import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.satisfy.foundation.rarity.RarityTooltipFrame;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;

@Mixin(class_332.class)
public abstract class GuiGraphicsMixin {
    @ModifyVariable(method = "renderTooltipInternal", at = @At("HEAD"), argsOnly = true, require = 0)
    private List<class_5684> foundation$rarityTooltipLayout(List<class_5684> components) {
        return RarityTooltipFrame.decorate(components);
    }
}
