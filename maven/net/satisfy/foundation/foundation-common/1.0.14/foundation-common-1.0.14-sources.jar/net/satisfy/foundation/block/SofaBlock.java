package net.satisfy.foundation.block;

import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.satisfy.foundation.seat.SeatUtil;
import org.jetbrains.annotations.NotNull;

public class SofaBlock extends LineConnectingBlock {
    private final double seatHeight;

    public SofaBlock(class_2251 properties) {
        this(properties, 0.2);
    }

    public SofaBlock(class_2251 properties, double seatHeight) {
        super(properties);
        this.seatHeight = seatHeight;
    }

    protected class_265 getSofaShape(LineConnectingType type, class_2350 facing) {
        return class_259.method_1077();
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return getSofaShape(state.method_11654(TYPE), state.method_11654(FACING));
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        return SeatUtil.onUse(level, player, hand, hit, seatHeight);
    }

    @Override
    public void method_9554(class_1937 level, class_2680 state, class_2338 pos, class_1297 entity, float fallDistance) {
        super.method_9554(level, state, pos, entity, fallDistance * 0.5F);
    }

    @Override
    public void method_9502(class_1922 level, class_1297 entity) {
        if (entity.method_21750()) {
            super.method_9502(level, entity);
            return;
        }
        class_243 motion = entity.method_18798();
        if (motion.field_1351 < 0.0) {
            double bounceFactor = entity instanceof class_1309 ? 1.0 : 0.8;
            entity.method_18800(motion.field_1352, -motion.field_1351 * 0.66 * bounceFactor, motion.field_1350);
        }
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        SeatUtil.onStateReplaced(level, pos);
        super.method_9536(state, level, pos, newState, moved);
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 type) {
        return false;
    }
}
