package net.satisfy.foundation.client.render;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.class_1058;
import net.minecraft.class_1163;
import net.minecraft.class_1723;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import net.minecraft.class_827;
import net.satisfy.foundation.Foundation;
import net.satisfy.foundation.block.SinkBlock;
import net.satisfy.foundation.block.SinkBlockEntity;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public class SinkRenderer implements class_827<SinkBlockEntity> {
    private static final class_2960 DEFAULT_FAUCET = Foundation.identifier("models/block/sink_faucet.json");
    private static final class_2960 WATER_TEXTURE = class_2960.method_60656("block/water_still");
    private static final float PIXEL = 1.0F / 16.0F;
    private static final float HANDLE_TURN = 135.0F;
    private static final float KNOB_TURN = 90.0F;
    private static final int WATER_GRID = 5;
    private static final float SLOSH_AMPLITUDE = 0.006F;
    private static final float RIPPLE_AMPLITUDE = 0.006F;
    private static final Map<class_2248, List<Element>> FAUCETS = new HashMap<>();

    public SinkRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(SinkBlockEntity sink, float partialTick, class_4587 poseStack, class_4597 buffers, int light, int overlay) {
        class_1937 level = sink.method_10997();
        if (level == null || !(sink.method_11010().method_26204() instanceof SinkBlock block)) {
            return;
        }
        class_2350 facing = sink.method_11010().method_11654(SinkBlock.FACING);
        float yaw = switch (facing) {
            case field_11034 -> 90.0F;
            case field_11035 -> 180.0F;
            case field_11039 -> 270.0F;
            default -> 0.0F;
        };
        poseStack.method_22903();
        poseStack.method_46416(0.5F, 0.0F, 0.5F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
        poseStack.method_46416(-0.5F, 0.0F, -0.5F);

        int upperLight = class_761.method_23794(level, sink.method_11016().method_10084());
        drawWater(poseStack, buffers, level, sink, block.layout(), partialTick, upperLight);

        float turn = class_3532.method_15363((level.method_8510() + partialTick - sink.getToggleTime()) / SinkBlockEntity.TURN_TICKS, 0.0F, 1.0F);
        float eased = 1.0F - (1.0F - turn) * (1.0F - turn);
        float progress = sink.isOpen() ? eased : 1.0F - eased;
        poseStack.method_46416(0.0F, 1.0F, 0.0F);
        drawFaucet(poseStack, buffers, faucet(block), progress, upperLight);
        poseStack.method_22909();
    }

    @Override
    public boolean shouldRenderOffScreen(SinkBlockEntity sink) {
        return true;
    }

    private static void drawWater(class_4587 poseStack, class_4597 buffers, class_1937 level, SinkBlockEntity sink, SinkBlock.Layout layout, float partialTick, int light) {
        float waterLevel = sink.getDisplayLevel(partialTick);
        if (waterLevel <= 0.01F) {
            return;
        }
        class_1058 sprite = class_310.method_1551().method_1549(class_1723.field_21668).apply(WATER_TEXTURE);
        int color = class_1163.method_4961(level, sink.method_11016());
        float r = (color >> 16 & 255) / 255.0F, g = (color >> 8 & 255) / 255.0F, b = (color & 255) / 255.0F;
        float y = layout.surfaceHeight(waterLevel);
        float x0 = layout.basinX0() * PIXEL, x1 = layout.basinX1() * PIXEL, z0 = layout.basinZ0() * PIXEL, z1 = layout.basinZ1() * PIXEL;
        float spoutX = layout.spoutX() * PIXEL, spoutZ = layout.spoutZ() * PIXEL;
        float time = level.method_8510() + partialTick;
        float slosh = sink.getSlosh(partialTick);
        boolean ripple = sink.isOpen() && sink.getWaterLevel() < SinkBlockEntity.MAX_LEVEL;
        class_4588 consumer = buffers.getBuffer(class_1921.method_23583());
        class_4587.class_4665 pose = poseStack.method_23760();
        for (int iz = 0; iz < WATER_GRID; iz++) {
            float za = class_3532.method_16439(iz / (float) WATER_GRID, z0, z1);
            float zb = class_3532.method_16439((iz + 1) / (float) WATER_GRID, z0, z1);
            for (int ix = 0; ix < WATER_GRID; ix++) {
                float xa = class_3532.method_16439(ix / (float) WATER_GRID, x0, x1);
                float xb = class_3532.method_16439((ix + 1) / (float) WATER_GRID, x0, x1);
                float[][] corners = {{xa, za}, {xa, zb}, {xb, zb}, {xb, za}};
                for (float[] corner : corners) {
                    float height = y + wave(corner[0], corner[1], time, slosh, ripple, spoutX, spoutZ);
                    consumer.method_56824(pose, corner[0], height, corner[1])
                            .method_22915(r, g, b, 0.85F)
                            .method_22913(sprite.method_4580(corner[0]), sprite.method_4570(corner[1]))
                            .method_60803(light)
                            .method_60831(pose, 0.0F, 1.0F, 0.0F);
                }
            }
        }
    }

    private static float wave(float x, float z, float time, float slosh, boolean ripple, float spoutX, float spoutZ) {
        float height = 0.0F;
        if (slosh > 0.001F) {
            height += SLOSH_AMPLITUDE * slosh * (0.6F * class_3532.method_15374(time * 0.45F + z * 14.0F + x * 4.0F) + 0.4F * class_3532.method_15374(time * 0.6F - x * 15.0F + z * 5.0F));
        }
        if (ripple) {
            float dx = x - spoutX, dz = z - spoutZ;
            float dist = class_3532.method_15355(dx * dx + dz * dz);
            height += RIPPLE_AMPLITUDE * class_3532.method_15374(dist * 40.0F - time) * (float) Math.exp(-dist * 6.0F);
        }
        return height;
    }

    private static void drawFaucet(class_4587 poseStack, class_4597 buffers, List<Element> faucet, float progress, int light) {
        Function<class_2960, class_1058> atlas = class_310.method_1551().method_1549(class_1723.field_21668);
        class_4588 consumer = buffers.getBuffer(class_1921.method_23581());
        for (Element element : faucet) {
            poseStack.method_22903();
            float cx = (element.from[0] + element.to[0]) / 2.0F * PIXEL;
            float cy = (element.from[1] + element.to[1]) / 2.0F * PIXEL;
            float cz = (element.from[2] + element.to[2]) / 2.0F * PIXEL;
            switch (element.motion) {
                case HANDLE -> {
                    poseStack.method_46416(0.0F, cy, cz);
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(progress * HANDLE_TURN));
                    poseStack.method_46416(0.0F, -cy, -cz);
                }
                case KNOB, KNOB_REVERSE -> {
                    float angle = progress * KNOB_TURN * (element.motion == Motion.KNOB ? 1.0F : -1.0F);
                    poseStack.method_46416(cx, 0.0F, cz);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));
                    poseStack.method_46416(-cx, 0.0F, -cz);
                }
                default -> {
                }
            }
            element.draw(poseStack.method_23760(), consumer, atlas, light);
            poseStack.method_22909();
        }
    }

    private static List<Element> faucet(class_2248 block) {
        return FAUCETS.computeIfAbsent(block, SinkRenderer::loadFaucet);
    }

    private static List<Element> loadFaucet(class_2248 block) {
        class_2960 id = class_7923.field_41175.method_10221(block);
        class_2960 own = class_2960.method_60655(id.method_12836(), "models/block/" + id.method_12832() + "_faucet.json");
        List<Element> elements = read(own);
        return elements.isEmpty() ? read(DEFAULT_FAUCET) : elements;
    }

    private static List<Element> read(class_2960 location) {
        List<Element> elements = new ArrayList<>();
        Optional<net.minecraft.class_3298> resource = class_310.method_1551().method_1478().method_14486(location);
        if (resource.isEmpty()) {
            return elements;
        }
        try (Reader reader = resource.get().method_43039()) {
            JsonObject model = JsonParser.parseReader(reader).getAsJsonObject();
            Map<String, String> textures = new HashMap<>();
            if (model.has("textures")) {
                for (Map.Entry<String, JsonElement> entry : model.getAsJsonObject("textures").entrySet()) {
                    textures.put(entry.getKey(), entry.getValue().getAsString());
                }
            }
            for (JsonElement entry : model.getAsJsonArray("elements")) {
                elements.add(Element.parse(entry.getAsJsonObject(), textures));
            }
        } catch (Exception exception) {
            Foundation.LOGGER.warn("Could not read sink faucet model {}", location, exception);
        }
        return elements;
    }

    private static class_2960 resolve(String reference, Map<String, String> textures) {
        String value = reference;
        for (int depth = 0; depth < 8 && value.startsWith("#"); depth++) {
            value = textures.getOrDefault(value.substring(1), "minecraft:missingno");
        }
        return class_2960.method_60654(value);
    }

    private enum Motion {
        NONE, HANDLE, KNOB, KNOB_REVERSE;

        static Motion of(JsonObject json) {
            if (!json.has("name")) {
                return NONE;
            }
            return switch (json.get("name").getAsString()) {
                case "handle" -> HANDLE;
                case "knob" -> KNOB;
                case "knob_reverse" -> KNOB_REVERSE;
                default -> NONE;
            };
        }
    }

    private record Face(class_2350 direction, float[] uv, int rotation, class_2960 texture) {
    }

    private record Element(float[] from, float[] to, Motion motion, List<Face> faces) {
        static Element parse(JsonObject json, Map<String, String> textures) {
            List<Face> faces = new ArrayList<>();
            String fallback = textures.containsKey("faucet") ? "#faucet" : textures.keySet().stream().filter(key -> !key.equals("particle")).findFirst().map(key -> "#" + key).orElse("#particle");
            for (Map.Entry<String, JsonElement> entry : json.getAsJsonObject("faces").entrySet()) {
                JsonObject face = entry.getValue().getAsJsonObject();
                class_2350 direction = class_2350.method_10168(entry.getKey());
                if (direction != null) {
                    String reference = face.has("texture") ? face.get("texture").getAsString() : fallback;
                    faces.add(new Face(direction, floats(face.getAsJsonArray("uv")), face.has("rotation") ? face.get("rotation").getAsInt() : 0, resolve(reference, textures)));
                }
            }
            return new Element(floats(json.getAsJsonArray("from")), floats(json.getAsJsonArray("to")), Motion.of(json), faces);
        }

        private static float[] floats(JsonArray array) {
            float[] values = new float[array.size()];
            for (int index = 0; index < values.length; index++) {
                values[index] = array.get(index).getAsFloat();
            }
            return values;
        }

        void draw(class_4587.class_4665 pose, class_4588 consumer, Function<class_2960, class_1058> atlas, int light) {
            float x0 = from[0] * PIXEL, y0 = from[1] * PIXEL, z0 = from[2] * PIXEL;
            float x1 = to[0] * PIXEL, y1 = to[1] * PIXEL, z1 = to[2] * PIXEL;
            for (Face face : faces) {
                class_1058 sprite = atlas.apply(face.texture);
                float[][] points = switch (face.direction) {
                    case field_11036 -> new float[][]{{x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, {x1, y1, z0}};
                    case field_11033 -> new float[][]{{x0, y0, z1}, {x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}};
                    case field_11043 -> new float[][]{{x1, y1, z0}, {x1, y0, z0}, {x0, y0, z0}, {x0, y1, z0}};
                    case field_11035 -> new float[][]{{x0, y1, z1}, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}};
                    case field_11039 -> new float[][]{{x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}};
                    case field_11034 -> new float[][]{{x1, y1, z1}, {x1, y0, z1}, {x1, y0, z0}, {x1, y1, z0}};
                };
                float u0 = face.uv[0], v0 = face.uv[1], u1 = face.uv[2], v1 = face.uv[3];
                float[][] uvs = {{u0, v0}, {u0, v1}, {u1, v1}, {u1, v0}};
                int shift = (face.rotation / 90) % 4;
                float shade = switch (face.direction) {
                    case field_11036 -> 1.0F;
                    case field_11033 -> 0.5F;
                    case field_11043, field_11035 -> 0.8F;
                    default -> 0.6F;
                };
                for (int corner = 0; corner < 4; corner++) {
                    float[] uv = uvs[(corner + shift) % 4];
                    consumer.method_56824(pose, points[corner][0], points[corner][1], points[corner][2])
                            .method_22915(shade, shade, shade, 1.0F)
                            .method_22913(sprite.method_4580(uv[0] / 16.0F), sprite.method_4570(uv[1] / 16.0F))
                            .method_60803(light)
                            .method_60831(pose, face.direction.method_10148(), face.direction.method_10164(), face.direction.method_10165());
                }
            }
        }
    }
}
