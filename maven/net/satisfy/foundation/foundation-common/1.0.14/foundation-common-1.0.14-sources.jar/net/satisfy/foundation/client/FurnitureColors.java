package net.satisfy.foundation.client;

import dev.architectury.registry.client.rendering.ColorHandlerRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_7923;
import net.satisfy.foundation.block.DyeableSofaBlock;

import java.util.ArrayList;
import java.util.List;

public final class FurnitureColors {
    private FurnitureColors() {
    }

    public static void init() {
        List<class_2248> sofas = new ArrayList<>();
        for (class_2248 block : class_7923.field_41175) {
            if (block instanceof DyeableSofaBlock) sofas.add(block);
        }
        if (!sofas.isEmpty()) {
            ColorHandlerRegistry.registerBlockColors((state, level, pos, tintIndex) -> state.method_11654(DyeableSofaBlock.COLOR).tint(), sofas.toArray(new class_2248[0]));
        }
    }
}
