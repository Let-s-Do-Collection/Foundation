package net.satisfy.foundation.food;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

/** Effect food that can also be placed as block when sneaking. */
@SuppressWarnings("unused")
public class PlaceableEffectFoodItem extends class_1747 {
    public PlaceableEffectFoodItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        EffectTooltips.append(itemStack, tooltipContext, tooltip);
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 user) {
        return user.method_60492(level, stack);
    }

    @Override
    public @NotNull class_1269 method_7712(class_1750 context) {
        class_1657 player = context.method_8036();
        if (player != null && player.method_5715()) {
            return super.method_7712(context);
        }
        return class_1269.field_5811;
    }
}
