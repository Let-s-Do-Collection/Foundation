package net.satisfy.foundation.client.mimic;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public final class MimicModels {
    public static final QuadRule ALL = (quad, state) -> Mode.REPLACE;

    private static final List<Entry> RETEXTURED = new ArrayList<>();
    private static final List<Supplier<? extends class_2248>> HELD = new ArrayList<>();
    private static @Nullable Map<class_2248, QuadRule> retexturedCache;
    private static @Nullable Map<class_2248, Boolean> heldCache;

    private MimicModels() {
    }

    public enum Mode {
        KEEP,
        REPLACE,
        UNDERLAY
    }

    @FunctionalInterface
    public interface QuadRule {
        Mode apply(class_777 quad, class_2680 state);
    }

    public static QuadRule tintIndex(int tintIndex) {
        return (quad, state) -> quad.method_3359() == tintIndex ? Mode.REPLACE : Mode.KEEP;
    }

    public static QuadRule placeholder(Mode others) {
        return (quad, state) -> quad.method_35788().method_45851().method_45816().method_12832().contains("placeholder") ? Mode.REPLACE : others;
    }

    @SafeVarargs
    public static synchronized void retexture(QuadRule rule, Supplier<? extends class_2248>... blocks) {
        for (Supplier<? extends class_2248> block : blocks) {
            RETEXTURED.add(new Entry(block, rule));
        }
        retexturedCache = null;
    }

    @SafeVarargs
    public static synchronized void held(Supplier<? extends class_2248>... blocks) {
        HELD.addAll(List.of(blocks));
        heldCache = null;
    }

    public static synchronized @Nullable QuadRule retextureRule(class_2248 block) {
        if (retexturedCache == null) {
            Map<class_2248, QuadRule> map = new IdentityHashMap<>();
            for (Entry entry : RETEXTURED) {
                map.put(entry.block().get(), entry.rule());
            }
            retexturedCache = map;
        }
        return retexturedCache.get(block);
    }

    public static synchronized boolean isHeld(class_2248 block) {
        if (heldCache == null) {
            Map<class_2248, Boolean> map = new IdentityHashMap<>();
            for (Supplier<? extends class_2248> supplier : HELD) {
                map.put(supplier.get(), true);
            }
            heldCache = map;
        }
        return heldCache.containsKey(block);
    }

    public static boolean isMimicModel(class_2248 block) {
        return retextureRule(block) != null || isHeld(block);
    }

    private record Entry(Supplier<? extends class_2248> block, QuadRule rule) {
    }
}
