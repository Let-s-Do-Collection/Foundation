package net.satisfy.foundation.trade;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1935;
import net.minecraft.class_3853;
import net.minecraft.class_5819;
import net.minecraft.class_9306;

public class SellItemFactory implements class_3853.class_1652 {
    private static final int DEFAULT_MAX_USES = 12;
    private static final float DEFAULT_MULTIPLIER = 0.05F;

    private final class_1799 sell;
    private final int price;
    private final int count;
    private final int maxUses;
    private final int experience;
    private final float multiplier;

    public SellItemFactory(class_1935 item, int price, int count, int experience) {
        this(new class_1799(item), price, count, DEFAULT_MAX_USES, experience);
    }

    public SellItemFactory(class_1935 item, int price, int count, int maxUses, int experience) {
        this(new class_1799(item), price, count, maxUses, experience);
    }

    public SellItemFactory(class_1799 stack, int price, int count, int maxUses, int experience) {
        this(stack, price, count, maxUses, experience, DEFAULT_MULTIPLIER);
    }

    public SellItemFactory(class_1799 stack, int price, int count, int maxUses, int experience, float multiplier) {
        this.sell = stack;
        this.price = price;
        this.count = count;
        this.maxUses = maxUses;
        this.experience = experience;
        this.multiplier = multiplier;
    }

    @Override
    public class_1914 method_7246(class_1297 entity, class_5819 random) {
        return new class_1914(new class_9306(class_1802.field_8687, price), sell.method_46651(count), maxUses, experience, multiplier);
    }
}
