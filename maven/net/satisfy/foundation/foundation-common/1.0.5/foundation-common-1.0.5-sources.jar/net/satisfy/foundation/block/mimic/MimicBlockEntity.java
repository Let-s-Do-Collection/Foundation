package net.satisfy.foundation.block.mimic;

import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class MimicBlockEntity extends class_2586 {
    private static final String TAG = "Mimic";
    private static final String LEGACY_TAG = "Held";

    private @Nullable class_2680 mimicState;

    public MimicBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public @Nullable class_2680 getMimicState() {
        return mimicState;
    }

    public boolean hasMimic() {
        return mimicState != null && !mimicState.method_26215();
    }

    public void setMimicState(@Nullable class_2680 state) {
        class_2680 next = state == null || state.method_26215() ? null : state;
        if (next == mimicState) {
            return;
        }
        mimicState = next;
        method_5431();
        if (field_11863 != null) {
            if (field_11863.field_9236) {
                refreshClient();
            } else {
                field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
            }
        }
    }

    protected void refreshClient() {
        if (field_11863 != null && field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31030);
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        if (mimicState != null) {
            tag.method_10566(TAG, class_2512.method_10686(mimicState));
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        String key = tag.method_10545(TAG) ? TAG : tag.method_10545(LEGACY_TAG) ? LEGACY_TAG : null;
        class_2680 state = key == null ? null : class_2512.method_10681(provider.method_46762(class_7924.field_41254), tag.method_10562(key));
        mimicState = state == null || state.method_26215() ? null : state;
        refreshClient();
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 provider) {
        return method_38244(provider);
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
}
