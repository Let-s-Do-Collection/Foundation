package net.satisfy.foundation.compostable;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_3962;

public final class FoundationCompostables {
    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Map<class_1792, Float> CHANCES = new IdentityHashMap<>();
    private static boolean applied;

    private FoundationCompostables() {
    }

    public static void register(float chance, Supplier<? extends class_1935> item) {
        synchronized (ENTRIES) {
            Entry entry = new Entry(item, chance);
            ENTRIES.add(entry);
            if (applied) {
                put(entry);
            }
        }
    }

    @SafeVarargs
    public static void register(float chance, Supplier<? extends class_1935>... items) {
        for (Supplier<? extends class_1935> item : items) {
            register(chance, item);
        }
    }

    @SafeVarargs
    public static void low(Supplier<? extends class_1935>... items) {
        register(0.3F, items);
    }

    @SafeVarargs
    public static void medium(Supplier<? extends class_1935>... items) {
        register(0.5F, items);
    }

    @SafeVarargs
    public static void high(Supplier<? extends class_1935>... items) {
        register(0.65F, items);
    }

    @SafeVarargs
    public static void veryHigh(Supplier<? extends class_1935>... items) {
        register(0.85F, items);
    }

    @SafeVarargs
    public static void full(Supplier<? extends class_1935>... items) {
        register(1.0F, items);
    }

    public static void apply() {
        synchronized (ENTRIES) {
            applied = true;
            for (Entry entry : ENTRIES) {
                put(entry);
            }
        }
    }

    private static void put(Entry entry) {
        class_1792 item = entry.item().get().method_8389();
        if (item == class_1802.field_8162) return;
        CHANCES.put(item, entry.chance());
        class_3962.field_17566.put(item, entry.chance());
    }

    public static float chance(class_1792 item) {
        Float chance = CHANCES.get(item);
        return chance == null ? -1.0F : chance;
    }

    private record Entry(Supplier<? extends class_1935> item, float chance) {
    }
}
