package net.satisfy.foundation.food;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1844;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_5328;
import net.minecraft.class_9334;
import net.satisfy.foundation.storage.StorageBlockEntity;
import net.satisfy.foundation.util.LibUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

public class PlaceableDrinkItem extends class_1747 {
    private static final int DRINK_DURATION = 32;

    private boolean crouchToPlace;
    private boolean drinkAnytime;
    private @Nullable Supplier<? extends class_1935> container;

    public PlaceableDrinkItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    public PlaceableDrinkItem crouchToPlace() {
        crouchToPlace = true;
        return this;
    }

    public PlaceableDrinkItem drinkAnytime() {
        drinkAnytime = true;
        return this;
    }

    public PlaceableDrinkItem container(Supplier<? extends class_1935> container) {
        this.container = container;
        return this;
    }

    protected @Nullable class_1792 containerFor(class_1799 stack) {
        return container == null ? null : container.get().method_8389();
    }

    protected void applyEffects(class_1799 stack, class_1937 level, class_1309 entity) {
        stack.method_57825(class_9334.field_49651, class_1844.field_49274).method_57402(effect -> entity.method_6092(new class_1293(effect)));
    }

    @Override
    public @NotNull class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return stack.method_57826(class_9334.field_50075) ? super.method_7881(stack, entity) : DRINK_DURATION;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (drinkAnytime || !player.method_5998(hand).method_57826(class_9334.field_50075)) {
            return class_5328.method_29282(level, player, hand);
        }
        return super.method_7836(level, player, hand);
    }

    @Override
    protected @Nullable class_2680 method_7707(class_1750 context) {
        if (crouchToPlace && (context.method_8036() == null || !context.method_8036().method_18276())) {
            return null;
        }
        return super.method_7707(context);
    }

    @Override
    protected boolean method_7710(class_2338 pos, class_1937 level, @Nullable class_1657 player, class_1799 stack, class_2680 state) {
        if (level.method_8321(pos) instanceof StorageBlockEntity storage) {
            storage.setStack(0, stack.method_46651(1));
        }
        return super.method_7710(pos, level, player, stack, state);
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
        class_1792 returned = containerFor(stack);
        if (!level.field_9236) {
            applyEffects(stack, level, entity);
        }
        class_1799 result;
        if (stack.method_57826(class_9334.field_50075)) {
            result = super.method_7861(stack, level, entity);
        } else {
            stack.method_57008(1, entity);
            result = stack;
        }
        return returned == null ? result : LibUtil.convertStackAfterFinishUsing(entity, result, returned, this);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        EffectTooltips.append(stack, context, tooltip);
    }
}
