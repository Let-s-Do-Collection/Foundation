package net.satisfy.foundation.food;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.satisfy.foundation.util.LibUtil;
import java.util.List;
import org.jetbrains.annotations.NotNull;

/**
 * Drink item that shows its food effects in the tooltip like a potion does.
 *
 * Note: {@code duration} in the constructor is not used anymore, kept for compat.
 */
@SuppressWarnings("unused")
public class EffectDrinkItem extends class_1792 {
    private final boolean returnBottle;

    public EffectDrinkItem(class_1793 properties, int duration, boolean returnBottle) {
        super(properties);
        this.returnBottle = returnBottle;
    }

    @Override
    public @NotNull class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 itemStack, class_1937 level, class_1309 livingEntity) {
        class_1799 eaten = livingEntity.method_60492(level, itemStack);
        if (this.returnBottle) {
            return LibUtil.convertStackAfterFinishUsing(livingEntity, eaten, class_1802.field_8469, this);
        }
        return eaten;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        super.method_7851(itemStack, tooltipContext, tooltip, tooltipFlag);
        EffectTooltips.append(itemStack, tooltipContext, tooltip);
    }
}
