package net.satisfy.foundation.mixin;

import net.minecraft.class_1266;
import net.minecraft.class_1315;
import net.minecraft.class_1642;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.satisfy.foundation.entity.equipment.ZombieEquipment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1642.class)
public abstract class ZombieMixin {
    @Inject(method = "finalizeSpawn", at = @At("RETURN"))
    private void foundation$equip(class_5425 level, class_1266 difficulty, class_3730 spawnType, class_1315 groupData, CallbackInfoReturnable<class_1315> cir) {
        ZombieEquipment.equip((class_1642) (Object) this, level.method_8409());
    }
}
