package net.satisfy.foundation.client.mimic;

import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.satisfy.foundation.block.mimic.MimicBlock;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public final class MimicQuads {
    private static final int STRIDE = 8;
    private static final int UV = 4;

    private MimicQuads() {
    }

    public static boolean isApplied(class_2680 state) {
        return !state.method_28498(MimicBlock.APPLIED) || state.method_11654(MimicBlock.APPLIED);
    }

    public static boolean isUsable(@Nullable class_2680 mimic) {
        return mimic != null && !mimic.method_26215() && mimic.method_26217() == class_2464.field_11458 && !MimicModels.isMimicModel(mimic.method_26204());
    }

    public static @Nullable class_1058 sprite(@Nullable class_2680 mimic) {
        if (!isUsable(mimic)) return null;
        class_1058 sprite = class_310.method_1551().method_1541().method_3349(mimic).method_4711();
        return sprite == null || "missingno".equals(sprite.method_45851().method_45816().method_12832()) ? null : sprite;
    }

    public static List<class_777> retexture(List<class_777> quads, class_2680 state, class_1058 sprite, MimicModels.QuadRule rule) {
        if (quads.isEmpty()) return quads;
        List<class_777> result = new ArrayList<>(quads.size());
        for (class_777 quad : quads) {
            switch (rule.apply(quad, state)) {
                case KEEP -> result.add(quad);
                case REPLACE -> result.add(remap(quad, sprite));
                case UNDERLAY -> {
                    result.add(remap(quad, sprite));
                    result.add(quad);
                }
            }
        }
        return result;
    }

    public static List<class_777> held(@Nullable class_2680 held, @Nullable class_2350 side, class_5819 random) {
        if (!isUsable(held)) return List.of();
        class_1087 model = class_310.method_1551().method_1541().method_3349(held);
        return model.method_4707(held, side, random);
    }

    public static class_777 remap(class_777 quad, class_1058 target) {
        class_1058 source = quad.method_35788();
        if (source == target) return quad;
        int[] vertices = quad.method_3357().clone();
        float widthScale = target.method_45851().method_45807() / (float) source.method_45851().method_45807();
        float heightScale = target.method_45851().method_45815() / (float) source.method_45851().method_45815();
        for (int i = 0; i < 4; i++) {
            int offset = i * STRIDE + UV;
            float u = Float.intBitsToFloat(vertices[offset]);
            float v = Float.intBitsToFloat(vertices[offset + 1]);
            vertices[offset] = Float.floatToRawIntBits((u - source.method_4594()) * widthScale + target.method_4594());
            vertices[offset + 1] = Float.floatToRawIntBits((v - source.method_4593()) * heightScale + target.method_4593());
        }
        return new class_777(vertices, quad.method_3359(), quad.method_3358(), target, quad.method_24874());
    }
}
