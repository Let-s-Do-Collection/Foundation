package net.satisfy.foundation.block.mimic;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1810;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_8567;
import net.minecraft.class_9062;

public final class MimicBlock {
    public static final class_2746 APPLIED = class_2746.method_11825("applied");
    private static final int DESTROY_EVENT = 2001;

    private MimicBlock() {
    }

    public static boolean canAccept(class_1922 level, class_2338 pos, class_2680 candidate) {
        if (candidate == null || candidate.method_26215()) return false;
        if (candidate.method_26204() instanceof class_2343) return false;
        if (candidate.method_26217() != class_2464.field_11458) return false;
        return class_2248.method_9614(candidate.method_26218(level, pos));
    }

    public static class_9062 use(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, Predicate<class_2680> accepts) {
        if (stack.method_7909() instanceof class_1810) {
            if (!state.method_11654(APPLIED)) return class_9062.field_47731;
            if (!level.field_9236) {
                remove(level, pos, state, true);
            }
            return class_9062.method_55644(level.field_9236);
        }
        if (state.method_11654(APPLIED) || !(stack.method_7909() instanceof class_1747 blockItem)) {
            return class_9062.field_47731;
        }
        class_2680 mimic = blockItem.method_7711().method_9564();
        if (!canAccept(level, pos, mimic) || !accepts.test(mimic)) {
            return class_9062.field_47731;
        }
        if (!level.field_9236 && apply(level, pos, state, mimic) && !player.method_31549().field_7477) {
            stack.method_7934(1);
        }
        return class_9062.method_55644(level.field_9236);
    }

    public static boolean apply(class_1937 level, class_2338 pos, class_2680 state, class_2680 mimic) {
        if (!(level.method_8321(pos) instanceof MimicBlockEntity entity)) return false;
        entity.setMimicState(mimic);
        if (state.method_28498(APPLIED)) {
            level.method_8652(pos, state.method_11657(APPLIED, true), class_2248.field_31036);
        }
        if (level instanceof class_3218 serverLevel) {
            serverLevel.method_20290(DESTROY_EVENT, pos, class_2248.method_9507(mimic));
        }
        return true;
    }

    public static void remove(class_1937 level, class_2338 pos, class_2680 state, boolean drop) {
        if (!(level.method_8321(pos) instanceof MimicBlockEntity entity)) return;
        class_2680 mimic = entity.getMimicState();
        if (mimic == null) return;
        if (drop) {
            class_2248.method_9577(level, pos, new class_1799(mimic.method_26204()));
        }
        entity.setMimicState(null);
        if (state.method_28498(APPLIED)) {
            level.method_8652(pos, state.method_11657(APPLIED, false), class_2248.field_31036);
        }
        if (level instanceof class_3218 serverLevel) {
            serverLevel.method_20290(DESTROY_EVENT, pos, class_2248.method_9507(mimic));
        }
    }

    public static List<class_1799> addDrops(List<class_1799> drops, class_8567.class_8568 builder) {
        if (!(builder.method_51876(class_181.field_1228) instanceof MimicBlockEntity entity) || !entity.hasMimic()) {
            return drops;
        }
        List<class_1799> result = new ArrayList<>(drops);
        result.add(new class_1799(entity.getMimicState().method_26204()));
        return result;
    }
}
