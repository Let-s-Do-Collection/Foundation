package net.satisfy.foundation.food;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_9334;

public final class EffectTooltips {
    private EffectTooltips() {
    }

    public static List<class_1293> effects(class_1799 stack) {
        List<class_1293> effects = new ArrayList<>();
        stack.method_57825(class_9334.field_49651, class_1844.field_49274).method_57402(effects::add);
        class_4174 food = stack.method_57824(class_9334.field_50075);
        if (food != null) {
            for (class_4174.class_9423 possibleEffect : food.comp_2495()) {
                effects.add(possibleEffect.comp_2496());
            }
        }
        return effects;
    }

    public static void append(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip) {
        class_1844.method_8065(effects(stack), tooltip::add, 1.0F, context.method_59531());
    }
}
