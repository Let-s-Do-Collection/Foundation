package net.satisfy.foundation.entity.equipment;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import net.minecraft.class_1304;
import net.minecraft.class_1642;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_5819;

public final class ZombieEquipment {
    private static final List<Outfit> OUTFITS = new ArrayList<>();

    private ZombieEquipment() {
    }

    public static Outfit add(DoubleSupplier chance) {
        Outfit outfit = new Outfit(chance);
        synchronized (OUTFITS) {
            OUTFITS.add(outfit);
        }
        return outfit;
    }

    public static Outfit add(double chance) {
        return add(() -> chance);
    }

    public static void equip(class_1642 zombie, class_5819 random) {
        synchronized (OUTFITS) {
            for (Outfit outfit : OUTFITS) {
                outfit.tryEquip(zombie, random);
            }
        }
    }

    public static final class Outfit {
        private final DoubleSupplier chance;
        private final Map<class_1304, Supplier<? extends class_1935>> items = new EnumMap<>(class_1304.class);
        private boolean adultsOnly;

        private Outfit(DoubleSupplier chance) {
            this.chance = chance;
        }

        public Outfit slot(class_1304 slot, Supplier<? extends class_1935> item) {
            items.put(slot, item);
            return this;
        }

        public Outfit adultsOnly() {
            adultsOnly = true;
            return this;
        }

        private void tryEquip(class_1642 zombie, class_5819 random) {
            if (adultsOnly && zombie.method_6109()) return;
            if (random.method_43058() >= chance.getAsDouble()) return;
            items.forEach((slot, item) -> zombie.method_5673(slot, new class_1799(item.get())));
        }
    }
}
