package net.satisfy.foundation.trade;

import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1935;
import net.minecraft.class_3853;
import net.minecraft.class_5819;
import net.minecraft.class_9306;

public class BuyForOneEmeraldFactory implements class_3853.class_1652 {
    private static final float DEFAULT_MULTIPLIER = 0.05F;

    private final class_1792 buy;
    private final int price;
    private final int maxUses;
    private final int experience;
    private final float multiplier;

    public BuyForOneEmeraldFactory(class_1935 item, int price, int maxUses, int experience) {
        this(item, price, maxUses, experience, DEFAULT_MULTIPLIER);
    }

    public BuyForOneEmeraldFactory(class_1935 item, int price, int maxUses, int experience, float multiplier) {
        this.buy = item.method_8389();
        this.price = price;
        this.maxUses = maxUses;
        this.experience = experience;
        this.multiplier = multiplier;
    }

    @Override
    public class_1914 method_7246(class_1297 entity, class_5819 random) {
        return new class_1914(new class_9306(buy, price), new class_1799(class_1802.field_8687), maxUses, experience, multiplier);
    }
}
