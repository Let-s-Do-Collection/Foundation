package net.satisfy.foundation.food;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.satisfy.foundation.util.LibUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Food item with potion-like effect tooltip, optionally gives the bowl back.
 *
 * Note: {@code duration} is unused, same as in {@link EffectDrinkItem}.
 */
@SuppressWarnings("unused")
public class EffectFoodItem extends class_1792 {
    private final boolean returnBowl;

    public EffectFoodItem(class_1793 properties, int duration, boolean returnBowl) {
        super(properties);
        this.returnBowl = returnBowl;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> tooltip, class_1836 tooltipFlag) {
        EffectTooltips.append(itemStack, tooltipContext, tooltip);
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 itemStack, class_1937 level, class_1309 livingEntity) {
        class_1799 eaten = livingEntity.method_60492(level, itemStack);
        if (this.returnBowl) {
            return LibUtil.convertStackAfterFinishUsing(livingEntity, eaten, class_1802.field_8428, this);
        }
        return eaten;
    }
}
